"""Strict raw C ABI/journal readback; a passing model is never OS authority."""
import json
import re
import uuid

CASES = ('normal', 'signal', 'stop', 'slow', 'descendant', 'ceiling', 'race', 'race', 'race',
         'fault1', 'fault2', 'fault3', 'fault4', 'fault5', 'fault6', 'fault7', 'fault8',
         'closed-input', 'inherited-input', 'unsupported-descriptor', 'closed-output', 'closed-error')
OBSERVATION_KEYS = {'schema','caseId','mode','phase','observerPid','monotonicNs','leaseDeadlineNs','workDeadlineNs',
    'stopDeadlineNs','drainDeadlineNs','pid','startTicks','birthUtcNs','bootId','executable','preexecHeld',
    'denialObserved','terminal','exitCode','signal','nativeError','exactAbsence','ownedTasks','reapedTasks'}
CONTROL_KEYS = {'schema','caseId','phase','position','observerPid','monotonicNs','family','loopbackPort',
                'connected','byteObserved','socketsClosed'}


def require(value):
    if not value:
        raise ValueError('Exact native C ABI/journal evidence refused')


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result); result[key] = value
    return result


def integers(row, names, minimum=0):
    require(all(type(row[k]) is int and row[k] >= minimum for k in names))


def declared_layout(fields):
    cursor = 0; offsets = {}; maximum_align = 1
    for name, size, align in fields:
        maximum_align = max(maximum_align, align)
        cursor = (cursor + align - 1) // align * align
        offsets[name] = cursor; cursor += size
    return (cursor + maximum_align - 1) // maximum_align * maximum_align, offsets


def expected_layout():
    request, req_offsets = declared_layout([(name, size, align) for name, size, align in
        [('size',4,4),('abi',4,4),('executable',8,8),('cwd',8,8),('argv',8,8),('envp',8,8),
         ('lease_deadline_ns',8,8),('work_deadline_ns',8,8),('test_fault',4,4)]])
    observation, obs_offsets = declared_layout([(name,4,4) for name in ('size','abi','pid','terminal','exit_code','signal')] +
        [('start_ticks',8,8),('birth_utc_ns',8,8),('boot_id',37,1),('executable',4096,1)] +
        [(name,4,4) for name in ('preexec_held','denial_observed','exact_absence','native_error','owned_tasks','reaped_tasks')])
    return dict(abi=1, pointerBytes=8, requestBytes=request, observationBytes=observation,
                requestOffsets=req_offsets, observationOffsets=obs_offsets)


def abi(raw):
    require(type(raw) is bytes and 0 < len(raw) <= 8192)
    value = json.loads(raw, object_pairs_hook=unique)
    expected = expected_layout()
    require(type(value) is dict and set(value) == set(expected))
    for key in ('abi','pointerBytes','requestBytes','observationBytes'):
        require(type(value[key]) is int and value[key] == expected[key])
    for key in ('requestOffsets','observationOffsets'):
        require(type(value[key]) is dict and set(value[key]) == set(expected[key]))
        require(all(type(v) is int and v == expected[key][name] for name, v in value[key].items()))
    return value


def journal(raw, observer_pid, expected_executable):
    require(type(raw) is bytes and 0 < len(raw) <= 4*1024**2 and type(observer_pid) is int and observer_pid > 0)
    require(type(expected_executable) is str and expected_executable.startswith('/'))
    rows = []
    for line in raw.decode('utf-8', errors='strict').splitlines():
        require(line and len(line.encode()) <= 32768)
        if line.startswith('{'):
            row = json.loads(line, object_pairs_hook=unique)
            require(type(row) is dict)
            rows.append(row)
        else:
            require(re.fullmatch(r'PASS native case (normal|signal|stop|slow|descendant|ceiling|race|closed-input|inherited-input|closed-output|closed-error)|PASS native fault[1-8]|PASS preallocation unsupported descriptor refusal|PASS 22 actual Linux child cases; Auth Program qualification remains separate', line) is not None)
    require(len(rows) == 113)
    grouped = {}
    for row in rows:
        require(row.get('phase') in {'live-parent-control','held','denied-held','terminal','released','preallocation-refused'})
        integers(row, ('schema','caseId','observerPid','monotonicNs'), 1)
        require(row['schema'] == 1 and row['observerPid'] == observer_pid and row['caseId'] <= 22)
        grouped.setdefault(row['caseId'], []).append(row)
        if row['phase'] == 'live-parent-control':
            require(set(row) == CONTROL_KEYS and row['position'] in {'before-create','after-release'})
            integers(row, ('family','loopbackPort'), 1)
            require(row['family'] in (2,10) and row['loopbackPort'] <= 65535)
            require(all(type(row[k]) is bool and row[k] for k in ('connected','byteObserved','socketsClosed')))
        else:
            require(set(row) == OBSERVATION_KEYS and row['mode'] == CASES[row['caseId']-1])
            integers(row, ('leaseDeadlineNs','workDeadlineNs'), 1)
            integers(row, ('stopDeadlineNs','drainDeadlineNs','pid','startTicks','birthUtcNs','nativeError','ownedTasks','reapedTasks'))
            require(row['workDeadlineNs'] <= row['leaseDeadlineNs'] and row['monotonicNs'] <= row['leaseDeadlineNs'])
            require(row['leaseDeadlineNs'] <= row['monotonicNs'] + 45_000_000_000 and
                    row['workDeadlineNs'] <= row['monotonicNs'] + 30_000_000_000)
            require(row['stopDeadlineNs'] <= row['leaseDeadlineNs'] and row['drainDeadlineNs'] <= row['leaseDeadlineNs'])
            require(row['stopDeadlineNs'] <= row['monotonicNs'] + 5_000_000_000 and
                    row['drainDeadlineNs'] <= row['monotonicNs'] + 5_000_000_000)
            for k in ('preexecHeld','denialObserved','terminal','exactAbsence'):
                require(type(row[k]) is int and row[k] in (0,1))
            require(type(row['exitCode']) is int and type(row['signal']) is int)
            require(type(row['bootId']) is str and type(row['executable']) is str)
            require(row['reapedTasks'] <= row['ownedTasks'] <= 64)
            if row['pid']:
                require(row['startTicks'] > 0 and row['birthUtcNs'] > 0 and row['executable'] == expected_executable)
                require(str(uuid.UUID(row['bootId'])) == row['bootId'])
            else:
                require(row['startTicks'] == row['birthUtcNs'] == 0 and row['bootId'] == row['executable'] == '')
            if row['terminal']:
                require((0 <= row['exitCode'] <= 255 and row['signal'] == -1) or
                        (row['exitCode'] == -1 and 1 <= row['signal'] <= 64))
                require(row['preexecHeld'] == 0)
            else:
                require(row['exitCode'] == row['signal'] == -1)
    require(set(grouped) == set(range(1,23)))
    identities = set()
    identity_keys = ('pid','startTicks','birthUtcNs','bootId','executable')
    def retain_identity(row):
        identity = tuple(row[k] for k in identity_keys)
        require(identity[0] > 0 and identity not in identities)
        identities.add(identity)
        return identity

    for case_id, mode in enumerate(CASES, 1):
        case = grouped[case_id]
        if mode == 'unsupported-descriptor':
            require(len(case) == 1 and case[0]['phase'] == 'preallocation-refused' and case[0]['nativeError'] > 0)
            require(case[0]['pid'] == case[0]['ownedTasks'] == case[0]['reapedTasks'] == 0)
            continue
        if mode.startswith('fault'):
            require(len(case) == 1 and case[0]['phase'] == 'released' and case[0]['nativeError'] > 0)
            require(case[0]['exactAbsence'] == 1 and case[0]['ownedTasks'] == case[0]['reapedTasks'])
            point = int(mode[-1]); has_child = point in (4,5,6,7)
            require(case[0]['ownedTasks'] == (1 if has_child else 0) and case[0]['terminal'] == int(has_child))
            if has_child:
                retain_identity(case[0])
            else:
                require(case[0]['pid'] == 0)
            require(case[0]['denialObserved'] == int(point == 7))
            require(case[0]['stopDeadlineNs'] > 0 and case[0]['drainDeadlineNs'] > 0)
            continue
        require(len(case) == 8)
        observations = [row for row in case if row['phase'] != 'live-parent-control']
        require([row['phase'] for row in observations] == ['held','denied-held','terminal','released'])
        controls = [row for row in case if row['phase'] == 'live-parent-control']
        require([(row['position'], row['family']) for row in controls] ==
                [('before-create',2),('before-create',10),('after-release',2),('after-release',10)])
        require(case[:2] == controls[:2] and case[-2:] == controls[-2:])
        identity = retain_identity(observations[0])
        require(identity[0] > 0 and all(tuple(row[k] for k in ('pid','startTicks','birthUtcNs','bootId','executable')) == identity for row in observations))
        require(all(row['nativeError'] == 0 for row in observations))
        require(observations[0]['preexecHeld'] == observations[1]['preexecHeld'] == 1)
        require(observations[0]['denialObserved'] == 0 and observations[1]['denialObserved'] == 1)
        for key in ('leaseDeadlineNs','workDeadlineNs'):
            require(len({row[key] for row in observations}) == 1)
        terminal, released = observations[2:]
        require(terminal['terminal'] == released['terminal'] == 1)
        signaled = mode in ('signal','slow','race')
        require(terminal['exitCode'] == released['exitCode'] == (-1 if signaled else 17))
        require(terminal['signal'] == released['signal'] == (9 if signaled else -1))
        require(released['exactAbsence'] == 1 and released['ownedTasks'] == released['reapedTasks'])
        require(released['stopDeadlineNs'] > 0 and released['drainDeadlineNs'] > 0)
        if mode == 'descendant': require(released['ownedTasks'] == 2)
        if mode == 'ceiling': require(released['ownedTasks'] == 64)
        if mode == 'race': require(released['ownedTasks'] >= 4)
    return dict(cases=len(CASES), rows=len(rows), observerPid=observer_pid, controls=52,
                nativeIdentityJoined=True, exactTerminalAndAbsenceJoined=True)
