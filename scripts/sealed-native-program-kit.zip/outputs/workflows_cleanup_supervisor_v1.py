"""Same-owner cleanup-only supervision with finite renewed attempt leases.

No launcher, PID lookup, new command, foreign cleanup or slot admission exists
here. Exhausted attempts checkpoint attention, retain ownership, and retry.
"""
from datetime import datetime, timedelta, timezone
import time
import math

def supervise(resources, recover, slot, journal, checkpoint, *, attempt_seconds=20,
              attention_seconds=900, monotonic=time.monotonic, wait=time.sleep,
              absolute_deadline=None):
    if not 0 < attempt_seconds <= 60 or not 0 < attention_seconds <= 900:
        raise ValueError('Invalid finite cleanup attempt lease')
    if absolute_deadline is not None and (type(absolute_deadline) not in (int,float) or not math.isfinite(absolute_deadline)):
        raise ValueError('Invalid fixed cleanup boundary')
    state = {'attempts':0, 'failureCount':0, 'errorDetails':[], 'checkpointFailureCount':0,
             'attentionCount':0, 'slotReleased':slot is None, 'journalClosed':journal is None,
             'cleanupOnly':True}
    attention_deadline = monotonic() + attention_seconds

    def error(exc):
        state['failureCount'] += 1
        detail = type(exc).__name__
        if detail not in state['errorDetails'] and len(state['errorDetails']) < 16:
            state['errorDetails'].append(detail)

    def write(kind):
        try:
            checkpoint(kind, dict(state))
        except BaseException as exc:
            state['checkpointFailureCount'] += 1
            error(exc)

    def expired():
        return absolute_deadline is not None and monotonic() >= absolute_deadline

    def retain_expired():
        # No renewed recovery or claim release is allowed beyond this boundary.
        # The file journal can close while resource/slot custody stays recorded.
        if not state['journalClosed']:
            try:
                journal.close();state['journalClosed']=journal.closed
            except BaseException as exc:error(exc)
        state.update(cleanupVerified=False,attentionRequired=True,
                     fixedDeadlineExpired=True,absoluteDeadline=absolute_deadline,
                     ownedLeases=list(resources),custodyRetained=True)
        error(TimeoutError('Fixed cleanup boundary expired; custody retained'))
        write('cleanup-expired-checkpoint')
        return state

    while resources or not state['slotReleased'] or not state['journalClosed']:
        if expired():return retain_expired()
        state['attempts'] += 1
        start = monotonic()
        state['attemptIssuedUtc'] = datetime.now(timezone.utc).isoformat()
        duration=attempt_seconds if absolute_deadline is None else min(attempt_seconds,max(0,absolute_deadline-start))
        state['attemptExpiresUtc'] = (datetime.now(timezone.utc)+timedelta(seconds=duration)).isoformat()
        state['ownedLeases'] = list(resources)
        state['attentionRequired'] = False
        write('cleanup-attempt-start')  # Failed persistence never drops ownership.
        deadline = start + duration
        while monotonic() < deadline:
            for lease_id in list(resources):
                if expired():return retain_expired()
                try:
                    recover(lease_id)
                except BaseException as exc:
                    error(exc)
            # Individual successes remain committed; none is queried/reclosed.
            if not resources and not state['slotReleased']:
                if expired():return retain_expired()
                try:
                    slot.close(partial=slot.partial_creation)
                    state['slotReleased'] = slot.released
                except BaseException as exc:
                    error(exc)
            if not resources and not state['journalClosed']:
                if expired():return retain_expired()
                try:
                    journal.close()
                    state['journalClosed'] = journal.closed
                except BaseException as exc:
                    error(exc)
            if not resources and state['slotReleased'] and state['journalClosed']:
                break
            try:
                wait(min(.1, max(0, deadline-monotonic())))
            except BaseException as exc:
                # Cancellation of the delay is not permission to abandon
                # retained resources or release the claim.
                error(exc)
        state['ownedLeases'] = list(resources)
        write('cleanup-attempt-end')
        if expired():return retain_expired()
        if monotonic() >= attention_deadline and (resources or not state['slotReleased'] or not state['journalClosed']):
            state['attentionCount'] += 1
            state['attentionRequired'] = True
            write('cleanup-attention-checkpoint')
            attention_deadline = monotonic() + attention_seconds
            # Renew cleanup supervision only. No permit or command is renewed.
    state['cleanupVerified'] = True
    return state
