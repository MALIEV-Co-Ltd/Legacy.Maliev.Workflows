"""Held regular-file execution and bounded task namespace removal primitives."""
import hashlib
import os
from pathlib import Path
import stat
import time

def require(value):
    if not value: raise RuntimeError('Linux trust/custody refused')

def bind_executable(requested, roots, expected_uid, expected_sha=None, *, maximum_bytes=64*1024**2):
    requested = Path(requested).absolute()
    roots = [Path(root).absolute() for root in roots]
    require(roots and all(root.resolve(strict=True) == root and root.is_dir() for root in roots))
    resolved = requested.resolve(strict=True)
    require(any(resolved.is_relative_to(root) for root in roots))
    require(type(maximum_bytes) is int and (maximum_bytes == 64*1024**2
            or maximum_bytes == 96*1024**2 and requested.name == resolved.name == 'dockerd'))
    fd = None
    try:
        fd = os.open(resolved, os.O_RDONLY | getattr(os, 'O_NOFOLLOW', 0))
        held = os.fstat(fd); observed = resolved.stat(follow_symlinks=False)
        require(stat.S_ISREG(held.st_mode) and held.st_uid == expected_uid
                and held.st_mode & 0o7022 == 0 and held.st_size <= maximum_bytes)
        require((held.st_dev, held.st_ino) == (observed.st_dev, observed.st_ino))
        hasher = hashlib.sha256(); size = 0
        with os.fdopen(os.dup(fd), 'rb') as source:
            while block := source.read(65536):
                size += len(block); require(size <= maximum_bytes); hasher.update(block)
        after = os.fstat(fd)
        require(size == held.st_size and (after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
                == (held.st_dev,held.st_ino,held.st_size,held.st_mtime_ns))
        sha = hasher.hexdigest()
        require(expected_sha is None or sha == expected_sha)
        os.lseek(fd, 0, os.SEEK_SET)
        value = dict(requested=str(requested), resolved=str(resolved), fd=fd, roots=[str(r) for r in roots],
                     uid=expected_uid, device=held.st_dev, inode=held.st_ino, bytes=size,
                     mode=held.st_mode, modifiedNs=held.st_mtime_ns, sha256=sha, maximumBytes=maximum_bytes)
        recheck_executable(value)
        return value
    except BaseException:
        if fd is not None: os.close(fd)
        raise

def recheck_executable(value):
    maximum_bytes = value['maximumBytes']
    require(type(maximum_bytes) is int and (maximum_bytes == 64*1024**2
            or maximum_bytes == 96*1024**2 and Path(value['requested']).name == Path(value['resolved']).name == 'dockerd'))
    held = os.fstat(value['fd'])
    resolved = Path(value['requested']).resolve(strict=True)
    require(str(resolved) == value['resolved'])
    actual = resolved.stat(follow_symlinks=False)
    require(stat.S_ISREG(actual.st_mode) and actual.st_uid == value['uid'] and actual.st_mode & 0o7022 == 0)
    require(held.st_size <= maximum_bytes and actual.st_size <= maximum_bytes)
    expected = (value['device'],value['inode'],value['bytes'],value['mode'],value['modifiedNs'])
    for row in (held,actual):
        require((row.st_dev,row.st_ino,row.st_size,row.st_mode,row.st_mtime_ns) == expected)
    hasher = hashlib.sha256()
    os.lseek(value['fd'], 0, os.SEEK_SET)
    with os.fdopen(os.dup(value['fd']), 'rb') as source:
        size = 0
        while block := source.read(65536):
            size += len(block); require(size <= maximum_bytes); hasher.update(block)
    os.lseek(value['fd'], 0, os.SEEK_SET)
    require(size == value['bytes'] and hasher.hexdigest() == value['sha256'])
    return True

def remaining(deadline):
    value = deadline-time.monotonic()
    if value <= 0: raise TimeoutError('Fixed cleanup reserve exhausted; custody retained')
    return value

def remove_owned_tree(root, expected_identity, deadline):
    root = Path(root)
    remaining(deadline)
    require(root.resolve() == root.absolute() and not root.is_symlink())
    observed = root.stat(follow_symlinks=False)
    require((observed.st_dev,observed.st_ino,observed.st_uid) == expected_identity)
    count = 0
    def remove(path):
        nonlocal count
        remaining(deadline); count += 1; require(count <= 100000)
        row = path.stat(follow_symlinks=False)
        if stat.S_ISDIR(row.st_mode):
            with os.scandir(path) as entries:
                children = [Path(entry.path) for entry in entries]
            for child in children: remove(child)
            remaining(deadline); path.rmdir()
        else:
            # Unlink a contained link/socket itself; never follow it outside the owned root.
            remaining(deadline); path.unlink()
    remove(root)
    require(not root.exists())
