"""Fixed original-route C component qualification; no Auth factory authority.

This source is inactive until its complete profile is sealed, published, and
associated with a fresh original Root permit by the existing hosted entry.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import time
import uuid

import native_program_readback as readback
import workflows_native_elf_admission_v1 as native

OUT = Path(__file__).resolve().parent
REPO = Path('/tmp/maliev-workflows-qualification/worktree')
BASE = '82cc4539b5b45c57457d4779c482bf1ab332900c'
SOURCE = REPO / 'tools/native-program-child'
SOURCE_INDEX = native.NATIVE_SOURCE_INDEX
TRANSPORT_INDEX = '6abd042d621b1d50acbc12679edbd47f687cedd5728ac20966295ff9b3911a73'
SDK_FILES = json.loads((OUT/'sdk-files.json').read_bytes(), object_pairs_hook=readback.unique)
FLAGS = ('terminal_state_verified','job_caps_readback_verified','cleanup_verified',
         'process_handle_closed','thread_handle_closed','job_handle_closed',
         'pipe_handles_closed','readers_settled','attribute_list_disposed')
CAPS = dict(initialMemoryFloorMiB=5120,runtimeMemoryFloorMiB=4096,
            memoryBytes=3221225472,cpuRate=5000,tasks=64,outputBytes=4194304,
            sharedWorkSeconds=600,cleanupReserveSeconds=25,externalMinutes=20,
            permitMaximumSeconds=900)
CFLAGS = ['-std=c11','-O2','-Wall','-Wextra','-Werror','-Wconversion','-Wshadow','-fPIC','-pthread']


def require(value):
    if not value:
        raise ValueError('Fixed native component profile refused')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def profile_check(profile):
    require(type(profile) is dict and set(profile) == {
        'schema','profile','baseSha','nativeSourceIndexSha256','transportSourceIndexSha256',
        'sourceDirectory','sourcePins','helperPins','caps','sdkExecuted','factoryBound'})
    require(type(profile['schema']) is int and profile['schema']==1)
    require(profile['profile']=='auth-program-child-c-component-v1' and profile['baseSha']==BASE)
    require(profile['nativeSourceIndexSha256']==SOURCE_INDEX and profile['transportSourceIndexSha256']==TRANSPORT_INDEX)
    require(profile['sourceDirectory']==SOURCE.as_posix() and profile['sdkExecuted'] is False and profile['factoryBound'] is False)
    require(type(profile['caps']) is dict and profile['caps']==CAPS and
            all(type(value) is int for value in profile['caps'].values()))
    pins = profile['sourcePins']
    require(type(pins) is list and len(pins)==6)
    require([row['path'] for row in pins]==['ABI.md','Makefile','program_child.c','program_child.h','source_checks.py','test_program_child.c'])
    for row in pins:
        require(type(row) is dict and set(row)=={'path','bytes','sha256'})
        require(type(row['bytes']) is int and 0<row['bytes']<=1024**2)
        require(type(row['sha256']) is str and len(row['sha256'])==64 and all(c in '0123456789abcdef' for c in row['sha256']))
    require(sha((json.dumps(pins,indent=2)+'\n').encode())==SOURCE_INDEX)
    require(type(profile['helperPins']) is dict and set(profile['helperPins'])=={
        'hosted_native_program_core.py','native_program_readback.py','workflows_native_elf_admission_v1.py',
        'workflows_linux_runtime.py','workflows_linux_trust.py','workflows_linux_owned_scope_v1.py',
        'workflows_native_admission_v3.py','workflows_cleanup_supervisor_v1.py','sdk-files.json'})
    for name, digest in profile['helperPins'].items():
        require(type(digest) is str and len(digest)==64 and all(c in '0123456789abcdef' for c in digest))
    return profile


def candidate_check():
    profile = profile_check(json.loads((OUT/'native-component-profile.json').read_bytes(),object_pairs_hook=readback.unique))
    for name, digest in profile['helperPins'].items():
        path=OUT/name
        require(path.resolve(strict=True)==path and sha(path.read_bytes())==digest)
    require(SOURCE.resolve(strict=True)==SOURCE and {p.name for p in SOURCE.iterdir()}=={r['path'] for r in profile['sourcePins']})
    for row in profile['sourcePins']:
        path=SOURCE/row['path']; info=path.stat(follow_symlinks=False)
        require(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size==row['bytes'])
        require(sha(path.read_bytes())==row['sha256'])
    return profile


def compile_commands(directory, frozen_source):
    root=str(directory)
    return [
        ['/usr/bin/cc',*CFLAGS,'-shared','-Wl,-z,relro,-z,now','-o',root+'/libmaliev_test_program_child.so',str(frozen_source/'program_child.c'),'-pthread'],
        ['/usr/bin/cc',*CFLAGS,'-o',root+'/test_program_child',str(frozen_source/'test_program_child.c'),'-L'+root,
         '-lmaliev_test_program_child','-Wl,-rpath,$ORIGIN','-pthread']]


def pinned_source_bytes(path,pin):
    with path.open('rb') as source:
        raw=source.read(pin['bytes']+1)
    require(len(raw)==pin['bytes'] and sha(raw)==pin['sha256'])
    return raw


def freeze_sources(root,pins):
    require(os.geteuid()==0 and root.resolve(strict=True)==root)
    parent=root.stat(follow_symlinks=False)
    require(parent.st_uid==0 and stat.S_ISDIR(parent.st_mode) and parent.st_mode & 0o7022==0)
    directory=root/'sources';directory.mkdir(mode=0o700)
    identities={}
    for pin in pins:
        # Hash the bytes actually copied, rather than trusting a prior pathname
        # check in the writable checkout. No compile uses the checkout path.
        raw=pinned_source_bytes(SOURCE/pin['path'],pin)
        path=directory/pin['path']
        with path.open('xb') as target:
            require(target.write(raw)==len(raw));target.flush();os.fsync(target.fileno())
        os.chmod(path,0o444)
        info=path.stat(follow_symlinks=False)
        identities[pin['path']]=dict(device=info.st_dev,inode=info.st_ino,bytes=info.st_size,
                                     modifiedNs=info.st_mtime_ns,sha256=pin['sha256'])
    os.chmod(directory,0o555)
    info=directory.stat(follow_symlinks=False)
    proof=dict(directory=dict(device=info.st_dev,inode=info.st_ino),files=identities)
    verify_frozen_sources(directory,proof)
    return directory,proof


def verify_frozen_sources(directory,proof):
    require(directory.resolve(strict=True)==directory)
    info=directory.stat(follow_symlinks=False)
    require(info.st_uid==0 and info.st_mode==stat.S_IFDIR|0o555 and
            (info.st_dev,info.st_ino)==(proof['directory']['device'],proof['directory']['inode']))
    require({p.name for p in directory.iterdir()}==set(proof['files']))
    for name,pin in proof['files'].items():
        path=directory/name;info=path.stat(follow_symlinks=False)
        require(path.resolve(strict=True)==path and info.st_uid==0 and info.st_mode==stat.S_IFREG|0o444 and info.st_nlink==1)
        require((info.st_dev,info.st_ino,info.st_size,info.st_mtime_ns)==
                (pin['device'],pin['inode'],pin['bytes'],pin['modifiedNs']))
        require(sha(path.read_bytes())==pin['sha256'])


def finish_component(primary,supervise,receipt,close_journal):
    """Always attempt retention; preserve the original command failure."""
    secondary=[];cleanup=None
    try:cleanup=supervise()
    except BaseException as error:
        if primary is None:primary=error
        else:secondary.append(type(error).__name__)
        try:close_journal()
        except BaseException as close_error:secondary.append(type(close_error).__name__)
    try:receipt(cleanup,primary,secondary)
    except BaseException as error:
        if primary is None:primary=error
        else:secondary.append(type(error).__name__)
    return primary,cleanup,secondary


def checked_file(path, uid, mode):
    require(path.resolve(strict=True)==path)
    before=path.stat(follow_symlinks=False)
    require(stat.S_ISREG(before.st_mode) and before.st_uid==uid and before.st_nlink==1 and 0<before.st_size<=64*1024**2)
    with path.open('rb') as stream:
        raw=stream.read(64*1024**2+1)
    after=path.stat(follow_symlinks=False)
    keys=('st_dev','st_ino','st_uid','st_gid','st_mode','st_size','st_mtime_ns','st_ctime_ns','st_nlink')
    require(all(getattr(before,k)==getattr(after,k) for k in keys) and len(raw)==before.st_size and
            raw[:7]==b'\x7fELF\x02\x01\x01' and raw[18:20]==b'\x3e\x00')
    os.chown(path,0,0);os.chmod(path,mode)
    final=path.stat(follow_symlinks=False)
    require(final.st_ino==before.st_ino and final.st_dev==before.st_dev and final.st_size==len(raw) and final.st_uid==0)
    return dict(path=str(path),sha256=sha(raw),device=final.st_dev,inode=final.st_ino,
                bytes=final.st_size,uid=final.st_uid,mode=final.st_mode,modifiedNs=final.st_mtime_ns)


def write_evidence(path,value):
    raw=(json.dumps(value,indent=2)+'\n').encode()
    require(len(raw)<=256*1024)
    with path.open('xb') as stream:
        require(stream.write(raw)==len(raw));stream.flush();os.fsync(stream.fileno())


def create_helper_parent(root):
    root.mkdir(mode=0o755)
    require(root.resolve(strict=True)==root)
    before=root.stat(follow_symlinks=False)
    require(before.st_uid==0 and stat.S_ISDIR(before.st_mode))
    # mkdir's mode is masked by the controller's umask. The separately
    # admitted compiler UID needs traversal through this exact fresh parent.
    os.chmod(root,0o755,follow_symlinks=False)
    after=root.stat(follow_symlinks=False)
    require((after.st_dev,after.st_ino)==(before.st_dev,before.st_ino) and
            after.st_uid==0 and after.st_mode==stat.S_IFDIR|0o755)
    return dict(device=after.st_dev,inode=after.st_ino,uid=after.st_uid,mode=after.st_mode)


def main():
    require(sys.platform=='linux' and os.geteuid()==0 and len(sys.argv)==3 and sys.argv[1]=='hosted-qualification')
    import workflows_linux_runtime as owned
    import workflows_native_admission_v3 as admission
    import workflows_cleanup_supervisor_v1 as supervisor
    require(owned.SCOPE is not None and not owned.SCOPE.closed)
    profile=candidate_check()
    candidate=sha((OUT/'native-component-profile.json').read_bytes())
    permit_path=Path(sys.argv[2]);permit,permit_raw=admission.read_json(permit_path)
    expiry=admission.validate(permit,'hosted-qualification',REPO,BASE,candidate)
    root=OUT/('native-helper-'+permit['leaseId']);parent_custody=create_helper_parent(root)
    journal=None;slot=None;failure=None;cleanup=None;rows=[];phases={};journal_bytes=0;frozen=None;frozen_proof=None
    deadline=min(owned.SCOPE.deadline,time.monotonic()+min(600,(expiry-datetime.now(timezone.utc)).total_seconds()-25))
    require(time.monotonic()<deadline)
    def event(kind,row):
        nonlocal journal_bytes
        rows.append(dict(row))
        raw=(json.dumps(dict(event=kind,resource=row))+'\n').encode()
        require(journal_bytes+len(raw)<=256*1024)
        require(journal.write(raw)==len(raw));os.fsync(journal.fileno());journal_bytes+=len(raw)
    def recheck():
        current,raw=admission.read_json(permit_path);require(raw==permit_raw)
        admission.validate(current,'hosted-qualification',REPO,BASE,candidate)
        candidate_check()
        if frozen is not None:verify_frozen_sources(frozen,frozen_proof)
        if slot is not None:slot.verify()
        admission.preflight()
        require(time.monotonic()<deadline)
    def command(name,argv,timeout,binding=None):
        recheck()
        result,row=owned.run_owned(argv,cwd=SOURCE,timeout=min(timeout,deadline-time.monotonic()),
            memory_limit=CAPS['memoryBytes'],cpu_rate=5000,output_limit=CAPS['outputBytes'],
            log_path=root/(name+'.log'),on_event=event,
            env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C'},
            native_binding=binding,native_lease=permit['leaseId'] if binding else None)
        rows.append(dict(row))
        (root/(name+'-stdout.log')).write_bytes(result.stdout)
        (root/(name+'-stderr.log')).write_bytes(result.stderr)
        require(result.returncode==0 and result.stderr==b'' and not row['output_truncated'])
        require(row['remaining_job_processes']==0 and all(row.get(key) is True for key in FLAGS))
        candidate_check()
        return result,row
    try:
        journal=(root/'resources.jsonl').open('xb',buffering=0)
        recheck()
        slot=admission.Lease({**permit,**admission.owner_identity(),'purpose':'fixed native C component compile/ABI/kernel cases',
                              'persistentData':False})
        head,_=command('base-head',['/usr/bin/git','rev-parse','HEAD'],10)
        require(head.stdout.decode().strip()==BASE)
        frozen,frozen_proof=freeze_sources(root,profile['sourcePins'])
        write_evidence(root/'frozen-source-custody.json',frozen_proof)
        version,compiler=command('compiler-identity',['/usr/bin/cc','--version'],10)
        phases['compiler']=dict(sha256=compiler['executableSha256'],identity=compiler['executableIdentity'],versionSha256=sha(version.stdout))
        executable_dir=root/'executables';executable_dir.mkdir(mode=0o700);os.chown(executable_dir,owned.SCOPE.uid,owned.SCOPE.gid)
        for number,argv in enumerate(compile_commands(executable_dir,frozen),1):
            _,row=command('compile-'+str(number),argv,60)
            require(row['executableSha256']==compiler['executableSha256'])
        require({p.name for p in executable_dir.iterdir()}=={'test_program_child','libmaliev_test_program_child.so'})
        binding=dict(leaseId=permit['leaseId'],sourceIndexSha256=SOURCE_INDEX,headerSha256=native.NATIVE_HEADER)
        binding['executable']=checked_file(executable_dir/'test_program_child',owned.SCOPE.uid,0o555)
        binding['library']=checked_file(executable_dir/'libmaliev_test_program_child.so',owned.SCOPE.uid,0o444)
        os.chown(executable_dir,0,0);os.chmod(executable_dir,0o555)
        info=executable_dir.stat(follow_symlinks=False)
        binding['directory']=dict(device=info.st_dev,inode=info.st_ino,uid=info.st_uid,mode=info.st_mode)
        executable=binding['executable']['path'];native.shape(binding,executable,permit['leaseId'])
        write_evidence(root/'fresh-elf-binding.json',binding)
        phases['compile']=dict(commands=2,warnings=0,errors=0,sourceIndexSha256=SOURCE_INDEX)
        result,row=command('actual-c-abi',[executable,'--abi'],10,binding)
        phases['abi']=readback.abi(result.stdout)
        write_evidence(root/'actual-c-abi.json',phases['abi'])
        result,row=command('actual-kernel-cases',[executable],60,binding)
        phases['kernelCases']=readback.journal(result.stdout,row['pid'],executable)
        write_evidence(root/'strict-kernel-cases.json',phases['kernelCases'])
    except BaseException as error:
        failure=error
        if getattr(error,'resource_row',None) is not None:rows.append(dict(error.resource_row))
        slot=getattr(error,'resource_lease',slot)
    finally:
        def checkpoint(kind,state):
            # Fixed single file: latest cleanup custody; no renewed work grant.
            raw=(json.dumps(dict(kind=kind,state=state))+'\n').encode();require(len(raw)<=256*1024)
            with (root/'cleanup-state.json').open('wb') as stream:
                require(stream.write(raw)==len(raw));stream.flush();os.fsync(stream.fileno())
        def recover(lease):
            rows.append(dict(owned.recover_quarantined(lease,deadline=owned.supervision_boundary())))
        def settle():
            return supervisor.supervise(owned._quarantined,recover,slot,journal,checkpoint,
                                        absolute_deadline=owned.supervision_boundary())
        def receipt(state,primary,secondary):
            write_evidence(root/'component-receipt.json',dict(profile=profile['profile'],candidateDigest=candidate,
                nativeSourceIndexSha256=SOURCE_INDEX,transportSourceIndexSha256=TRANSPORT_INDEX,
                permitSha256=sha(permit_raw),completedPhases=phases,resources=rows,cleanup=state,
                helperParentCustody=parent_custody,
                failureType=type(primary).__name__ if primary else None,secondaryFailureTypes=secondary,
                sdkExecuted=False,authProgramExecuted=False,factoryBound=False))
        failure,cleanup,secondary=finish_component(failure,settle,receipt,
                                                   lambda:journal.close() if journal is not None else None)
        if secondary:
            try:print(json.dumps(dict(primaryFailureType=type(failure).__name__,secondaryFailureTypes=secondary)),flush=True)
            except BaseException:pass  # Outer hosted wrapper still retains the primary exception.
    if failure is not None:raise failure
    require(cleanup['cleanupVerified'] and not owned._quarantined)


if __name__=='__main__':
    main()
