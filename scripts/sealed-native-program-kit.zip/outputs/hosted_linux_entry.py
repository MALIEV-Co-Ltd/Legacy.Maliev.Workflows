"""Linux selection for the existing protected sealed-static route."""
from datetime import datetime, timezone
import importlib
import json
import os
from pathlib import Path
import signal
import sys
import time

def cleanup_sdk_namespace(sdk, permit, parent_identity, deadline):
    from workflows_linux_trust import remaining, remove_owned_tree
    remaining(deadline)
    sdk=Path(sdk); parent=sdk.parent
    if not sdk.exists() and not sdk.is_symlink():
        if parent.exists():
            observed=parent.stat(follow_symlinks=False)
            if parent_identity is None or (observed.st_dev,observed.st_ino,observed.st_uid)!=parent_identity:
                raise ValueError('Unknown SDK parent custody; preserved')
            remaining(deadline);parent.rmdir()
        return True
    if sdk.resolve()!=sdk.absolute() or sdk.is_symlink(): raise ValueError('SDK path substitution; preserved')
    with (sdk/'.codex-sdk-owner.json').open('rb') as stream:raw=stream.read(4097)
    if len(raw)>4096:raise ValueError('SDK owner marker quota; preserved')
    def unique(pairs):
        value={}
        for key,item in pairs:
            if key in value:raise ValueError('Duplicate SDK marker; preserved')
            value[key]=item
        return value
    owner=json.loads(raw,object_pairs_hook=unique)
    if owner!={'owner':permit['owner'],'leaseId':permit['leaseId'],'expiresUtc':permit['expiresUtc'],'persistentData':False}:
        raise ValueError('Unknown SDK ownership; preserved')
    observed=parent.stat(follow_symlinks=False)
    if parent_identity is None or (observed.st_dev,observed.st_ino,observed.st_uid)!=parent_identity:
        raise ValueError('SDK parent substitution; preserved')
    observed=sdk.stat(follow_symlinks=False)
    remove_owned_tree(sdk,(observed.st_dev,observed.st_ino,observed.st_uid),deadline)
    record=parent/'sdk-bootstrap-record.json'
    if record.exists() or record.is_symlink():
        row=record.stat(follow_symlinks=False)
        if record.is_symlink() or not record.is_file() or row.st_uid!=parent_identity[2] or row.st_size>65536:
            raise ValueError('Unknown bootstrap receipt custody; preserved')
        remaining(deadline);record.unlink()
    remaining(deadline);parent.rmdir()
    return True

def emit_bounded_receipt(path, value):
    data=json.dumps(value,indent=2).encode('utf-8')
    if len(data)>256*1024:raise ValueError('Wrapper receipt bound')
    try:
        with Path(path).open('wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    except BaseException:
        print(data.decode('utf-8'),flush=True)  # Required recovery evidence if the file channel itself fails.
        raise

def retained_relay_metadata(scope):
    from workflows_private_docker_proxy_v1 import retain_relay_metadata, relay_metadata_evidence
    try:
        retained=getattr(scope,'relay_metadata_retained',None)
        if retained is None:return relay_metadata_evidence(getattr(scope,'proxy',None))
        return retain_relay_metadata(retained)
    except BaseException:return dict(schema=1,available=False,reason='snapshotUnavailable')

def main(transport, entries):
    if sys.platform != 'linux' or os.geteuid() != 0: raise ValueError('Linux root custody required')
    trusted = Path(__file__).resolve().parent
    policy = json.loads(transport.selected_policy_path(trusted).read_bytes(), object_pairs_hook=transport.unique)
    raw = os.environ['ROOT_STATIC_PERMIT'].encode()
    permit = transport.validate_permit(raw, policy)
    context = json.loads(os.environ['TRUSTED_WORKFLOW_CONTEXT'], object_pairs_hook=transport.unique)
    outputs, worktree = Path(policy['outputsRoot']), Path(policy['worktree'])
    namespace = outputs.parent
    if namespace.exists() or namespace.is_symlink(): raise ValueError('Fresh Linux namespace required')
    uid, gid = int(os.environ['MALIEV_WORKFLOWS_UID']), int(os.environ['MALIEV_WORKFLOWS_GID'])
    if uid < 1000 or gid <= 0: raise ValueError('Original unprivileged hosted identity required')
    import pwd
    if pwd.getpwuid(uid).pw_gid != gid: raise ValueError('Hosted primary group association required')
    namespace.mkdir(mode=0o755); outputs.mkdir(mode=0o755)
    os.chmod(namespace,0o755);os.chmod(outputs,0o755)
    for name, data in entries.items():
        if name.startswith('outputs/'): transport.safe_write(outputs, name[8:], data)
    for name, pin in policy['linuxHelpers'].items():
        if transport.digest((outputs/name).read_bytes()) != pin: raise ValueError('Linux helper pin')
    sys.path.insert(0, str(outputs))
    owned = importlib.import_module('workflows_linux_runtime')
    expiry = datetime.fromisoformat(permit['expiresUtc'])
    remaining = (expiry-datetime.now(timezone.utc)).total_seconds()-25
    if remaining <= 0: raise ValueError('Finite Linux deadline unavailable')
    deadline = time.monotonic()+min(600, remaining)
    ledger, failure = [], None
    cleanup = None
    sdk_parent_identity=None
    cleaning_up=False
    previous_handlers={}
    def cancelled(number, frame):
        nonlocal failure
        error=KeyboardInterrupt('Hosted qualification cancelled')
        if cleaning_up:
            if failure is None:failure=error
        else:raise error
    for number in (signal.SIGINT,signal.SIGTERM):
        previous_handlers[number]=signal.signal(number,cancelled)
    try:
        proof = owned.begin(deadline, namespace/'private-docker', uid, gid)
        (outputs/'linux-capability.json').write_text(json.dumps(proof, indent=2))
        def command(name, argv, cwd, timeout=30):
            return transport.preparation_command(owned.run_owned, ledger, argv, cwd=cwd,
                timeout=min(timeout, deadline-time.monotonic()), memory_limit=256*1024**2,
                output_limit=4*1024**2, log_path=outputs/(name+'.log'))
        head = command('trusted-head', ['git','rev-parse','HEAD'], trusted.parent).decode().strip()
        transport.validate_context(context, head)
        worktree.mkdir(mode=0o755); os.chown(worktree, uid, gid)
        command('candidate-checkout', ['git','-c','core.autocrlf=true','worktree','add',
                '--detach',str(worktree),policy['baseSha']], trusted.parent)
        for name, data in entries.items():
            if name.startswith('worktree/'): transport.safe_write(worktree, name[9:], data)
        for path in [worktree, *worktree.rglob('*')]:
            if path.is_symlink(): raise ValueError('Candidate ownership escape')
            os.chown(path, uid, gid)
        del entries
        cache = outputs/'hosted-cache'; cache.mkdir(exist_ok=True); os.chown(cache, uid, gid)
        sdk_parent = namespace/'private-sdk'
        from workflows_linux_owned_scope_v1 import registration_window
        with registration_window():
            sdk_parent.mkdir(); os.chown(sdk_parent, uid, gid)
            observed=sdk_parent.stat(follow_symlinks=False)
            sdk_parent_identity=(observed.st_dev,observed.st_ino,observed.st_uid)
        (outputs/'root-hosted-static-permit.json').write_bytes(raw)
        # Authority and sealed helper files remain controller-owned. Only the
        # separate cache, SDK namespace and phase results are writable by SDK.
        os.chmod(outputs,0o755)
        bootstrap = outputs/'hosted_linux_sdk_bootstrap.py'
        command('sdk-bootstrap', [sys.executable,'-B',str(bootstrap)], trusted.parent, timeout=300)
        with (sdk_parent/'sdk-bootstrap-record.json').open('rb') as stream:
            bootstrap_record=stream.read(65537)
        if len(bootstrap_record)>65536:raise ValueError('Bootstrap receipt bound')
        (outputs/'sdk-bootstrap-record.json').write_bytes(bootstrap_record)
        core = importlib.import_module('hosted_native_program_core')
        if transport.digest((outputs/'hosted_native_program_core.py').read_bytes()) != policy['coreSha256']:
            raise ValueError('Native core pin')
        identity = []
        for name, pin in core.SDK_FILES.items():
            path = Path(name)
            if transport.digest(path.read_bytes()) != pin: raise ValueError('Linux SDK file pin')
            identity.append({'file':name,'sha256':pin,'bytes':path.stat().st_size})
        (outputs/'sdk-identity.json').write_text(json.dumps({'isolated':identity,'allFiveMatch':True}))
        core.candidate_check()
        sys.argv = [str(outputs/'hosted_native_program_core.py'),'hosted-qualification',str(outputs/'root-hosted-static-permit.json')]
        core.main()
    except BaseException as error:
        failure = error
    finally:
        cleaning_up=True
        # One fixed reserve covers groups, proxy/thread settlement, HOME and SDK deletion.
        cleanup_deadline=min(deadline+25,time.monotonic()+25,
                             getattr(owned.SCOPE,'cleanup_deadline',None) or deadline+25)
        state={'kernel':None,'sdkRootRemoved':None,'cleanupFailures':[],'cleanupDeadline':cleanup_deadline}
        first_cleanup_error=None
        def clean():
            nonlocal first_cleanup_error
            def collect(name, operation):
                nonlocal first_cleanup_error
                try:return operation()
                except BaseException as error:
                    state['cleanupFailures'].append({'operation':name,'type':type(error).__name__})
                    if first_cleanup_error is None:first_cleanup_error=error
                    return None
            state['kernel']=collect('owned-groups-proxy-home',lambda:owned.finish(cleanup_deadline))
            if first_cleanup_error is None:
                state['sdkRootRemoved']=collect('sdk-namespace',lambda:cleanup_sdk_namespace(
                    namespace/'private-sdk/sdk',permit,sdk_parent_identity,cleanup_deadline))
            if first_cleanup_error is not None:raise first_cleanup_error
            return state
        def receipt(ignored, errors):
            emit_bounded_receipt(outputs/'wrapper-receipt.json',{
                'leaseId':permit['leaseId'],
                'failureType':type(failure or first_cleanup_error).__name__ if failure or first_cleanup_error else None,
                'cleanup':state,'cleanupFailureTypes':errors,
                'quarantineContainment':getattr(owned.SCOPE,'quarantine_containment',None),
                'controllerReaderCleanup':getattr(owned.SCOPE,'controller_reader_cleanup',None),
                'relayMetadata':retained_relay_metadata(owned.SCOPE),
                'resources':ledger,'historicalBuildOrTestsReplayed':False})
        try:
            transport.preserve_first_failure(failure,clean,receipt)
            if failure is not None:raise failure
        finally:
            for number,previous in previous_handlers.items():signal.signal(number,previous)
