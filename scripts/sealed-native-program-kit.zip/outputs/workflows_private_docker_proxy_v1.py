"""Finite Unix Docker API relay. Backend access is confined to verified SDK peers.

This helper requires an already admitted Linux owner/cgroup; it grants no authority.
It never logs API bodies, Docker environment or customer data.
"""
import os
import json
import re
from pathlib import Path
import selectors
import socket
import stat
import struct
import threading
import time

MAX_CLIENTS=32
MAX_CONNECTION_BYTES=32*1024*1024
MAX_RUN_BYTES=128*1024*1024
MAX_PENDING_BYTES=64*1024
MAX_METADATA_CONNECTIONS=32
MAX_METADATA_BYTES=32*1024
METADATA_COVERAGE='metadata of relayed connections; Linux admission requires actual owner evidence'
METADATA_STAGES={'peerCredentials','peerObservation','backendConnect','relayIO'}

def retain_relay_metadata(value):
    """Closed-schema, bounded observation; rejection never replaces cleanup."""
    def number(item,maximum=(1<<63)-1):
        require(type(item) is int and 0<=item<=maximum)
    def exception_type(item):
        require(type(item) is str and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,63}',item) is not None)
    def failure(item):
        if item is None:return
        require(type(item) is dict and len(item)==2 and set(item)=={'stage','type'}
                and type(item['stage']) is str and item['stage'] in METADATA_STAGES)
        exception_type(item['type'])
    try:
        if value is None:return dict(schema=1,available=False,reason='notAcquired')
        require(type(value) is dict and len(value)<=7 and type(value.get('schema')) is int and value['schema']==1
                and type(value.get('available')) is bool)
        if set(value)=={'schema','available','failureType'}:
            require(value['available'] is False);exception_type(value['failureType'])
        elif set(value)=={'schema','available','reason'}:
            require(value['available'] is False and type(value['reason']) is str
                    and value['reason'] in {'notAcquired','snapshotUnavailable','validationRejected'})
        else:
            require(set(value)=={'schema','available','coverage','maxRetainedConnections','totals','firstFailure','connections'})
            require(type(value['coverage']) is str and value['coverage']==METADATA_COVERAGE
                    and type(value['maxRetainedConnections']) is int
                    and value['maxRetainedConnections']==MAX_METADATA_CONNECTIONS)
            totals=value['totals']
            require(type(totals) is dict and len(totals)==9 and set(totals)=={'connections','peerAdmitted','backendConnected','settled',
                'clientRead','backendRead','clientWritten','backendWritten','droppedRecords'})
            for key,item in totals.items():
                number(item,MAX_RUN_BYTES if key in {'clientRead','backendRead','clientWritten','backendWritten'} else (1<<63)-1)
            rows=value['connections']
            require(type(rows) is list and len(rows)<=MAX_METADATA_CONNECTIONS)
            require(totals['connections']==len(rows)+totals['droppedRecords']
                    and totals['backendConnected']<=totals['peerAdmitted']<=totals['connections']
                    and totals['settled']<=totals['connections']
                    and totals['clientRead']+totals['backendRead']<=MAX_RUN_BYTES
                    and totals['clientWritten']<=totals['backendRead']
                    and totals['backendWritten']<=totals['clientRead'])
            failure(value['firstFailure']);seen=set()
            for row in rows:
                require(type(row) is dict and len(row)==18 and set(row)=={'connection','stage','pid','startTicks','peerAdmitted',
                    'backendConnected','clientRead','backendRead','clientWritten','backendWritten',
                    'clientPendingPeak','backendPendingPeak','clientEOF','backendEOF','clientWriteClosed',
                    'backendWriteClosed','terminal','failure'})
                number(row['connection']);require(row['connection']>0 and row['connection'] not in seen)
                seen.add(row['connection'])
                require(type(row['stage']) is str and row['stage'] in METADATA_STAGES)
                for key in ('peerAdmitted','backendConnected','clientEOF','backendEOF','clientWriteClosed','backendWriteClosed'):
                    require(type(row[key]) is bool)
                require(not row['backendConnected'] or row['peerAdmitted'])
                if row['pid'] is None or row['startTicks'] is None:
                    require(row['pid'] is row['startTicks'] is None and not row['peerAdmitted'])
                else:
                    number(row['pid']);number(row['startTicks']);require(row['pid']>0 and row['startTicks']>0)
                for key in ('clientRead','backendRead','clientWritten','backendWritten'):number(row[key],MAX_RUN_BYTES)
                require(row['clientRead']+row['backendRead']<=MAX_RUN_BYTES
                        and row['clientWritten']<=row['backendRead'] and row['backendWritten']<=row['clientRead'])
                for key in ('clientPendingPeak','backendPendingPeak'):number(row[key],MAX_PENDING_BYTES)
                require(row['terminal'] is None or (type(row['terminal']) is str and row['terminal'] in {'eof','fenced','failure'}))
                failure(row['failure'])
        raw=json.dumps(value,indent=2,ensure_ascii=True,allow_nan=False).encode('utf-8')
        require(len(raw)<=MAX_METADATA_BYTES)
        return json.loads(raw)
    except BaseException:
        return dict(schema=1,available=False,reason='validationRejected')

def relay_metadata_evidence(proxy):
    """Best effort snapshot even when custody cleanup raises; no new authority."""
    if proxy is None:return retain_relay_metadata(None)
    try:return retain_relay_metadata(proxy.metadata_snapshot())
    except BaseException:return dict(schema=1,available=False,reason='snapshotUnavailable')

def require(value):
    if not value:raise RuntimeError('Private Docker socket custody refused.')

def verify_peer(peer,observation,uid,gid,sdk_group):
    require(type(peer) is tuple and len(peer)==3 and all(type(v) is int for v in peer))
    pid,actual_uid,actual_gid=peer
    require(pid>0 and actual_uid==uid and actual_gid==gid and uid>=1000 and gid>0)
    require(set(observation)=={'pid','uid','gid','startTicks','cgroup','retainedGroupIdentityVerified'})
    require(observation['pid']==pid and observation['uid']==uid and observation['gid']==gid
            and type(observation['startTicks']) is int and observation['startTicks']>0
            and observation['retainedGroupIdentityVerified'] is True)
    group=observation['cgroup']
    require(type(group) is str and type(sdk_group) is str and sdk_group.startswith('/')
            and (group==sdk_group or group.startswith(sdk_group+'/')))
    return (pid,observation['startTicks'])

class PrivateDockerProxy:
    def __init__(self,front,backend,uid,gid,sdk_group,observe_peer,deadline):
        require(os.name=='posix' and hasattr(socket,'SO_PEERCRED'))
        self.front,self.backend=Path(front),Path(backend)
        require(self.front.is_absolute() and self.backend.is_absolute() and self.front!=self.backend)
        require(not self.front.exists() and not self.front.is_symlink())
        require(self.front.parent.resolve()==self.front.parent and self.backend.parent.resolve()==self.backend.parent)
        private=self.backend.parent.stat()
        require(private.st_uid==0 and stat.S_IMODE(private.st_mode)==0o700)
        require(0<deadline-time.monotonic()<=600)
        self.uid,self.gid,self.sdk_group=uid,gid,sdk_group
        self.observe,self.deadline=observe_peer,deadline
        self.lock=threading.RLock();self.closed=threading.Event()
        self.listener=None;self.listener_thread=None;self.identity=None
        self.workers={};self.sockets={};self.bytes=0;self.failure=None;self.next_client=0
        self.started=False
        self._initialize_metadata()

    def _initialize_metadata(self):
        # Observations contain counts and exact peer birth only, never HTTP,
        # environment, exception messages, paths or customer/API content.
        self.metadata_connections={}
        self.metadata_totals=dict(connections=0,peerAdmitted=0,backendConnected=0,
                                  settled=0,clientRead=0,backendRead=0,
                                  clientWritten=0,backendWritten=0,droppedRecords=0)
        self.metadata_first_failure=None
        self.metadata_unavailable=False

    def _metadata_open(self,key):
        try:
            with self.lock:
                self.metadata_totals['connections']+=1
                if len(self.metadata_connections)>=MAX_METADATA_CONNECTIONS:
                    self.metadata_totals['droppedRecords']+=1;return
                self.metadata_connections[key]=dict(connection=key,stage='peerCredentials',
                    pid=None,startTicks=None,peerAdmitted=False,backendConnected=False,
                    clientRead=0,backendRead=0,clientWritten=0,backendWritten=0,
                    clientPendingPeak=0,backendPendingPeak=0,clientEOF=False,backendEOF=False,
                    clientWriteClosed=False,backendWriteClosed=False,terminal=None,failure=None)
        except BaseException:self.metadata_unavailable=True

    def _metadata_update(self,key,**values):
        try:
            with self.lock:
                record=self.metadata_connections.get(key)
                if record is not None:record.update(values)
        except BaseException:self.metadata_unavailable=True

    def _metadata_count(self,key,field,count,pending=None):
        try:
            with self.lock:
                self.metadata_totals[field]+=count
                record=self.metadata_connections.get(key)
                if record is not None:
                    if field in record and type(record[field]) is int:record[field]+=count
                    if pending is not None:
                        label='backendPendingPeak' if field=='clientRead' else 'clientPendingPeak'
                        record[label]=max(record[label],pending)
        except BaseException:self.metadata_unavailable=True

    def _metadata_failure(self,key,stage,error):
        try:
            name=type(error).__name__[:64]
            with self.lock:
                failure=dict(stage=stage,type=name)
                if self.metadata_first_failure is None:self.metadata_first_failure=failure
                record=self.metadata_connections.get(key)
                if record is not None:record['failure']=failure
        except BaseException:self.metadata_unavailable=True

    def metadata_snapshot(self):
        # The controller may retain this bounded snapshot before deleting its
        # private namespace. This relay adds no file, logging worker or broker.
        try:
            with self.lock:
                return dict(schema=1,available=not self.metadata_unavailable,
                    coverage=METADATA_COVERAGE,
                    maxRetainedConnections=MAX_METADATA_CONNECTIONS,
                    totals=dict(self.metadata_totals),
                    firstFailure=dict(self.metadata_first_failure) if self.metadata_first_failure else None,
                    connections=[dict(row,failure=dict(row['failure']) if row['failure'] else None)
                                 for row in self.metadata_connections.values()])
        except BaseException as error:
            return dict(schema=1,available=False,failureType=type(error).__name__[:64])

    def start(self):
        require(not self.started)
        self.listener=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
        try:
            self.listener.bind(str(self.front))
            created=self.front.stat()
            require(stat.S_ISSOCK(created.st_mode))
            self.identity=(created.st_dev,created.st_ino)
            os.chown(self.front,0,self.gid);os.chmod(self.front,0o660)
            self.listener.listen(MAX_CLIENTS);self.listener.settimeout(.2)
            self.started=True
            self.listener_thread=threading.Thread(target=self._accept,name='owned-private-docker-proxy',daemon=False)
            self.listener_thread.start()
        except BaseException:
            self.stop()
            raise

    def _fail(self,error):
        with self.lock:
            if self.failure is None:self.failure=type(error).__name__
        self.closed.set()

    def _accept(self):
        try:
            while not self.closed.is_set():
                require(time.monotonic()<self.deadline)
                try:client,_=self.listener.accept()
                except socket.timeout:continue
                except OSError:
                    if self.closed.is_set():break
                    raise
                with self.lock:
                    # Retain each handle until observed terminal and joined.
                    for key,worker in list(self.workers.items()):
                        if not worker.is_alive():
                            worker.join(0)
                            require(key not in self.sockets)
                            del self.workers[key]
                    if self.closed.is_set() or len(self.workers)>=MAX_CLIENTS:
                        client.close();raise RuntimeError('Private client admission closed or capacity reached')
                    self.next_client+=1;key=self.next_client
                    self.sockets[key]=[client]
                    worker=threading.Thread(target=self._relay,args=(key,client),name='owned-private-docker-client',daemon=False)
                    self.workers[key]=worker
                    try:worker.start()
                    except BaseException:
                        client.close();self.sockets.pop(key);self.workers.pop(key);raise
        except BaseException as error:self._fail(error)

    def _relay(self,key,client):
        selector=None;backend=None
        stage='peerCredentials';terminal='fenced'
        self._metadata_open(key)
        try:
            peer=struct.unpack('3i',client.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,struct.calcsize('3i')))
            stage='peerObservation';self._metadata_update(key,stage=stage)
            birth=verify_peer(peer,self.observe(peer[0]),self.uid,self.gid,self.sdk_group)
            require(not self.closed.is_set() and time.monotonic()<self.deadline)
            # Re-observe exact peer birth/group immediately before any backend call.
            require(verify_peer(peer,self.observe(peer[0]),self.uid,self.gid,self.sdk_group)==birth)
            self._metadata_count(key,'peerAdmitted',1)
            self._metadata_update(key,pid=birth[0],startTicks=birth[1],peerAdmitted=True)
            stage='backendConnect';self._metadata_update(key,stage=stage)
            backend=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
            with self.lock:self.sockets[key].append(backend)
            backend.settimeout(min(1,max(.001,self.deadline-time.monotonic())))
            backend.connect(str(self.backend))
            self._metadata_count(key,'backendConnected',1)
            self._metadata_update(key,backendConnected=True)
            client.setblocking(False);backend.setblocking(False)
            selector=selectors.DefaultSelector()
            streams=(client,backend)
            other={client:backend,backend:client}
            pending={client:bytearray(),backend:bytearray()}
            read_open={client:True,backend:True}
            write_open={client:True,backend:True}
            connection_bytes=0
            stage='relayIO';self._metadata_update(key,stage=stage)
            while not self.closed.is_set():
                require(time.monotonic()<self.deadline)
                for stream in streams:
                    destination=other[stream]
                    if not read_open[destination] and not pending[stream] and write_open[stream]:
                        stream.shutdown(socket.SHUT_WR);write_open[stream]=False
                        self._metadata_update(key,**{'clientWriteClosed' if stream is client else 'backendWriteClosed':True})
                    mask=0
                    if read_open[stream] and len(pending[destination])<MAX_PENDING_BYTES:
                        mask|=selectors.EVENT_READ
                    if pending[stream]:mask|=selectors.EVENT_WRITE
                    try:selector.get_key(stream);registered=True
                    except KeyError:registered=False
                    if mask and registered:selector.modify(stream,mask)
                    elif mask:selector.register(stream,mask)
                    elif registered:selector.unregister(stream)
                if not any(read_open.values()) and not any(pending.values()):
                    terminal='eof';return
                for event,mask in selector.select(.2):
                    stream=event.fileobj;destination=other[stream]
                    if mask&selectors.EVENT_READ:
                        try:data=stream.recv(MAX_PENDING_BYTES-len(pending[destination]))
                        except BlockingIOError:data=None
                        except (BrokenPipeError,ConnectionResetError) as error:
                            if stream is not client:raise
                            terminal='failure';self._metadata_failure(key,stage,error);return
                        if data==b'':
                            read_open[stream]=False
                            self._metadata_update(key,**{'clientEOF' if stream is client else 'backendEOF':True})
                        elif data:
                            connection_bytes+=len(data)
                            with self.lock:
                                self.bytes+=len(data)
                                require(connection_bytes<=MAX_CONNECTION_BYTES and self.bytes<=MAX_RUN_BYTES)
                            pending[destination].extend(data)
                            self._metadata_count(key,'clientRead' if stream is client else 'backendRead',len(data),len(pending[destination]))
                    if mask&selectors.EVENT_WRITE:
                        try:sent=stream.send(pending[stream])
                        except BlockingIOError:continue
                        except (BrokenPipeError,ConnectionResetError) as error:
                            if stream is not client:raise
                            terminal='failure';self._metadata_failure(key,stage,error);return
                        require(sent>0);del pending[stream][:sent]
                        self._metadata_count(key,'clientWritten' if stream is client else 'backendWritten',sent)
        except (OSError,RuntimeError) as error:
            if self.closed.is_set():terminal='fenced'
            else:
                terminal='failure';self._metadata_failure(key,stage,error);self._fail(error)
        except BaseException as error:
            terminal='failure';self._metadata_failure(key,stage,error);self._fail(error)
        finally:
            if selector is not None:selector.close()
            for stream in (client,backend):
                if stream is not None:stream.close()
            with self.lock:self.sockets.pop(key,None)
            self._metadata_count(key,'settled',1)
            self._metadata_update(key,terminal=terminal)
            # Keep the thread handle until the owner joins it; completed is not joined.

    def request_fence(self):
        # Cancellation never waits or renews a lease. Joining and a truthful
        # settlement receipt still require the original remaining deadline.
        self.closed.set()
        if self.listener is not None:self.listener.close()
        with self.lock:streams=[s for owned in self.sockets.values() for s in owned]
        for stream in streams:
            try:stream.shutdown(socket.SHUT_RDWR)
            except OSError:pass
    def fence_and_settle(self,seconds=20):
        require(0<seconds<=20)
        end=time.monotonic()+seconds
        self.request_fence()
        if self.listener_thread is not None:self.listener_thread.join(max(0,end-time.monotonic()))
        with self.lock:workers=list(self.workers.values())
        for worker in workers:worker.join(max(0,end-time.monotonic()))
        require(self.listener_thread is None or not self.listener_thread.is_alive())
        require(all(not worker.is_alive() for worker in workers))
        with self.lock:
            require(not self.sockets)
            self.workers.clear()
        return dict(admissionFenced=True,activeClients=0,workersJoined=True,relayBytes=self.bytes,failure=self.failure,
                    relayMetadata=relay_metadata_evidence(self))

    def stop(self,seconds=20):
        receipt=self.fence_and_settle(seconds)
        if self.identity is not None:
            observed=self.front.stat()
            require((observed.st_dev,observed.st_ino)==self.identity and stat.S_ISSOCK(observed.st_mode))
            self.front.unlink()
            require(not self.front.exists())
        return receipt
