"""Official Linux SDK data extraction. No SDK execution or authority issuance."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import time
import urllib.request

URL = 'https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.401/dotnet-sdk-10.0.401-linux-x64.tar.gz'
ARCHIVE_BYTES = 240059572
ARCHIVE_SHA512 = '51c8b999af9e8dd9998c9edc5944e19a90788862068acd38694e098889054ce8c23d4f0c5cccfa16bf187d044562359e5ee69a9f8ad0bbe913ba90311fbce25b'
SDK_ROOT = Path('/tmp/maliev-workflows-qualification/private-sdk/sdk')
OUT = Path('/tmp/maliev-workflows-qualification/outputs')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *args): raise ValueError('Official SDK redirect refused')

def archive_plan(source):
    seen = set(); members = []; total = 0
    for member in source:
        name = member.name
        while name.startswith('./'): name = name[2:]
        if name in ('', '.') and member.isdir(): continue
        if (not name or '\\' in name or ':' in name or PurePosixPath(name).is_absolute()
                or any(part in ('', '.', '..') for part in name.split('/'))
                or name in seen or any(ord(char) < 32 for char in name)
                or not (member.isdir() or member.isreg()) or member.mode & 0o7022
                or not 0 <= member.size <= 128*1024**2):
            raise ValueError('SDK archive path/type/mode/quota')
        seen.add(name); total += member.size; members.append((member, name))
        if len(seen) > 30000 or total > 2*1024**3: raise ValueError('SDK expansion quota')
    regular = {name for member, name in members if member.isreg()}
    if 'dotnet' not in regular: raise ValueError('SDK executable missing')
    if any('/'.join(name.split('/')[:i]) in regular for name in seen for i in range(1, len(name.split('/')))):
        raise ValueError('SDK file/directory collision')
    return members

def main():
    permit = json.loads((OUT/'root-hosted-static-permit.json').read_bytes())
    expiry = datetime.fromisoformat(permit['expiresUtc'])
    deadline = min(time.monotonic()+300,
                   time.monotonic()+(expiry-datetime.now(timezone.utc)).total_seconds()-25)
    if SDK_ROOT.exists() or time.monotonic() >= deadline: raise ValueError('Fresh finite SDK required')
    archive = SDK_ROOT.parent/'official-linux-sdk.tar.gz'; size = 0; sha = hashlib.sha512()
    try:
        with urllib.request.build_opener(NoRedirect()).open(URL, timeout=25) as response, archive.open('xb') as target:
            while block := response.read(1024**2):
                if time.monotonic() >= deadline: raise TimeoutError('SDK bootstrap deadline')
                size += len(block)
                if size > ARCHIVE_BYTES: raise ValueError('SDK download quota')
                sha.update(block); target.write(block)
        if size != ARCHIVE_BYTES or sha.hexdigest() != ARCHIVE_SHA512: raise ValueError('Official SDK archive differs')
        with tarfile.open(archive, 'r:gz') as source:
            members = archive_plan(source)
            SDK_ROOT.mkdir(mode=0o755)
            (SDK_ROOT/'.codex-sdk-owner.json').write_text(json.dumps({
                'owner':permit['owner'], 'leaseId':permit['leaseId'],
                'expiresUtc':permit['expiresUtc'], 'persistentData':False}))
            for member, name in members:
                if time.monotonic() >= deadline: raise TimeoutError('SDK extraction deadline')
                target = SDK_ROOT/name
                if not target.resolve().is_relative_to(SDK_ROOT.resolve()) or target.is_symlink():
                    raise ValueError('SDK extraction escape')
                if member.isdir(): target.mkdir(parents=True, exist_ok=True)
                else:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    with source.extractfile(member) as data, target.open('xb') as output:
                        copied = 0
                        while block := data.read(1024**2):
                            if time.monotonic() >= deadline: raise TimeoutError('SDK extraction deadline')
                            copied += len(block); output.write(block)
                    if copied != member.size: raise ValueError('SDK member truncated')
                    os.chmod(target, member.mode)
        (SDK_ROOT.parent/'sdk-bootstrap-record.json').write_text(json.dumps({
            'url':URL, 'bytes':size, 'sha512':sha.hexdigest(), 'officialArchiveMatched':True,
            'sdkExecuted':False, 'archiveMembers':len(members)}))
    finally:
        archive.unlink(missing_ok=True)

if __name__ == '__main__': main()
