"""Cooperative finite admission, not a cryptographic authorization boundary."""
import ctypes
from ctypes import wintypes as W
from datetime import datetime, timezone
import json
import os
import sys
from pathlib import Path
import uuid
from workflows_snapshot_census_v3 import SnapshotController

OWNER = '01a1009c-83f6-7010-9a59-df89ecbb1b1f'
ROOT = '019fc21e-50f0-7112-834f-9fb3b35b9dfe'
SLOT = Path('/tmp/maliev-workflows-qualification/sdk-exclusive-slot.json') if sys.platform == 'linux' else Path('D:/codex-temp/2026-10-03/maliev-native-sdk-exclusive-slot.json')
RELEVANT_SDK_EXECUTABLES = {'dotnet.exe', 'msbuild.exe', 'testhost.exe', 'testhost.x86.exe', 'vstest.console.exe', 'vbcscompiler.exe', 'csc.exe', 'vbc.exe', 'fsc.exe', 'fsi.exe'}

def filter_sdk_processes(rows, allowed_owned_pid=None):
    return [row for row in rows if row[1].lower() in RELEVANT_SDK_EXECUTABLES and row[0] != allowed_owned_pid]


def owner_identity():
    if sys.platform == 'linux':
        from workflows_linux_runtime import owner_identity as observed
        return observed()
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    k.GetCurrentProcess.restype = W.HANDLE
    k.GetProcessTimes.argtypes = [W.HANDLE] + [ctypes.POINTER(W.FILETIME)] * 4
    k.GetProcessTimes.restype = W.BOOL
    k.QueryFullProcessImageNameW.argtypes = [W.HANDLE, W.DWORD, W.LPWSTR, ctypes.POINTER(W.DWORD)]
    k.QueryFullProcessImageNameW.restype = W.BOOL
    current = k.GetCurrentProcess()  # Pseudo-handle; do not close.
    stamps = [W.FILETIME() for _ in range(4)]
    if not k.GetProcessTimes(current, *(ctypes.byref(v) for v in stamps)):
        raise ctypes.WinError(ctypes.get_last_error())
    name, length = ctypes.create_unicode_buffer(32768), W.DWORD(32768)
    if not k.QueryFullProcessImageNameW(current, 0, name, ctypes.byref(length)):
        raise ctypes.WinError(ctypes.get_last_error())
    return {'runnerPid':os.getpid(), 'runnerStartFiletime':(stamps[0].dwHighDateTime<<32)|stamps[0].dwLowDateTime,
            'runnerExecutable':name.value, 'ports':[], 'persistentData':False}

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key')
        result[key] = value
    return result

def read_json(path):
    with Path(path).open('rb') as stream:
        data = stream.read(4097)
    if len(data) > 4096:
        raise ValueError('Permit exceeds bound')
    return json.loads(data, object_pairs_hook=unique_object), data

def validate(permit, phase, worktree, base, candidate, now=None):
    required = {'issuedBy', 'owner', 'phase', 'leaseId', 'issuedUtc', 'expiresUtc',
                'worktree', 'baseSha', 'candidateSha'}
    if set(permit) != required or any(type(v) is not str for v in permit.values()):
        raise ValueError('Permit shape refused')
    expected = {'issuedBy': ROOT, 'owner': OWNER, 'phase': phase,
                'worktree': str(Path(worktree).resolve()), 'baseSha': base, 'candidateSha': candidate}
    if any(permit[k] != v for k, v in expected.items()):
        raise ValueError('Permit association refused')
    if str(uuid.UUID(permit['leaseId'])) != permit['leaseId']:
        raise ValueError('Noncanonical lease ID')
    issued = datetime.fromisoformat(permit['issuedUtc'])
    expiry = datetime.fromisoformat(permit['expiresUtc'])
    if issued.utcoffset() is None or expiry.utcoffset() is None:
        raise ValueError('Naive lease time refused')
    now = now or datetime.now(timezone.utc)
    if not issued <= now < expiry or not 0 < (expiry-issued).total_seconds() <= 900:
        raise ValueError('Lease unavailable')
    return expiry

def checked_inventory(first, advance, error, read):
    rows = []
    ok = first()
    while ok:
        rows.append(read())
        ok = advance()
    if error() != 18:
        raise RuntimeError('Process census incomplete')
    return rows

def preflight(allowed_owned_pid=None):
    if sys.platform == 'linux':
        from workflows_linux_runtime import preflight as observed
        return observed(allowed_owned_pid)
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    class Entry(ctypes.Structure):
        _fields_ = [('size', W.DWORD), ('usage', W.DWORD), ('pid', W.DWORD),
                    ('heap', ctypes.c_size_t), ('module', W.DWORD), ('threads', W.DWORD),
                    ('parent', W.DWORD), ('priority', W.LONG), ('flags', W.DWORD),
                    ('executable', W.WCHAR * 260)]
    class Memory(ctypes.Structure):
        _fields_ = [('length', W.DWORD), ('load', W.DWORD)] + [(n, ctypes.c_uint64) for n in
                     ('totalPhysical', 'availablePhysical', 'totalPage', 'availablePage',
                      'totalVirtual', 'availableVirtual', 'extendedVirtual')]
    k.CreateToolhelp32Snapshot.argtypes = [W.DWORD, W.DWORD]
    k.CreateToolhelp32Snapshot.restype = W.HANDLE
    for name in ('Process32FirstW', 'Process32NextW'):
        getattr(k, name).argtypes = [W.HANDLE, ctypes.POINTER(Entry)]
        getattr(k, name).restype = W.BOOL
    k.CloseHandle.argtypes = [W.HANDLE]
    k.CloseHandle.restype = W.BOOL
    k.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(Memory)]
    k.GlobalMemoryStatusEx.restype = W.BOOL
    # Prepare process identity, ledger and callbacks before acquiring the raw handle.
    owner = owner_identity()
    packet = Path(__file__).resolve().parent / ('snapshot-census-v3-' + str(uuid.uuid4()))
    packet.mkdir(exist_ok=False)
    entry = Entry()
    entry.size = ctypes.sizeof(entry)
    def checkpoint(kind, state):
        body = json.dumps(dict(kind=kind, owner=owner, resource=state,
            observedUtc=datetime.now(timezone.utc).isoformat(), purpose='process inventory; cleanup-only handle ownership',
            persistentData=False)).encode()
        if len(body) > 64 * 1024:
            raise RuntimeError('Snapshot checkpoint bound exceeded')
        temporary = packet / 'checkpoint.tmp'
        with temporary.open('wb', buffering=0) as stream:
            stream.write(body)
            os.fsync(stream.fileno())
        os.replace(temporary, packet / 'checkpoint.json')
        if kind == 'cleanup-attention-checkpoint':
            print(json.dumps({'attention':'exact snapshot cleanup remains supervised', 'packet':str(packet)}), flush=True)
    controller = SnapshotController(lambda:k.CreateToolhelp32Snapshot(2, 0),
        lambda handle:k.Process32FirstW(handle, ctypes.byref(entry)),
        lambda handle:k.Process32NextW(handle, ctypes.byref(entry)), ctypes.get_last_error,
        lambda:(entry.pid, entry.executable), k.CloseHandle, checkpoint)
    rows = controller.collect()
    jobs = filter_sdk_processes(rows, allowed_owned_pid)
    memory = Memory()
    memory.length = ctypes.sizeof(memory)
    if not k.GlobalMemoryStatusEx(ctypes.byref(memory)):
        raise ctypes.WinError(ctypes.get_last_error())
    free = memory.availablePhysical // (1024 * 1024)
    if free < 4096 or jobs:
        raise RuntimeError('Admission refused: memory floor or existing SDK jobs')
    return {'freeMiB': free, 'sdkJobs': jobs, 'observedUtc': datetime.now(timezone.utc).isoformat()}

class Lease:
    def __init__(self, body, path=SLOT, writer=os.write):
        self.path, self.fd = Path(path), None
        self.expected = json.dumps(body, sort_keys=True).encode('utf-8')
        self.identity = None
        self.written = b''
        self.released = False
        self.partial_creation = True
        self.fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_RDWR | getattr(os, 'O_BINARY', 0), 0o600)
        try:
            stat = os.fstat(self.fd)
            self.identity = (stat.st_dev, stat.st_ino)
            while len(self.written) < len(self.expected):
                count = writer(self.fd, self.expected[len(self.written):])
                if type(count) is not int or not 0 < count <= len(self.expected)-len(self.written):
                    raise OSError('Slot write failed')
                self.written += self.expected[len(self.written):len(self.written)+count]
            os.fsync(self.fd)
            self.partial_creation = False
        except BaseException as error:
            try:
                self.close(partial=True)
            except BaseException as cleanup_error:
                cleanup_error.resource_lease = self
                raise cleanup_error from error
            raise

    def verify(self, partial=False):
        if self.identity is None and self.fd is not None:
            created = os.fstat(self.fd)
            self.identity = (created.st_dev, created.st_ino)
        stat = self.path.stat()
        if (stat.st_dev, stat.st_ino) != self.identity or not stat.st_ino:
            raise RuntimeError('Claim identity changed; preserve foreign file')
        with self.path.open('rb') as stream:
            data = stream.read(len(self.expected)+1)
        valid = self.expected.startswith(data) if partial else data == self.expected
        if not valid:
            raise RuntimeError('Claim contents changed; preserve file')

    def close(self, partial=False):
        if self.released:
            return
        self.verify(partial)
        if self.fd is not None:
            held = os.fstat(self.fd)
            if (held.st_dev, held.st_ino) != self.identity:
                raise RuntimeError('Retained claim descriptor identity changed')
            os.close(self.fd)
            self.fd = None
        self.verify(partial)
        self.path.unlink()
        if self.path.exists():
            raise RuntimeError('Claim removal not verified')
        self.released = True
