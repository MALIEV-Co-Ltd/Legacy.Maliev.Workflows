"""Narrow test-local fresh-ELF admission; no allocation/authority at import."""
import os
from pathlib import Path
import re
import stat
import uuid

NATIVE_SOURCE_INDEX = '16c62fa97e8bcf8055ff89eeb5546df4ec5a40a3f3404ae3395b8728f979b727'
NATIVE_HEADER = 'eaa93f26ab4a766aab948ec00d92c1dfb98f2ea4f377ed61c1198ca49c913fef'
OUTPUTS = Path('/tmp/maliev-workflows-qualification/outputs')


def require(value):
    if not value:
        raise RuntimeError('Exact fresh native ELF admission refused')


def shape(proof, executable, active_lease):
    require(type(proof) is dict and set(proof) == {'leaseId', 'sourceIndexSha256', 'headerSha256',
                                                  'directory', 'executable', 'library'})
    require(type(active_lease) is str and str(uuid.UUID(active_lease)) == active_lease)
    require(proof['leaseId'] == active_lease and proof['sourceIndexSha256'] == NATIVE_SOURCE_INDEX
            and proof['headerSha256'] == NATIVE_HEADER)
    root = OUTPUTS / ('native-helper-' + active_lease) / 'executables'
    require(type(executable) is str and executable == str(root / 'test_program_child'))
    directory = proof['directory']
    require(type(directory) is dict and set(directory) == {'device', 'inode', 'uid', 'mode'})
    require(all(type(directory[k]) is int and directory[k] >= 0 for k in directory))
    require(directory['inode'] > 0 and directory['uid'] == 0 and directory['mode'] == stat.S_IFDIR | 0o555)
    for label, name, mode in (('executable', 'test_program_child', 0o555),
                              ('library', 'libmaliev_test_program_child.so', 0o444)):
        row = proof[label]
        require(type(row) is dict and set(row) == {'path', 'sha256', 'device', 'inode', 'bytes', 'uid', 'mode', 'modifiedNs'})
        require(type(row['path']) is str and row['path'] == str(root / name))
        require(type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']) is not None)
        require(all(type(row[k]) is int and row[k] >= 0 for k in ('device', 'inode', 'bytes', 'uid', 'mode', 'modifiedNs')))
        require(row['inode'] > 0 and 0 < row['bytes'] <= 64 * 1024**2 and row['uid'] == 0
                and row['mode'] == stat.S_IFREG | mode)
    return root


def bind(proof, executable, active_lease, bind_executable, recheck_executable, custody):
    # Caller publishes these fixed slots into its existing cleanup closure
    # BEFORE any file binding. Slot assignment allocates no tracking container.
    require(type(custody) is list and len(custody) == 2 and custody == [None, None])
    root = shape(proof, executable, active_lease)
    require(root.resolve(strict=True) == root and OUTPUTS.resolve(strict=True) == OUTPUTS)
    for parent in (OUTPUTS, root.parent):
        row = parent.stat(follow_symlinks=False)
        require(stat.S_ISDIR(row.st_mode) and row.st_uid == 0 and row.st_mode & 0o7022 == 0)
    observed = root.stat(follow_symlinks=False)
    expected = proof['directory']
    require((observed.st_dev, observed.st_ino, observed.st_uid, observed.st_mode)
            == (expected['device'], expected['inode'], expected['uid'], expected['mode']))
    bind_pair(proof, root, bind_executable, recheck_executable, custody)
    require(root.stat(follow_symlinks=False).st_ino == expected['inode'])


def bind_pair(proof, root, bind_executable, recheck_executable, custody):
    # No local cleanup that can replace the primary exception. The published
    # caller custody owns BOTH completed and partially validated bindings.
    for index, label in ((0, 'executable'), (1, 'library')):
        row = proof[label]
        custody[index] = bind_executable(row['path'], [root], 0, row['sha256'])
        value = custody[index]
        require((value['device'], value['inode'], value['bytes'], value['uid'], value['mode'], value['modifiedNs'])
                == tuple(row[k] for k in ('device', 'inode', 'bytes', 'uid', 'mode', 'modifiedNs')))
        require(os.fstat(value['fd']).st_nlink == 1)
        header = os.pread(value['fd'], 20, 0)
        require(len(header) == 20 and header[:7] == b'\x7fELF\x02\x01\x01' and header[18:20] == b'\x3e\x00')
        recheck_executable(value)


def recover_custody(custody, closed, cleanup_error_names, deadline, remaining, close=None):
    # Run only after the original SDK cgroup is independently quiescent. These
    # fixed state arrays belong to the original retained cleanup closure.
    close = os.close if close is None else close
    first = None
    for index in (0, 1):
        value = custody[index]
        if value is None or closed[index]:
            continue
        try:
            remaining(deadline)
            try:
                row = os.fstat(value['fd'])
            except OSError as error:
                if error.errno != 9:
                    raise
                closed[index] = True
                continue
            require((row.st_dev, row.st_ino, row.st_size, row.st_mode, row.st_mtime_ns)
                    == tuple(value[k] for k in ('device','inode','bytes','mode','modifiedNs')))
            close(value['fd'])
            closed[index] = True
        except BaseException as error:
            cleanup_error_names[index] = type(error).__name__
            if first is None:
                first = error
            # Still attempt every other exact retained descriptor. Original
            # run_owned preserves its primary error and quarantines this state.
    if first is not None:
        raise first
    return True
