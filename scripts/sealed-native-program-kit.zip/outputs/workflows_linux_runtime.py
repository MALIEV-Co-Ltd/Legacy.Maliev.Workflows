"""Same sealed route, Linux backend using existing owned scope and private relay.

Source under review. A grant never bypasses Linux capability or byte admission.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import socket
import subprocess
import sys
import threading
import time
import uuid
from workflows_linux_owned_scope_v1 import LinuxOwnedScope, require, start_ticks, registration_window
from workflows_private_docker_proxy_v1 import PrivateDockerProxy
from workflows_linux_trust import bind_executable, recheck_executable, remaining, remove_owned_tree

SCOPE = None
_quarantined = {}
SDK_NAMES = {'dotnet', 'MSBuild', 'testhost', 'VBCSCompiler', 'vstest.console'}

def capabilities(platform, free_mib, executables, controllers, competing):
    require(platform == 'linux' and free_mib >= 5120 and not competing)
    require({'bash', 'docker', 'dockerd'} <= set(executables))
    require({'cpu', 'memory', 'pids'} <= set(controllers))
    return {'platform': 'linux', 'initialFreeMiB': free_mib,
            'linuxDockerAndBashRequired': True, 'controllers': sorted(controllers)}

def preflight(allowed_owned_pid=None, floor=4096):
    require(sys.platform == 'linux')
    memory = dict(line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
    free = int(memory['MemAvailable'].split()[0]) // 1024
    competitors = []
    for process in Path('/proc').glob('[0-9]*/exe'):
        pid = int(process.parent.name)
        try:
            name = process.resolve(strict=True).name
        except FileNotFoundError:
            continue
        if name in SDK_NAMES and pid != allowed_owned_pid:
            competitors.append(pid)
    require(free >= floor and not competitors)
    return {'freeMiB': free, 'sdkJobs': competitors,
            'observedUtc': datetime.now(timezone.utc).isoformat()}

def owner_identity():
    return {'runnerPid': os.getpid(), 'runnerStartTicks': start_ticks(os.getpid()),
            'runnerExecutable': str(Path('/proc/self/exe').resolve(strict=True)),
            'ports': [], 'persistentData': False}

def private_daemon_version(backend, deadline):
    while time.monotonic() < deadline:
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(min(2, deadline-time.monotonic()))
                client.connect(str(backend))
                client.sendall(b'GET /version HTTP/1.0\r\nHost: localhost\r\n\r\n')
                raw = bytearray()
                while block := client.recv(4096):
                    if time.monotonic() >= deadline: raise TimeoutError('Private Docker readiness deadline')
                    raw.extend(block)
                    if len(raw) > 65536: raise ValueError('Private Docker version quota')
            headers, body = bytes(raw).split(b'\r\n\r\n', 1)
            require(headers.splitlines()[0].split()[1] == b'200')
            value = json.loads(body)
            require(type(value) is dict and value.get('Os') == 'linux')
            return {'os': value['Os'], 'version': value.get('Version'), 'api': value.get('ApiVersion')}
        except (OSError, TimeoutError):
            time.sleep(.05)
    raise TimeoutError('Private Linux Docker readiness unavailable')

def begin(deadline, private, uid, gid):
    global SCOPE
    require(SCOPE is None and uid >= 1000 and gid > 0)
    require(os.execve in os.supports_fd)
    import shutil
    observed = preflight(floor=5120)
    executables = {name: shutil.which(name) for name in ('bash', 'docker', 'dockerd')}
    controllers = Path('/sys/fs/cgroup/cgroup.subtree_control').read_text().split()
    proof = capabilities(sys.platform, observed['freeMiB'],
                         [name for name, path in executables.items() if path], controllers, observed['sdkJobs'])
    private = Path(private)
    require(not private.exists() and private.is_absolute() and private.parent.resolve() == private.parent)
    SCOPE = LinuxOwnedScope(deadline)
    SCOPE.uid, SCOPE.gid, SCOPE.private = uid, gid, private
    with registration_window():
        private.mkdir(mode=0o700)
        created = private.stat(follow_symlinks=False)
        SCOPE.private_identity = (created.st_dev, created.st_ino, created.st_uid)
    SCOPE.cli_home = private.parent/'cli-home'
    SCOPE.cli_identity, SCOPE.cli_fd = None, None
    with registration_window():
        SCOPE.cli_home.mkdir(mode=0o700)
        created = SCOPE.cli_home.stat(follow_symlinks=False)
        SCOPE.cli_identity = (created.st_dev, created.st_ino, created.st_uid)
        os.chown(SCOPE.cli_home, uid, gid)
        created = SCOPE.cli_home.stat(follow_symlinks=False)
        SCOPE.cli_identity = (created.st_dev, created.st_ino, created.st_uid)
        SCOPE.cli_fd = os.open(SCOPE.cli_home, os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
    for name in ('cache','config','data','tmp'):
        directory = SCOPE.cli_home/name
        directory.mkdir(mode=0o700); os.chown(directory, uid, gid)
    SCOPE.acquire()
    # Backend is private to UID0. SDK peers get only the finite verified relay.
    backend = private / 'backend.sock'
    front_parent = private.parent / 'sdk-docker'
    front_parent.mkdir(mode=0o755)
    SCOPE.front_parent = front_parent
    with registration_window():
        daemon_log = (private / 'daemon.log').open('xb', buffering=0)
        SCOPE.daemon_log = daemon_log
        daemon_read, daemon_write = os.pipe()
        SCOPE.daemon_pipes = [daemon_read, daemon_write]
    SCOPE.daemon_failure = None
    SCOPE.daemon_reader_stop = threading.Event()
    SCOPE.daemon_reader_receipt = None
    os.set_blocking(daemon_read,False)
    SCOPE.daemon_reader = threading.Thread(target=retain_daemon_output,
                                          args=(SCOPE,daemon_read,daemon_log),daemon=False)
    with registration_window(): SCOPE.daemon_reader.start()
    argv = [executables['dockerd'], '--host=unix://' + str(backend),
            '--data-root=' + str(private / 'data'), '--exec-root=' + str(private / 'exec'),
            '--pidfile=' + str(private / 'daemon.pid'), '--group=root',
            '--storage-driver=vfs', '--bridge=none', '--iptables=false', '--ip6tables=false',
            '--ip-forward=false', '--ip-masq=false', '--userland-proxy=false',
            '--exec-opt=native.cgroupdriver=cgroupfs', '--cgroup-parent=' + str(SCOPE.root / 'docker')]
    with registration_window():
        SCOPE.daemon_binding = bind_executable(executables['dockerd'], [Path('/usr/bin'),Path('/usr/sbin'),Path('/usr/local/bin')], 0, maximum_bytes=96*1024**2)
    recheck_executable(SCOPE.daemon_binding)
    argv[0] = SCOPE.daemon_binding['resolved']
    daemon = SCOPE.spawn(argv, 'daemon', 0, 0, [], dict(os.environ, GOMAXPROCS='2'), daemon_write, daemon_write, SCOPE.daemon_binding['fd'])
    os.close(daemon_write); SCOPE.daemon_pipes.remove(daemon_write)
    until = min(deadline, time.monotonic() + 30)
    while not backend.exists():
        require(time.monotonic() < until and SCOPE.daemon_failure is None)
        time.sleep(.05)
    version = private_daemon_version(backend, until)
    require(start_ticks(daemon['pid']) == daemon['startTicks'])
    actual_daemon = Path('/proc/'+str(daemon['pid'])+'/exe').resolve(strict=True)
    require(actual_daemon == Path(executables['dockerd']).resolve(strict=True))
    relay = PrivateDockerProxy(front_parent / 'docker.sock', backend, uid, gid,
                               '/' + SCOPE.root.name + '/sdk', SCOPE.observe_peer, deadline)
    relay.start()
    SCOPE.register_proxy(relay)
    proof['owner'] = owner_identity()
    proof['docker'] = version
    proof['daemon'] = {key:value for key,value in daemon.items() if key != 'pidfd'}
    proof['daemon']['executable'] = str(actual_daemon)
    proof['budget'] = {'memoryBytes': 3221225472, 'cpuRate': 5000, 'tasks': 64}
    proof['budgetReadback'] = {name:(SCOPE.root/name).read_text().strip()
                              for name in ('memory.max','cpu.max','pids.max')}
    proof['ownedGroups'] = [{'path':str(path),'identity':SCOPE.births[path]}
                            for path in SCOPE.handles]
    return proof

def command_budget(timeout, memory_limit, cpu_rate, output_limit, deadline):
    require(type(timeout) in (int, float) and 0 < timeout <= 600)
    require(memory_limit <= 3 * 1024**3 and cpu_rate <= 5000 and 0 < output_limit <= 4 * 1024**2)
    require(time.monotonic() < deadline)

def runtime_environment(environment, home, uid, gid):
    home = Path(home)
    observed = home.stat(follow_symlinks=False)
    require(home.resolve() == home.absolute() and not home.is_symlink()
            and observed.st_uid == uid and observed.st_gid == gid
            and observed.st_mode & 0o777 == 0o700)
    result = dict(environment)
    for key in ('GH_TOKEN','GITHUB_TOKEN','ROOT_STATIC_PERMIT','TRUSTED_WORKFLOW_CONTEXT'):
        result.pop(key, None)
    result.update(HOME=str(home),DOTNET_CLI_HOME=str(home),XDG_CACHE_HOME=str(home/'cache'),
                  XDG_CONFIG_HOME=str(home/'config'),XDG_DATA_HOME=str(home/'data'),TMPDIR=str(home/'tmp'))
    return result

def check_cli_home():
    held = os.fstat(SCOPE.cli_fd); observed = SCOPE.cli_home.stat(follow_symlinks=False)
    require((held.st_dev,held.st_ino,held.st_uid) == SCOPE.cli_identity
            == (observed.st_dev,observed.st_ino,observed.st_uid))
    size = 0; count = 0
    for path in SCOPE.cli_home.rglob('*'):
        require(time.monotonic() < SCOPE.deadline and not path.is_symlink())
        count += 1; require(count <= 10000)
        if path.is_file(): size += path.stat().st_size
        require(size <= 128*1024**2)


# Observation only: fixed readonly inputs, no new workers, no authority to qualify.
COUNTER_FILES = ('pids.current','pids.max','pids.events','pids.peak',
                 'memory.current','memory.peak','memory.max','memory.events','memory.events.local')

def parse_discovery_counter(name, raw):
    import re
    require(name in COUNTER_FILES and type(raw) is bytes and 0 < len(raw) <= 4096)
    text = raw.decode('ascii',errors='strict')
    def decimal(value):
        require(re.fullmatch(r'0|[1-9][0-9]{0,19}',value) is not None)
        return int(value)
    if name.endswith('events') or name.endswith('events.local'):
        required = {'max'} if name.startswith('pids.') else {'low','high','max','oom','oom_kill'}
        allowed = required if name.startswith('pids.') else required | {'oom_group_kill'}
        result = {}
        for line in text.splitlines():
            fields=line.split(' ')
            require(len(fields)==2 and fields[0] in allowed and fields[0] not in result)
            result[fields[0]]=decimal(fields[1])
        require(required <= result.keys())
        return result
    value=text.removesuffix('\n')
    if name in ('pids.max','memory.max') and value=='max': return 'max'
    return decimal(value)

def observation_read(path, bound=4096):
    import stat
    fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW|os.O_NONBLOCK)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode))
        raw=os.read(fd,bound+1)
        require(len(raw)<=bound)
        return raw
    finally: os.close(fd)

def discovery_process(pid, expected_group):
    import stat,re
    from workflows_linux_owned_scope_v1 import group_of
    birth=start_ticks(pid)
    require(group_of(pid)==expected_group)
    base=Path('/proc')/str(pid)
    status=observation_read(base/'status',8192).decode('ascii')
    names=re.findall(r'^Name:\s+([A-Za-z0-9_.+-]{1,64})$',status,re.M)
    require(len(names)==1)
    matches=re.findall(r'^Threads:\s+([0-9]+)$',status,re.M)
    require(len(matches)==1 and 1<=int(matches[0])<=100000)
    fdmeta=(base/'fd'/'0').stat()
    fdinfo=observation_read(base/'fdinfo'/'0').decode('ascii')
    flags=re.findall(r'^flags:\s+([0-7]+)$',fdinfo,re.M)
    require(len(flags)==1)
    kinds={stat.S_IFREG:'regular',stat.S_IFCHR:'character',stat.S_IFIFO:'pipe',stat.S_IFSOCK:'socket',stat.S_IFDIR:'directory'}
    limits=observation_read(base/'limits',8192).decode('ascii')
    selected={}
    for label in ('Max processes','Max open files','Max stack size','Max address space'):
        match=re.findall(r'^'+label+r'\s+([0-9]+|unlimited)\s+([0-9]+|unlimited)\s+(\S+)\s*$',limits,re.M)
        require(len(match)==1)
        soft,hard,units=match[0]
        selected[label]={'soft':soft,'hard':hard,'units':units}
    require(start_ticks(pid)==birth and group_of(pid)==expected_group)
    return {'pid':pid,'startTicks':birth,'name':names[0],'threads':int(matches[0]),
            'stdin':{'type':kinds.get(stat.S_IFMT(fdmeta.st_mode),'other'),'flagsOctal':flags[0]},'limits':selected}

OBSERVED_PHASES = ('discovery','focused','suite')

def observed_phase(log_path):
    if log_path is None: return None
    name = Path(log_path).name
    return next((phase for phase in OBSERVED_PHASES if name == phase+'.log'),None)

def sample_phase_observation(log_path, state, row, deadline=None):
    require(type(state) is dict and set(state)=={'count','nextAt'})
    require(type(state['count']) is int and 0 <= state['count'] <= 8)
    require(type(state['nextAt']) in (int,float) and 0 <= state['nextAt'] < float('inf'))
    phase = observed_phase(log_path)
    require(phase is not None)
    # At most eight early live snapshots, spaced at least one second after the
    # preceding snapshot completes, plus fixed before/admitted/terminal ones.
    # No new workers or extension of command/shared SDK deadlines.
    now = time.monotonic()
    require(deadline is None or type(deadline) in (int,float) and 0 <= deadline < float('inf'))
    boundary = min(SCOPE.deadline,deadline if deadline is not None else SCOPE.deadline)
    if state['count'] < 8 and now >= state['nextAt'] and now < boundary:
        retain_discovery_observation(log_path,'live-'+str(state['count']+1),row,deadline=boundary)
        state['count'] += 1
        state['nextAt'] = time.monotonic()+1

def retain_discovery_observation(log_path, stage, row, *, deadline=None):
    phase = observed_phase(log_path)
    require(phase is not None)
    require(type(stage) is str and stage in {'before','admitted','terminal',*('live-'+str(i) for i in range(1,9))})
    # Each snapshot consumes at most one second WITHIN the shared SDK deadline.
    require(deadline is None or type(deadline) in (int,float) and 0 <= deadline < float('inf'))
    deadline=min(SCOPE.deadline,time.monotonic()+1,deadline if deadline is not None else SCOPE.deadline)
    body={'schema':1,'qualified':False,'stage':stage,'utc':datetime.now(timezone.utc).isoformat(),
          'groups':{},'processes':[],'coverage':'direct members of the five held owned groups; nested Docker groups excluded'}
    try:
        for label in ('root','sdk'):
            group=SCOPE.root if label=='root' else SCOPE.root/'sdk'
            SCOPE.verify(group)
            counters={}
            for name in COUNTER_FILES:
                remaining(deadline)
                try: value=parse_discovery_counter(name,observation_read(group/name))
                except (OSError,RuntimeError,ValueError,UnicodeError) as error:
                    counters[name]={'status':'unavailable','value':None,'reason':type(error).__name__}
                else: counters[name]={'status':'observed','value':value,'reason':None}
            SCOPE.verify(group)
            body['groups'][label]=counters
        count=0
        for label in ('root','control','sdk','daemon','docker'):
            group=SCOPE.root if label=='root' else SCOPE.root/label
            remaining(deadline);SCOPE.verify(group)
            raw=observation_read(group/'cgroup.procs')
            import re
            require(all(re.fullmatch(rb'[1-9][0-9]{0,9}',v) for v in raw.splitlines()))
            pids=[int(v) for v in raw.splitlines()]
            require(len(pids)==len(set(pids)))
            count+=len(pids);require(count<=64)
            expected='/'+str(group.relative_to('/sys/fs/cgroup'))
            for pid in pids:
                remaining(deadline)
                try: observed=discovery_process(pid,expected)
                except (OSError,RuntimeError,ValueError,UnicodeError) as error:
                    observed={'pid':pid,'status':'unavailable','reason':type(error).__name__}
                else: observed['status']='observed'
                observed['group']=label;body['processes'].append(observed)
            SCOPE.verify(group)
        body['status']='observed'
    except (OSError,RuntimeError,ValueError,UnicodeError) as error:
        body.update(status='incomplete',reason=type(error).__name__)
    try:
        encoded=(json.dumps(body,sort_keys=True)+'\n').encode()
        require(len(encoded)<=65536)
        path=Path(log_path).with_name(phase+'-observation-'+stage+'.json')
        with path.open('xb') as stream: stream.write(encoded)
        summary={'status':body['status'],'file':path.name,'bytes':len(encoded),'sha256':hashlib.sha256(encoded).hexdigest()}
    except (OSError,RuntimeError,ValueError) as error:
        summary={'status':'unavailable','reason':type(error).__name__}
    row.setdefault('discoveryObservations',{})[stage]=summary

def sdk_child_environment(environment, socket_path):
    require(type(environment) is dict and all(type(k) is str and type(v) is str for k,v in environment.items()))
    require(type(socket_path) is str and socket_path)
    result = dict(environment)
    # Disable optional diagnostic IPC/debugger/profiler helper threads only in
    # owned child processes. Console logs, cgroup evidence and test checks remain.
    result.update(DOCKER_HOST='unix://' + socket_path,
                  DOTNET_PROCESSOR_COUNT='1', MSBUILDDISABLENODEREUSE='1',
                  DOTNET_CLI_DO_NOT_USE_MSBUILD_SERVER='1', DOTNET_EnableDiagnostics='0')
    return result

def run_owned(argv, cwd=None, timeout=30, memory_limit=256*1024**2,
              cpu_rate=5000, output_limit=4*1024**2, log_path=None, on_event=None, env=None, native_binding=None, native_lease=None):
    require(SCOPE is not None and not SCOPE.closed)
    require(SCOPE.daemon_failure is None)
    command_budget(timeout, memory_limit, cpu_rate, output_limit, SCOPE.deadline)
    sdk_group = SCOPE.root/'sdk'
    SCOPE.verify(sdk_group)
    # Tighter preparation budgets remain tighter than the aggregate SDK ceiling.
    (sdk_group/'memory.max').write_text(str(memory_limit))
    (sdk_group/'cpu.max').write_text(str(cpu_rate*10)+' 100000')
    require((sdk_group/'memory.max').read_text().strip() == str(memory_limit))
    require((sdk_group/'cpu.max').read_text().strip() == str(cpu_rate*10)+' 100000')
    import shutil
    argv = list(argv)
    executable = shutil.which(argv[0]) if not Path(argv[0]).is_absolute() else argv[0]
    require(executable is not None)
    argv[0] = executable
    check_cli_home()
    environment = runtime_environment(os.environ if env is None else env, SCOPE.cli_home, SCOPE.uid, SCOPE.gid)
    environment = sdk_child_environment(environment, str(SCOPE.front_parent / 'docker.sock'))
    # The scope's SDK child executes unprivileged and drops supplementary groups.
    # A fixed Python trampoline sets cwd without a shell or argument interpolation.
    descriptors = []
    child = None
    stdout, stderr = bytearray(), bytearray()
    stop_reason = None
    status = None
    row = {'job_lease': str(uuid.uuid4()), 'purpose': 'sealed Linux command',
           'executable': executable, 'persistentData': False, 'ports': [],
           'job_memory_limit_bytes': memory_limit, 'job_cpu_rate': cpu_rate,
           'job_active_process_limit': 64, 'job_caps_readback_verified': True}
    primary = None
    native_selected = native_binding is not None
    native_custody = [None, None]
    native_closed = [False, False]
    native_cleanup_errors = [None, None]
    if native_selected:
        row["nativeDescriptorCleanup"] = {"closed":native_closed,"errorTypes":native_cleanup_errors}
    observation_phase = observed_phase(log_path)
    discovery_observation = observation_phase is not None
    if discovery_observation: retain_discovery_observation(log_path,"before",row)
    try:
        # Retain a command-specific handle while the overall scope retains its own.
        with registration_window(): descriptors.append(os.dup(SCOPE.handles[sdk_group]))
        sdk_root = Path('/tmp/maliev-workflows-qualification/private-sdk/sdk')
        sdk_selected = Path(executable).name == 'dotnet'
        native_selected = native_binding is not None
        require(not native_selected or not sdk_selected)
        require(native_selected or native_lease is None)
        if native_selected:
            require(not any(environment.get(k) for k in ("LD_PRELOAD", "LD_LIBRARY_PATH", "LD_AUDIT")))
        roots = [sdk_root] if sdk_selected else [Path('/usr/bin'),Path('/usr/local/bin'),Path('/usr/sbin')]
        pin = '01d89e0a0191052bfea616cd4ce624c8faf13b05bbddf7f64499c23e2a9d9269' if sdk_selected else None
        with registration_window():
            if native_selected:
                from workflows_native_elf_admission_v1 import bind as bind_native
                bind_native(native_binding, executable, native_lease, bind_executable, recheck_executable, native_custody)
                binding, native_library = native_custody
                row["nativeArtifactSourceIndex"] = native_binding["sourceIndexSha256"]
                row["nativeLibrarySha256"] = native_library["sha256"]
            else:
                binding = bind_executable(executable, roots, SCOPE.uid if sdk_selected else 0, pin)
            executable_fd = binding['fd']
            if not native_selected: descriptors.append(executable_fd)
        os.set_inheritable(executable_fd, True)
        executable_birth = os.fstat(executable_fd)
        executable = binding['resolved']; argv[0] = executable
        row['executableIdentity'] = {'device':executable_birth.st_dev,'inode':executable_birth.st_ino}
        row['executableSha256'] = binding['sha256']
        with registration_window():
            interpreter = bind_executable(sys.executable, [Path('/usr/bin'),Path('/usr/local/bin')], 0)
            descriptors.append(interpreter['fd'])
        trampoline_code = 'import os,sys;os.chdir(sys.argv[1]);os.execve(int(sys.argv[2]),sys.argv[3:],os.environ)'
        if native_selected:
            trampoline_code = 'import os,sys;os.chdir(sys.argv[1]);fd=int(sys.argv[2]);os.set_inheritable(fd,False);os.execve(fd,sys.argv[3:],os.environ)'
        trampoline = [interpreter['resolved'], '-I', '-B', '-c', trampoline_code,
                      str(Path(cwd or Path.cwd()).resolve()), str(executable_fd), *argv]
        with registration_window():
            out_read, out_write = os.pipe(); descriptors.extend((out_read, out_write))
            err_read, err_write = os.pipe(); descriptors.extend((err_read, err_write))
        recheck_executable(binding)
        if native_selected: recheck_executable(native_library)
        recheck_executable(interpreter)
        child = SCOPE.spawn(trampoline, 'sdk', SCOPE.uid, SCOPE.gid, [], environment, out_write, err_write, interpreter['fd'])
        row.update(pid=child['pid'], startTicks=child['startTicks'])
        if discovery_observation: retain_discovery_observation(log_path,'admitted',row)
        if on_event: on_event('linux-owned-child', dict(row))
        os.close(out_write); descriptors.remove(out_write)
        os.close(err_write); descriptors.remove(err_write)
        deadline = min(SCOPE.deadline, time.monotonic() + timeout)
        pipes = {out_read: stdout, err_read: stderr}
        observation_state = {"count":0,"nextAt":time.monotonic()+1}
        while pipes or status is None:
            require(SCOPE.daemon_failure is None)
            if time.monotonic() >= deadline:
                stop_reason = 'timeout'; break
            if discovery_observation: sample_phase_observation(log_path,observation_state,row,deadline=deadline)
            ready, _, _ = select.select(list(pipes), [], [], .05)
            for descriptor in ready:
                data = os.read(descriptor, 65536)
                if not data:
                    os.close(descriptor); descriptors.remove(descriptor); del pipes[descriptor]
                    continue
                if len(stdout) + len(stderr) + len(data) > output_limit:
                    stop_reason = 'output-limit'; break
                pipes[descriptor].extend(data)
            if stop_reason: break
            if status is None:
                pid, observed = os.waitpid(child['pid'], os.WNOHANG)
                if pid:
                    status = observed; child['reaped'] = True
        if log_path: Path(log_path).write_bytes(bytes(stdout) + bytes(stderr))
    except BaseException as error:
        primary = error
    finally:
        if discovery_observation:
            retain_discovery_observation(log_path,"terminal",row)
            try:
                Path(log_path).with_name(observation_phase+"-stdout.log").write_bytes(bytes(stdout))
                Path(log_path).with_name(observation_phase+"-stderr.log").write_bytes(bytes(stderr))
            except OSError as error:
                row["discoveryStreams"]={"status":"unavailable","reason":type(error).__name__}
            else:
                row["discoveryStreams"]={"status":"retained","stdoutBytes":len(stdout),"stderrBytes":len(stderr)}
        failed = primary is not None or stop_reason is not None or (status is not None and os.waitstatus_to_exitcode(status) != 0)
        if failed and getattr(SCOPE,'cleanup_deadline',None) is None:
            SCOPE.cleanup_deadline = min(SCOPE.deadline+25,time.monotonic()+25)
        cleanup_deadline = getattr(SCOPE,'cleanup_deadline',None) or min(SCOPE.deadline+25,time.monotonic()+20)
        def cleanup(deadline=None):
            effective=cleanup_deadline
            if getattr(SCOPE,'cleanup_deadline',None) is not None:
                effective=min(effective,SCOPE.cleanup_deadline-2)
            if deadline is not None:effective=min(effective,deadline)
            SCOPE.stop_group('sdk',effective)
            native_cleanup_error = None
            if native_selected:
                from workflows_native_elf_admission_v1 import recover_custody
                try: recover_custody(native_custody,native_closed,native_cleanup_errors,effective,remaining)
                except BaseException as error: native_cleanup_error = error
            for descriptor in list(descriptors):
                remaining(effective)
                os.close(descriptor); descriptors.remove(descriptor)
            if child and child['pidfd'] is not None:
                remaining(effective)
                os.close(child['pidfd']); child['pidfd'] = None
            remaining(effective)
            if native_cleanup_error is not None: raise native_cleanup_error
            row.update(remaining_job_processes=0, terminal_state_verified=True,
                       cleanup_verified=True, process_handle_closed=True, thread_handle_closed=True,
                       job_handle_closed=True, pipe_handles_closed=True, readers_settled=True,
                       attribute_list_disposed=True, retained_unverified_handles=False)
            return True
        try: cleanup()
        except BaseException as error:
            _quarantined[row['job_lease']] = (cleanup, row)
            if primary is None: primary = error
        row['stop_reason'] = stop_reason
        row['output_truncated'] = stop_reason == 'output-limit'
        if on_event: on_event('linux-owned-command-terminal', dict(row))
    if primary:
        primary.resource_row = row
        raise primary
    code = os.waitstatus_to_exitcode(status) if status is not None else -1
    row['exit_code'] = code
    return subprocess.CompletedProcess(argv, code, bytes(stdout), bytes(stderr)), row

def recover_quarantined(lease,deadline=None):
    cleanup, row = _quarantined[lease]
    if cleanup(deadline): del _quarantined[lease]
    return row

def cleanup_boundary():
    require(SCOPE is not None)
    if getattr(SCOPE,'cleanup_deadline',None) is None:
        SCOPE.cleanup_deadline=min(SCOPE.deadline+25,time.monotonic()+25)
    return SCOPE.cleanup_deadline

def supervision_boundary():
    # Reserve two seconds INSIDE the existing 25-second boundary for finite
    # controller settlement. Neither SDK work nor cleanup gets a renewed lease.
    return cleanup_boundary()-2

def retain_daemon_output(scope,descriptor,log,*,monotonic=time.monotonic):
    used=0;reason='eof';failure=None
    try:
        # Never block on a pipe held open by a quarantined daemon. The reader
        # self-expires even when the controller cannot prove full cleanup.
        while not scope.daemon_reader_stop.is_set():
            deadline=min(scope.deadline+25,getattr(scope,'cleanup_deadline',None) or scope.deadline+25)
            available=deadline-monotonic()
            if available<=0:reason='fixed-deadline';break
            try:block=os.read(descriptor,65536)
            except BlockingIOError:
                scope.daemon_reader_stop.wait(min(.05,available));continue
            if not block:break
            if used+len(block)>4*1024**2:
                reason='output-limit';scope.daemon_failure=reason;break
            used+=len(block);log.write(block)
        else:reason='controller-stop'
    except BaseException as error:
        failure=type(error).__name__;scope.daemon_failure=failure
    finally:
        closed=False
        try:
            os.close(descriptor);scope.daemon_pipes.remove(descriptor);closed=True
        except BaseException as error:
            failure=failure or type(error).__name__;scope.daemon_failure=failure
        scope.daemon_reader_receipt=dict(stopReason=reason,bytes=used,pipeClosed=closed,failure=failure)

def settle_controller_reader(deadline):
    reader=getattr(SCOPE,'daemon_reader',None)
    if reader is None:return dict(nothingAcquired=True)
    SCOPE.daemon_reader_stop.set()
    reader.join(max(0,deadline-time.monotonic()))
    state=dict(stopRequested=True,joined=not reader.is_alive(),
               reader=getattr(SCOPE,'daemon_reader_receipt',None),fullResourceCleanupVerified=False)
    SCOPE.controller_reader_cleanup=state
    require(state['joined'] and state['reader'] is not None and state['reader']['pipeClosed'])
    return state

def contain_quarantined_controller(deadline):
    state=dict(custodyRetained=True,claimReleaseAuthorized=False,reader=None,
               proxy=None,daemonStopped=False,dockerStopped=False,errors=[])
    SCOPE.quarantine_containment=state
    def collect(operation):
        try:return operation()
        except BaseException as error:state['errors'].append(type(error).__name__);return None
    state['reader']=collect(lambda:settle_controller_reader(deadline))
    proxy=getattr(SCOPE,'proxy',None)
    if proxy is not None:
        collect(proxy.request_fence)
        state['proxy']=collect(lambda:proxy.stop(min(20,remaining(deadline))))
    relay_settled=proxy is None or (state['proxy'] is not None and
        state['proxy'].get('admissionFenced') is True and state['proxy'].get('activeClients')==0
        and state['proxy'].get('workersJoined') is True)
    if relay_settled:
        for name in ('docker','daemon'):
            if SCOPE.root/name in SCOPE.births:
                def stop(name=name):
                    SCOPE.stop_group(name,deadline);state[name+'Stopped']=True
                collect(stop)
    # Never close kernel custody handles, erase private data, or release claim
    # while SDK quarantine remains. Parent-death guards remain the final exact
    # direct-child containment if the fixed reserve itself is exhausted.
    return state

def prepare_result_directories(runroot):
    require(SCOPE is not None)
    runroot=Path(runroot)
    require(runroot.resolve()==runroot.absolute() and not runroot.is_symlink()
            and runroot.stat(follow_symlinks=False).st_uid==0)
    # Only controller-owned traversal directories are made searchable. Grant,
    # journal and receipt files stay under controller ownership.
    os.chmod(runroot,0o755)
    results=runroot/'test-results';results.mkdir(mode=0o755);os.chmod(results,0o755)
    proof={}
    for phase in ('focused','suite'):
        target=results/phase
        with registration_window():
            target.mkdir(mode=0o700);os.chown(target,SCOPE.uid,SCOPE.gid);os.chmod(target,0o700)
        observed=target.stat(follow_symlinks=False)
        proof[phase]=dict(device=observed.st_dev,inode=observed.st_ino,uid=SCOPE.uid,gid=SCOPE.gid,mode=0o700)
        verify_result_directory(runroot,phase,proof[phase])
    return proof

def verify_result_directory(runroot,phase,proof):
    require(SCOPE is not None and phase in ('focused','suite'))
    runroot=Path(runroot);results=runroot/'test-results';target=results/phase
    for parent in (runroot,results):
        row=parent.stat(follow_symlinks=False)
        require(not parent.is_symlink() and parent.resolve()==parent.absolute()
                and row.st_uid==0 and row.st_mode & 0o777==0o755)
    row=target.stat(follow_symlinks=False)
    require(not target.is_symlink() and target.resolve()==target.absolute()
            and (row.st_dev,row.st_ino,row.st_uid,row.st_gid,row.st_mode & 0o777)
            ==(proof['device'],proof['inode'],SCOPE.uid,SCOPE.gid,0o700)
            and proof['uid']==SCOPE.uid and proof['gid']==SCOPE.gid and proof['mode']==0o700)
    return True

def result_permission_arguments(runroot,permit_path):
    require(SCOPE is not None)
    # This probe uses the same held-interpreter/UID-drop route as validation.
    # It writes only fresh disposable files inside the two admitted results
    # directories; controller authority is tested without modifying it.
    code='''import json,os,sys
from pathlib import Path
runroot,permit=Path(sys.argv[1]),Path(sys.argv[2])
uid,gid=int(sys.argv[3]),int(sys.argv[4])
assert os.getuid()==os.geteuid()==uid and os.getgid()==os.getegid()==gid
assert all(not os.access(path,os.W_OK) for path in (runroot,runroot.parent,permit))
for phase in ('focused','suite'):
    target=runroot/'test-results'/phase/'.permission-probe'
    created=False
    try:
        with target.open('xb') as stream:
            created=True;stream.write(b'bounded results permission proof');stream.flush();os.fsync(stream.fileno())
        assert target.read_bytes()==b'bounded results permission proof'
    finally:
        if created:target.unlink()
print(json.dumps(dict(uid=uid,gid=gid,writableResults=['focused','suite'],authorityNotWritable=True)))
'''
    return [sys.executable,'-I','-B','-c',code,str(runroot),str(permit_path),str(SCOPE.uid),str(SCOPE.gid)]

def finish(deadline):
    if SCOPE is None: return {'nothingAcquired': True}
    deadline = min(deadline,getattr(SCOPE,'cleanup_deadline',None) or deadline)
    if _quarantined:
        contain_quarantined_controller(deadline)
        raise RuntimeError('Quarantine custody retained; controller containment recorded')
    # Existing scope fences relay clients before stopping exact daemon/cgroups.
    first_failure=None
    try:
        receipt = SCOPE.release(deadline)
        receipt.pop('relayMetadata',None)  # Metadata is retained on SCOPE; kernel flags remain unchanged.
    except BaseException as error:
        first_failure=error
        try:
            state=contain_quarantined_controller(deadline)
            if state['errors']:first_failure.add_note('Secondary controller containment failures: '+','.join(state['errors']))
        except BaseException as secondary:
            first_failure.add_note('Secondary controller containment failure: '+type(secondary).__name__)
        raise first_failure
    try:settle_controller_reader(deadline)
    except BaseException as error:
        if first_failure is None:first_failure=error
        else:first_failure.add_note('Secondary reader settlement failure: '+type(error).__name__)
    if first_failure is not None:raise first_failure
    if getattr(SCOPE,'daemon_binding',None) is not None:
        os.close(SCOPE.daemon_binding['fd']);SCOPE.daemon_binding=None
    for descriptor in list(getattr(SCOPE, 'daemon_pipes', [])):
        if descriptor != SCOPE.daemon_pipes[0]:
            os.close(descriptor); SCOPE.daemon_pipes.remove(descriptor)
    for descriptor in list(getattr(SCOPE, 'daemon_pipes', [])):
        os.close(descriptor); SCOPE.daemon_pipes.remove(descriptor)
    if getattr(SCOPE, 'daemon_log', None) is not None: SCOPE.daemon_log.close()
    private = SCOPE.private
    require(private.resolve() == private.absolute() and not private.is_symlink())
    observed = private.stat(follow_symlinks=False)
    require((observed.st_dev, observed.st_ino, observed.st_uid) == SCOPE.private_identity)
    log = private/'daemon.log'
    if log.exists():
        require(log.stat().st_size <= 4*1024**2)
        (private.parent/'outputs/docker-daemon.log').write_bytes(log.read_bytes())
    remove_owned_tree(private,SCOPE.private_identity,deadline)
    front_parent = getattr(SCOPE, 'front_parent', None)
    if front_parent is not None:
        remaining(deadline); front_parent.rmdir()
    require(not private.exists() and (front_parent is None or not front_parent.exists()))
    receipt['privateDockerDataRemoved'] = True
    if getattr(SCOPE,'cli_home',None) is not None:
        remove_owned_tree(SCOPE.cli_home,SCOPE.cli_identity,deadline)
        if SCOPE.cli_fd is not None:
            os.close(SCOPE.cli_fd); SCOPE.cli_fd = None
        receipt['privateCliHomeRemoved'] = True
    return receipt
