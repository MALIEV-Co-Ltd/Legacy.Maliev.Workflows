"""Retain the exact Toolhelp handle through census and cleanup-only recovery."""
import time
import uuid
import workflows_cleanup_supervisor_v1 as supervisor


class SnapshotController:
    def __init__(self, create, first, advance, error, read, close, checkpoint,
                 *, monotonic=time.monotonic, wait=time.sleep):
        self.create, self.first, self.advance = create, first, advance
        self.error, self.read, self.close = error, read, close
        self.checkpoint = checkpoint
        self.monotonic, self.wait = monotonic, wait
        self.lease = str(uuid.uuid4())
        self.handle = None
        self.closed = False
        self.cleanup = None
        # Establish the recovery owner before acquisition, including before a
        # census callback or checkpoint can fail. No PID lookup/reopen occurs.
        self.resources = {self.lease: self}

    def recover(self, lease):
        if lease != self.lease:
            raise RuntimeError('Snapshot ownership mismatch')
        if self.closed:
            self.resources.pop(lease, None)
            return
        if self.handle is None:
            raise RuntimeError('Snapshot ownership mismatch')
        if not self.close(self.handle):
            raise OSError(self.error(), 'Owned Toolhelp CloseHandle failed')
        self.closed = True
        self.handle = None
        del self.resources[lease]

    def collect(self):
        try:
            self.handle = self.create()
        except BaseException:
            self.resources.clear()
            raise
        if self.handle is None or self.handle == -1 or self.handle == __import__('ctypes').c_void_p(-1).value:
            self.resources.clear()
            raise OSError(self.error(), 'Toolhelp acquisition failed')
        try:
            rows = []
            ok = self.first(self.handle)
            while ok:
                rows.append(self.read())
                ok = self.advance(self.handle)
            if self.error() != 18:
                raise RuntimeError('Process census incomplete')
            return rows
        finally:
            def checkpoint(kind, state):
                self.checkpoint(kind, dict(state, snapshotHandle=self.handle,
                    snapshotLease=self.lease, snapshotClosed=self.closed))
            # Never return/throw from this finally while an exact handle remains.
            # Each attempt has a finite lease; attention renews cleanup only.
            self.cleanup = supervisor.supervise(self.resources, self.recover, None, None,
                checkpoint, monotonic=self.monotonic, wait=self.wait)
            if self.cleanup['failureCount']:
                raise RuntimeError('Snapshot released after recovery; fresh admission required')
