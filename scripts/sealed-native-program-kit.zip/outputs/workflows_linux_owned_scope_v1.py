"""Linux cgroup-v2 custody primitives. No authority issuance or implicit SDK run.

Callers must first consume an authenticated, sealed Root grant. This module is
source under review; physical hosted capability remains unqualified.
"""
import os
import ctypes
from contextlib import contextmanager
from pathlib import Path
import select
import signal
import sys
import time
import uuid
from workflows_private_docker_proxy_v1 import relay_metadata_evidence

@contextmanager
def registration_window():
    previous=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
    try:yield
    finally:signal.pthread_sigmask(signal.SIG_SETMASK,previous)

def child_guard(parent, libc=None):
    libc=libc or ctypes.CDLL(None,use_errno=True)
    require(libc.prctl(1,signal.SIGKILL,0,0,0)==0)
    require(os.getppid()==parent)

BUDGET={'memory.max':'3221225472','pids.max':'64','cpu.max':'50000 100000'}
def require(value):
    if not value:raise RuntimeError('Linux owned scope refused.')
def identity(path):
    value=path.stat(follow_symlinks=False);return (value.st_dev,value.st_ino)
def descriptor_identity(fd):
    value=os.fstat(fd);return (value.st_dev,value.st_ino)
def start_ticks(pid):
    raw=Path('/proc/'+str(pid)+'/stat').read_text()
    return int(raw[raw.rfind(')')+2:].split()[19])
def group_of(pid):
    lines=Path('/proc/'+str(pid)+'/cgroup').read_text().splitlines()
    require(len(lines)==1 and lines[0].startswith('0::/'))
    return lines[0][3:]
def populated(path):
    rows=dict(line.split() for line in (path/'cgroup.events').read_text().splitlines())
    require(rows.get('populated') in {'0','1'});return rows['populated']=='1'

class LinuxOwnedScope:
    def __init__(self,deadline):
        require(sys.platform=='linux' and os.geteuid()==0 and hasattr(os,'pidfd_open'))
        require(0<deadline-time.monotonic()<=600)
        self.deadline=deadline;self.root=Path('/sys/fs/cgroup')/('maliev-workflows-'+uuid.uuid4().hex)
        self.handles={};self.births={};self.children={};self.self_group=None
        self.self_birth=start_ticks(os.getpid());self.entered=False;self.closed=False
        self.original_group=None;self.proxy=None
    def verify(self,path):
        require(path in self.handles and descriptor_identity(self.handles[path])==self.births[path]
                and identity(path)==self.births[path])
    def create(self,path):
        self.births[path]=None  # Register before the mkdir/open cancellation window.
        path.mkdir()
        self.births[path]=identity(path)
        fd=os.open(path,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW)
        self.handles[path]=fd;self.births[path]=descriptor_identity(fd);self.verify(path)
    def _acquire(self):
        require(not self.entered and not self.root.exists())
        base=self.root.parent
        require(not base.is_symlink() and (base/'cgroup.controllers').is_file())
        require({'cpu','memory','pids'}<=set((base/'cgroup.subtree_control').read_text().split()))
        self.original_group=group_of(os.getpid())
        self.self_group=base/self.original_group.lstrip('/')
        self.create(self.root)
        for name,value in BUDGET.items():(self.root/name).write_text(value)
        require(all((self.root/name).read_text().strip()==value for name,value in BUDGET.items()))
        (self.root/'cgroup.subtree_control').write_text('+cpu +memory +pids')
        for name in ('control','sdk','daemon','docker'):self.create(self.root/name)
        (self.root/'docker/cgroup.subtree_control').write_text('+cpu +memory +pids')
        require(start_ticks(os.getpid())==self.self_birth)
        (self.root/'control/cgroup.procs').write_text(str(os.getpid()))
        self.entered=True
        require(group_of(os.getpid())=='/'+self.root.name+'/control')
        return self
    def acquire(self):
        with registration_window():return self._acquire()
    def register_proxy(self,proxy):
        require(self.entered and self.proxy is None and proxy.started)
        self.proxy=proxy
    def spawn(self,argv,kind,uid,gid,groups,environment,stdout_fd,stderr_fd,executable_fd=None):
        require(self.entered and not self.closed and kind in {'sdk','daemon'}
                and time.monotonic()<self.deadline and type(argv) is list and argv
                and all(type(v) is str and '\0' not in v for v in argv))
        require(type(uid) is int and type(gid) is int and type(groups) is list)
        require((kind=='sdk' and uid>=1000 and gid>0) or (kind=='daemon' and uid==gid==0))
        require(kind!='sdk' or (self.proxy is not None and self.proxy.started and not self.proxy.closed.is_set()))
        group=self.root/kind;self.verify(group)
        previous=signal.pthread_sigmask(signal.SIG_BLOCK,{signal.SIGINT,signal.SIGTERM})
        parent=os.getpid()
        try:
            pid=os.fork()
            if pid==0:
                try:
                    signal.signal(signal.SIGINT,signal.SIG_DFL)
                    signal.signal(signal.SIGTERM,signal.SIG_DFL)
                    child_guard(parent)
                    os.kill(os.getpid(),signal.SIGSTOP)
                    os.dup2(stdout_fd,1);os.dup2(stderr_fd,2)
                    if kind=='sdk':
                        libc=ctypes.CDLL(None,use_errno=True)
                        require(libc.prctl(38,1,0,0,0)==0)
                        os.setgroups(groups);os.setgid(gid);os.setuid(uid)
                    child_guard(parent)  # Credential changes clear Linux parent-death state.
                    signal.pthread_sigmask(signal.SIG_SETMASK,previous)
                    os.execve(executable_fd if executable_fd is not None else argv[0],argv,environment)
                except BaseException:os._exit(126)
            # Registration precedes identity acquisition; unreaped direct child
            # cannot have its PID reused even if pidfd_open itself fails.
            row=dict(pid=pid,pidfd=None,startTicks=None,group=str(group),reaped=False,
                     purpose=kind,executable=argv[0],uid=uid,gid=gid,persistentData=False,admitted=False)
            self.children[pid]=row
            row['pidfd']=os.pidfd_open(pid);row['startTicks']=start_ticks(pid)
            end=min(self.deadline,time.monotonic()+10)
            while time.monotonic()<end:
                observed,status=os.waitpid(pid,os.WNOHANG|os.WUNTRACED)
                if observed:
                    require(os.WIFSTOPPED(status));break
                time.sleep(.01)
            else:raise TimeoutError('Owned child admission stop not observed')
            self.verify(group);require(start_ticks(pid)==row['startTicks'])
            (group/'cgroup.procs').write_text(str(pid))
            require(group_of(pid)=='/'+self.root.name+'/'+kind and time.monotonic()<self.deadline)
            row['admitted']=True
            signal.pidfd_send_signal(row['pidfd'],signal.SIGCONT)
            return row
        finally:signal.pthread_sigmask(signal.SIG_SETMASK,previous)
    def observe_peer(self,pid):
        sdk=self.root/'sdk';self.verify(sdk)
        birth=start_ticks(pid)
        status=dict(line.split(':',1) for line in Path('/proc/'+str(pid)+'/status').read_text().splitlines() if ':' in line)
        group=group_of(pid);require(start_ticks(pid)==birth)
        return dict(pid=pid,uid=int(status['Uid'].split()[1]),gid=int(status['Gid'].split()[1]),
                    startTicks=birth,cgroup=group,retainedGroupIdentityVerified=True)
    def stop_group(self,name,deadline=None):
        require(name in {'sdk','daemon','docker'})
        group=self.root/name;self.verify(group)
        end=deadline if deadline is not None else time.monotonic()+20
        require(time.monotonic()<end)
        # Graceful first, using only retained direct child custody.
        for row in self.children.values():
            if row['group']!=str(group) or row['reaped']:continue
            if row['pidfd'] is not None:
                ready,_,_=select.select([row['pidfd']],[],[],0)
                if not ready:signal.pidfd_send_signal(row['pidfd'],signal.SIGTERM)
            else:
                os.kill(row['pid'],signal.SIGTERM)  # Exact unreaped direct child cannot be reused.
        grace=min(end,time.monotonic()+1)
        def unadmitted_pending():
            pending=False
            for row in self.children.values():
                if row['group']!=str(group) or row['reaped'] or row.get('admitted',True):continue
                pid,_=os.waitpid(row['pid'],os.WNOHANG)
                if pid:row['reaped']=True
                else:pending=True
            return pending
        while (populated(group) or unadmitted_pending()) and time.monotonic()<grace:time.sleep(.02)
        require(time.monotonic()<end)
        self.verify(group)
        # A child stopped before cgroup admission is still an exact unreaped
        # direct child. Never resume it outside its admitted group.
        for row in self.children.values():
            if row['group']!=str(group) or row['reaped'] or row.get('admitted',True):continue
            if row['pidfd'] is not None:signal.pidfd_send_signal(row['pidfd'],signal.SIGKILL)
            else:os.kill(row['pid'],signal.SIGKILL)
        if populated(group):(group/'cgroup.kill').write_text('1')
        while populated(group):
            require(time.monotonic()<end);time.sleep(.02)
        for row in self.children.values():
            if row['group']!=str(group) or row['reaped']:continue
            while time.monotonic()<end:
                pid,_=os.waitpid(row['pid'],os.WNOHANG)
                if pid:row['reaped']=True;break
                time.sleep(.02)
            require(row['reaped'])
    def release(self,deadline=None):
        from workflows_linux_trust import remaining
        deadline=deadline if deadline is not None else time.monotonic()+25
        remaining(deadline)
        require(not self.closed)
        if self.root/'sdk' in self.births:self.stop_group('sdk',deadline)
        if self.proxy is not None:
            try:receipt=self.proxy.stop(min(20,remaining(deadline)))
            finally:self.relay_metadata_retained=relay_metadata_evidence(self.proxy)
            require(receipt['admissionFenced'] is True and receipt['activeClients']==0 and receipt['workersJoined'] is True)
        for name in ('docker','daemon'):
            if self.root/name in self.births:self.stop_group(name,deadline)
        require(all(row['reaped'] for row in self.children.values()))
        remaining(deadline)
        if self.entered:
            require(start_ticks(os.getpid())==self.self_birth)
            (self.self_group/'cgroup.procs').write_text(str(os.getpid()))
            require(group_of(os.getpid())==self.original_group)
            self.entered=False
        # Docker-created kernel groups are disposable descendants of the exact
        # owned docker scope, never groups selected by process name or prefix.
        docker=self.root/'docker'
        if docker in self.handles:
            self.verify(docker);require(not populated(docker))
            for path in sorted(docker.rglob('*'),key=lambda p:len(p.parts),reverse=True):
                if path.is_dir():
                    require(not path.is_symlink() and path.resolve().is_relative_to(docker.resolve()) and not populated(path))
                    remaining(deadline);path.rmdir()
        for path in sorted(self.births,key=lambda p:len(p.parts),reverse=True):
            remaining(deadline)
            if path in self.handles:self.verify(path)
            else:require(self.births[path] is not None and identity(path)==self.births[path])
            require(not populated(path));path.rmdir()
            if path in self.handles:
                os.close(self.handles[path]);del self.handles[path]
            require(not path.exists())
        for row in self.children.values():
            if row['pidfd'] is not None:os.close(row['pidfd']);row['pidfd']=None
        require(not self.root.exists() and not self.handles)
        self.closed=True
        return dict(allChildrenReaped=True,allHandlesClosed=True,ownedGroupsAbsent=True,
                    relayMetadata=getattr(self,'relay_metadata_retained',relay_metadata_evidence(None)))
