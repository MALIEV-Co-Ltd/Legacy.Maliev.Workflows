# Test-local Linux retained Program helper, draft v1

This packet contains native source, not a qualified factory. No Linux compilation,
native execution, Auth compilation, SDK launch, or production change has occurred.
The managed Auth binding remains null. Windows has no Linux C compiler available.

The helper is a Linux x86_64 shared library loaded into the original managed
testhost. Its private bounded pthread owns direct fork, ptrace and exact waitpid;
there is no executable wrapper, delayed attachment, socket service or external
queue. All arguments/environment are copied before fork. The trusted child path
redirects stdout/stderr to anonymous pipes, preserves inherited stdin verbatim,
refuses stdin sockets or any additional inheritable descriptor before allocation,
closes extra CLOEXEC descriptors early, changes to the original absolute cwd, holds before
exec, then installs no_new_privs and an architecture-checked seccomp filter.
The parent observes IPv4/IPv6 socket syscall exits with EPERM and seccomp state
before the second preexec hold. The filter follows exec/descendants and additionally
refuses io_uring and Unix descriptor import. The parent observer/control stays
outside this scope.

## RetainedProgramOperations mapping

Factory/operations construction stores only managed launch data. The outer lease
is published before CreateOwnedSuspended. That operation marshals pc_request and
calls pc_create; it must retain *out on every return, including errors. Set
test_fault0 for every actual Auth Program; values1..8 inject real allocation,
hold/denial/resume failures only in the native regression harness. Do not use
a PInvoke out marshaller that discards the returned pointer when the error is
converted to an exception. pc_request.size is sizeof(pc_request), abi1. argv[0]
is the exact absolute executable; argv/envp are null-terminated UTF8 vectors.
No shell parsing is performed. Set deadlines once from pc_monotonic_ns at the
original lease origin, preserving the already elapsed portion of the managed
45-second lease and original min30 remaining work budget. No cleanup allowance
is subtracted from work admission. Recovery receives the caller's original shared
min5remaining absolute stop deadline; an exhausted lease quarantines custody.

ObserveExactIdentityAndPreExecHold maps to pc_observe_hold. The immutable
identity is original held PID/startticks/boot/executable; birth_utc_ns is a UTC
presentation derived from boot/realtime clocks, not the generation key. Do not
use CLR Process.StartTime as native generation custody. A Process.GetProcessById
representation may be retained for the existing caller's SafeHandle/HasExited
checks; CLR non-child ExitCode cannot supply a terminal outcome.

EnforceAndObserveProgramNetworkDenial maps to pc_enforce_denial. ResumeExactChild
maps to pc_resume. Both receive the already fixed absolute work deadline.
WaitForTerminalStatusAsync polls pc_observe without changing the native operation;
CancellationToken abandons only that managed waiter. Concurrent/repeated polls
copy the same mutex-protected status. terminal1 means exact waitpid reported
normal exit0..255 XOR signal1..64. Intermediate stops/exec/fork events are never
terminal. Native error remains visible even after recovery.

RecoverAndVerifyExactAbsenceAsync passes the caller's original absolute shared
stop deadline to pc_recover. It cannot extend an existing stop deadline or
exceed min5remaining lease. Recovery signals only kernel-registered unreaped
owned tasks, preferring retained pidfds, and collects exact terminal wait status.
Reaped task identity absence is independently checked. Unrelated reused PIDs
are preserved. Deadline failures retain custody and prevent release.

Stdout/Stderr transfer duplicates once via pc_take_readers; managed SafeFileHandle
owns those duplicates. Start both drains before waiting. After drains complete,
dispose both readers, then pc_ack_readers_closed independently checks descriptor
identity disappearance and original anonymous pipe HUP/zero unread bytes.
ReleaseVerifiedCustody is an exclusive pc_release after every managed waiter
settles. It requires native exact absence, terminal status where identity exists,
and transferred reader closure, uses bounded pthread_tryjoin_np polling through
the caller's original remaining release/drain deadline, then closes
original pipe/pidfd handles and frees state. Never retry using a freed pointer.

## Validation boundary and remaining source work

Makefile requests builds with warnings as errors; make check defines22 Linux cases:
normal17, signal9, intermediate stop, canceled poll followed by recovery, with
concurrent/repeated status, child-only IPv4/IPv6 denial and reader/custody release.
It also defines descendant recovery, cumulative64task refusal and eight real
partial-allocation/hold/denial/resume/fork fault injections. The fork-failure case
transfers and settles readers to verify writer closure. Harness assertion failures
attempt bounded exact recovery and reader drainage before reporting quarantine.
Three concurrent clone/fork runs request recovery after actual owned-task creation;
new tasks registered while stopping are killed before any child continuation.
Closed stdin stays closed, inherited input bytes arrive unchanged, and extra
inheritable descriptors are refused before any lease allocation. Native pipe
descriptors are moved above2 so allocation cannot replace an originally closed
standard descriptor or retain CLOEXEC on the child's redirected output.
Separate closed stdout/stderr cases verify parent descriptors remain closed while
the actual child receives both requested redirections; exact stdout bytes are
checked for every normal17 case.
The executable's --abi option emits actual sizeof/offsetof for both ABI structs
and every field, before any child creation. Hosted proof must join that raw
output to the exact fresh ELF and the managed Marshal layout; source estimates
of offsets are not runtime observations.

The harness retains a CLOEXEC journal descriptor so closed-parent stdout tests
still emit observations. Every actual case has a unique numeric case ID,
including the three concurrent race runs and preallocation refusal. Held,
denied-held, native terminal and released observations include original PID/
startticks/boot/executable, timestamps/deadlines and owned/reaped task counts.
Normal cases establish live IPv4/IPv6 parent loopback TCP byte exchange both
before create and after release, with observed ports and socket closure. This
source addition is uncompiled; it is not a native qualification receipt.
The harness uses one shared absolute stop deadline and one drain deadline per
case, capped by its original lease, and reuses them during failure cleanup.
Journal fflush/ferror and ABI stdout checks explicitly fail on incomplete
output. Terminal reaping clears the current-held flag; the historical held
identity remains immutable. Transport must still require every exact case/
phase/layout record before accepting an actual run.
They are source only and have NOT been executed here. Supplemental Python checks
only inspect source constraints and cannot establish OS behavior.

This draft is not ready for qualification: it still needs complete actual fault
injection at every native allocation boundary, generation-substitution tests,
work timeout/output overflow/reader failure,
recovery-failure quarantine verification, and the original Auth Program test.
At cumulative64 traced tasks, syscall-entry reservations refuse new fork/clone
with EAGAIN before allocation; concurrent reservations count toward that ceiling.
This path remains unexecuted and requires actual task-ceiling tests. Nonleader
exec identity transfer is deliberately refused. Actual
Linux compilation/kernel tests must expose and resolve these paths before a
sealed reviewed adapter or any capability/receipt can be activated.

The preserved inherited stdin and explicit extra-descriptor refusal still need
exact managed launch snapshot review. No SDK floor, host policy, frozen Auth route,
capability pin or five-file candidate is changed by this source draft.
