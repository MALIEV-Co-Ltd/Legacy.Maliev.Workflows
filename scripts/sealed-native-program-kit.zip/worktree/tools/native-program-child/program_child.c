#define _GNU_SOURCE
#include "program_child.h"
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <linux/audit.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <pthread.h>
#include <poll.h>
#include <signal.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/prctl.h>
#include <sys/ptrace.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/syscall.h>
#include <sys/user.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#if !defined(__linux__) || !defined(__x86_64__)
#error This unqualified ABI supports only Linux x86_64
#endif

#define PC_TASKS 64
#define PC_NS 1000000000LL
enum { NEW, HELD, DENYING, DENIED, RUNNING, FINISHED };
struct task { pid_t pid, tgid; int pidfd, done, newborn, creating, refused; uint64_t ticks; };
struct pc_lease {
    pthread_mutex_t lock;
    pthread_t owner;
    int owner_started, owner_done, stage, request_denial, request_resume;
    int recover, readers_taken, readers_closed, stopping;
    int pipes[2][2];
    int reader_fds[2];
    struct stat reader_identity[2];
    int64_t lease_end, work_end, stop_end;
    char *exe, *cwd, **argv, **envp;
    struct task tasks[PC_TASKS];
    unsigned count;
    unsigned reservations;
    uint32_t test_fault;
    int probe_family, probes;
    pc_observation observation;
};

int64_t pc_monotonic_ns(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts)) return -1;
    return (int64_t)ts.tv_sec * PC_NS + ts.tv_nsec;
}
static void pause_tick(void) {
    struct timespec ts = {0, 1000000};
    nanosleep(&ts, NULL);
}
static void close_fd(int *fd) { if (*fd >= 0) { close(*fd); *fd = -1; } }
static void fail(pc_lease *l, int error) {
    if (!l->observation.native_error) l->observation.native_error = error ? error : EIO;
    l->recover = 1;
}
static char **copy_vector(const char *const *v) {
    size_t n = 0, bytes = 0;
    if (!v) { errno = EINVAL; return NULL; }
    while (v[n]) {
        size_t length = strnlen(v[n], 131073);
        if (n >= 4096 || length > 131072 || bytes + length > 1048576) {
            errno = E2BIG; return NULL;
        }
        bytes += length; ++n;
    }
    char **r = calloc(n + 1, sizeof(*r));
    if (!r) return NULL;
    for (size_t i = 0; i < n; ++i) {
        r[i] = strdup(v[i]);
        if (!r[i]) {
            for (size_t j = 0; j < i; ++j) free(r[j]);
            free(r); return NULL;
        }
    }
    return r;
}
static void free_vector(char **v) {
    if (!v) return;
    for (size_t i = 0; v[i]; ++i) free(v[i]);
    free(v);
}
/* Preserve inherited stdin. Refuse unmodeled inherited descriptors/sockets
 * BEFORE allocating a lease, pipe, thread, or child. CLOEXEC descriptors would
 * disappear at the original direct exec and are not inherited Program facts. */
static int inherited_descriptor_preflight(void) {
    struct stat input;
    if (!fstat(STDIN_FILENO, &input) && S_ISSOCK(input.st_mode)) return ENOTSUP;
    DIR *dir = opendir("/proc/self/fd");
    if (!dir) return errno;
    int error = 0;
    struct dirent *entry;
    while ((entry = readdir(dir))) {
        char *end; errno = 0;
        long fd = strtol(entry->d_name, &end, 10);
        if (errno || *end || fd < 3 || fd > 2147483647L) continue;
        int flags = fcntl((int)fd, F_GETFD);
        if (flags < 0 && errno != EBADF) { error = errno; break; }
        if (flags >= 0 && !(flags & FD_CLOEXEC)) { error = ENOTSUP; break; }
    }
    closedir(dir); return error;
}
static int create_pipe_above_stdio(int fds[2]) {
    if (pipe2(fds, O_CLOEXEC)) return errno;
    for (int i = 0; i < 2; ++i) if (fds[i] < 3) {
        /* A closed inherited stdin/stdout must stay closed in the parent and
         * cannot become our pipe. Source pipe FD>=3 also ensures dup2 clears
         * CLOEXEC even when the child's original stdout/stderr was closed. */
        int moved = fcntl(fds[i], F_DUPFD_CLOEXEC, 3);
        if (moved < 0) return errno;
        close_fd(&fds[i]); fds[i] = moved;
    }
    return 0;
}
static int read_text(const char *path, char *buf, size_t cap) {
    int fd = open(path, O_RDONLY | O_CLOEXEC);
    if (fd < 0) return errno;
    ssize_t n = read(fd, buf, cap - 1);
    int error = n < 0 ? errno : 0;
    close(fd);
    if (!error) buf[n] = 0;
    return error;
}
static int identity(pid_t pid, uint64_t *ticks, pid_t *tgid, char *exe) {
    char path[64], buf[8192];
    snprintf(path, sizeof(path), "/proc/%d/stat", pid);
    int error = read_text(path, buf, sizeof(buf));
    if (error) return error;
    char *p = strrchr(buf, ')');
    if (!p || p[1] != ' ') return EPROTO;
    p += 2;
    /* comm may contain spaces/parentheses; field3 starts AFTER last ')'. */
    for (int field = 3; field < 22; ++field) {
        p = strchr(p, ' ');
        if (!p) return EPROTO;
        ++p;
    }
    errno = 0; char *end;
    *ticks = strtoull(p, &end, 10);
    if (errno || end == p || !*ticks) return EPROTO;
    snprintf(path, sizeof(path), "/proc/%d/status", pid);
    error = read_text(path, buf, sizeof(buf));
    if (error) return error;
    p = strstr(buf, "Tgid:\t");
    if (!p || sscanf(p, "Tgid:\t%d", tgid) != 1 || *tgid <= 0) return EPROTO;
    if (exe) {
        snprintf(path, sizeof(path), "/proc/%d/exe", pid);
        ssize_t n = readlink(path, exe, 4095);
        if (n < 0) return errno;
        exe[n] = 0;
    }
    return 0;
}
static int same_task(const struct task *t) {
    uint64_t ticks; pid_t tgid;
    int e = identity(t->pid, &ticks, &tgid, NULL);
    return e ? e : (ticks == t->ticks && tgid == t->tgid ? 0 : ESTALE);
}
static int register_task(pc_lease *l, pid_t pid, int newborn) {
    if (l->count >= PC_TASKS) return E2BIG;
    struct task *t = &l->tasks[l->count];
    t->pid = pid; t->pidfd = -1; t->newborn = newborn;
    /* The ptrace event is kernel evidence of this unreaped owned task.
     * Retain it before proc/pidfd reads can fail. */
    ++l->count; l->observation.owned_tasks = l->count;
    int e = identity(pid, &t->ticks, &t->tgid,
                     NULL);
    if (e) return e;
    if (t->pid == t->tgid) {
        t->pidfd = (int)syscall(SYS_pidfd_open, pid, 0);
        if (t->pidfd < 0) return errno;
    }
    return 0;
}

/* Child path uses only syscalls and already prepared native memory. */
static void child(pc_lease *l) {
    if (syscall(SYS_dup2, l->pipes[0][1], STDOUT_FILENO) < 0 ||
        syscall(SYS_dup2, l->pipes[1][1], STDERR_FILENO) < 0) _exit(120);
    /* stdin is inherited verbatim. Preflight admits only CLOEXEC extra FDs;
     * closing them early matches their original direct-exec disappearance. */
    if (syscall(SYS_close_range, 3U, ~0U, 0U) < 0) _exit(122);
    if (syscall(SYS_chdir, l->cwd) < 0 || syscall(SYS_setpgid, 0, 0) < 0) _exit(123);
    if (syscall(SYS_ptrace, PTRACE_TRACEME, 0, 0, 0) < 0) _exit(124);
    syscall(SYS_kill, syscall(SYS_getpid), SIGSTOP);
    struct sock_filter filter[] = {
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, arch)),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_X86_64, 1, 0),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),
        BPF_JUMP(BPF_JMP | BPF_JSET | BPF_K, 0x40000000U, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_socket, 0, 4),
        BPF_STMT(BPF_LD | BPF_W | BPF_ABS, offsetof(struct seccomp_data, args[0])),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AF_UNIX, 1, 0),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO | EPERM),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_io_uring_setup, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO | EPERM),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_ptrace, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO | EPERM),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_recvmsg, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO | EPERM),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, SYS_recvmmsg, 0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ERRNO | EPERM),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW)
    };
    struct sock_fprog program = {(unsigned short)(sizeof(filter) / sizeof(filter[0])), filter};
    if (syscall(SYS_prctl, PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0) < 0 ||
        syscall(SYS_seccomp, SECCOMP_SET_MODE_FILTER, 0, &program) < 0) _exit(125);
    syscall(SYS_socket, AF_INET, SOCK_STREAM, 0);
    syscall(SYS_socket, AF_INET6, SOCK_STREAM, 0);
    syscall(SYS_kill, syscall(SYS_getpid), SIGSTOP);
    syscall(SYS_execve, l->exe, l->argv, l->envp);
    _exit(126);
}
static int continue_task(struct task *t, int syscall_mode, int signal) {
    if (same_task(t)) return ESTALE;
    if (ptrace(syscall_mode ? PTRACE_SYSCALL : PTRACE_CONT, t->pid, NULL,
               (void *)(intptr_t)signal) < 0) return errno;
    return 0;
}
static int denial_readback(pc_lease *l) {
    char path[64], buf[8192], exe[4096]; uint64_t ticks; pid_t tgid;
    int e = identity(l->tasks[0].pid, &ticks, &tgid, exe);
    if (e || ticks != l->observation.start_ticks || strcmp(exe, l->observation.executable)) return e ? e : ESTALE;
    snprintf(path, sizeof(path), "/proc/%d/status", l->observation.pid);
    e = read_text(path, buf, sizeof(buf));
    if (e || !strstr(buf, "NoNewPrivs:\t1\n") || !strstr(buf, "Seccomp:\t2\n") || l->probes != 3) return e ? e : EACCES;
    return 0;
}
static void observe_event(pc_lease *l, unsigned index, int status) {
    struct task *t = &l->tasks[index];
    if (WIFEXITED(status) || WIFSIGNALED(status)) {
        t->done = 1; ++l->observation.reaped_tasks;
        if (!index) {
            l->observation.terminal = 1;
            l->observation.preexec_held = 0;
            l->observation.exit_code = WIFEXITED(status) ? WEXITSTATUS(status) : -1;
            l->observation.signal = WIFSIGNALED(status) ? WTERMSIG(status) : -1;
        }
        return;
    }
    if (!WIFSTOPPED(status)) { fail(l, EPROTO); return; }
    int signal = WSTOPSIG(status); unsigned event = (unsigned)status >> 16;
    if (!index && l->stage == NEW && signal == SIGSTOP && !event) {
        int e = same_task(t);
        char exe[4096]; uint64_t ticks; pid_t tgid;
        if (!e) e = identity(t->pid, &ticks, &tgid, exe);
        if (!e) memcpy(l->observation.executable, exe, strlen(exe) + 1);
        long options = PTRACE_O_EXITKILL | PTRACE_O_TRACEFORK | PTRACE_O_TRACEVFORK |
                       PTRACE_O_TRACECLONE | PTRACE_O_TRACEEXEC | PTRACE_O_TRACESYSGOOD;
        if (!e && ptrace(PTRACE_SETOPTIONS, t->pid, NULL, (void *)options) < 0) e = errno;
        if (!e && l->test_fault == 5) e = EIO;
        if (e) { fail(l, e); return; }
        l->stage = HELD; l->observation.preexec_held = 1; return;
    }
    if (!index && l->stage == DENYING && signal == (SIGTRAP | 0x80)) {
        struct user_regs_struct regs;
        if (ptrace(PTRACE_GETREGS, t->pid, NULL, &regs) < 0) { fail(l, errno); return; }
        if (regs.orig_rax == SYS_socket) {
            if ((int64_t)regs.rax == -ENOSYS) l->probe_family = (int)regs.rdi;
            else if (l->probe_family == AF_INET || l->probe_family == AF_INET6) {
                if ((int64_t)regs.rax != -EPERM) { fail(l, EACCES); return; }
                l->probes |= l->probe_family == AF_INET ? 1 : 2;
                l->probe_family = 0;
            }
        }
        int e = continue_task(t, 1, 0); if (e) fail(l, e); return;
    }
    if (!index && l->stage == DENYING && signal == SIGSTOP && !event) {
        int e = denial_readback(l);
        if (e) fail(l, e);
        else { l->stage = DENIED; l->observation.denial_observed = 1; }
        return;
    }
    if (l->stage == RUNNING && signal == (SIGTRAP | 0x80)) {
        struct user_regs_struct regs;
        if (ptrace(PTRACE_GETREGS, t->pid, NULL, &regs) < 0) { fail(l, errno); return; }
        if (t->refused) {
            regs.rax = (unsigned long long)-EAGAIN;
            if (ptrace(PTRACE_SETREGS, t->pid, NULL, &regs) < 0) { fail(l, errno); return; }
            t->refused = 0;
        } else if (t->creating) {
            /* Failed creation: no fork event consumed this reservation. */
            t->creating = 0; --l->reservations;
        } else if ((int64_t)regs.rax == -ENOSYS &&
                   (regs.orig_rax == SYS_clone || regs.orig_rax == SYS_clone3 ||
                    regs.orig_rax == SYS_fork || regs.orig_rax == SYS_vfork)) {
            if (l->count + l->reservations >= PC_TASKS) {
                /* Refuse before the kernel allocates an unretainable task. */
                regs.orig_rax = (unsigned long long)-1;
                if (ptrace(PTRACE_SETREGS, t->pid, NULL, &regs) < 0) { fail(l, errno); return; }
                t->refused = 1;
            } else { t->creating = 1; ++l->reservations; }
        }
        int e = continue_task(t, 1, 0); if (e) fail(l, e); return;
    }
    if (event == PTRACE_EVENT_FORK || event == PTRACE_EVENT_VFORK || event == PTRACE_EVENT_CLONE) {
        unsigned long pid;
        if (ptrace(PTRACE_GETEVENTMSG, t->pid, NULL, &pid) < 0) { fail(l, errno); return; }
        if (!t->creating || !l->reservations) { fail(l, EPROTO); return; }
        t->creating = 0; --l->reservations;
        int e = register_task(l, (pid_t)pid, 1);
        if (e) { fail(l, e); return; }
        if (l->stopping) {
            struct task *new_task = &l->tasks[l->count - 1];
            int result = new_task->pidfd >= 0
                ? (int)syscall(SYS_pidfd_send_signal, new_task->pidfd, SIGKILL, NULL, 0)
                : kill(new_task->pid, SIGKILL);
            if (result < 0 && errno != ESRCH) fail(l, errno);
            /* Never resume a newly registered descendant during recovery. */
        }
        e = continue_task(t, 1, 0); if (e) fail(l, e); return;
    }
    if (event == PTRACE_EVENT_EXEC) {
        unsigned long former;
        if (ptrace(PTRACE_GETEVENTMSG, t->pid, NULL, &former) < 0 || former != (unsigned long)t->pid) {
            fail(l, ENOTSUP); return; /* nonleader exec requires separately reviewed identity transfer */
        }
        int e = continue_task(t, 1, 0); if (e) fail(l, e); return;
    }
    if (signal == SIGSTOP) { t->newborn = 0; signal = 0; }
    int e = continue_task(t, 1, signal); if (e) fail(l, e);
}
static void begin_stop(pc_lease *l) {
    l->stopping = 1;
    int64_t now = pc_monotonic_ns();
    if (!l->stop_end || l->stop_end > now + 5 * PC_NS) l->stop_end = now + 5 * PC_NS;
    if (l->stop_end > l->lease_end) l->stop_end = l->lease_end;
    for (unsigned i = 0; i < l->count; ++i) {
        struct task *t = &l->tasks[i];
        if (t->done) continue;
        if (t->pidfd < 0) {
            /* Includes retained threads and partial pidfd failures. Every PID
             * here came from fork or GETEVENTMSG and remains unreaped by this
             * sole native owner. No PID reuse is possible before exact wait. */
            if (kill(t->pid, SIGKILL) < 0 && errno != ESRCH) fail(l, errno);
            continue;
        }
        int e = t->ticks ? same_task(t) : 0;
        if (!e && syscall(SYS_pidfd_send_signal, t->pidfd, SIGKILL, NULL, 0) < 0 && errno != ESRCH) e = errno;
        if (e && e != ENOENT && e != ESRCH) fail(l, e);
    }
}
static void *owner(void *arg) {
    pc_lease *l = arg;
    pthread_mutex_lock(&l->lock);
    pid_t pid = l->test_fault == 8 ? -1 : fork();
    if (l->test_fault == 8) errno = EAGAIN;
    if (!pid) child(l);
    if (pid < 0) {
        fail(l, errno); l->owner_done = 1; l->observation.exact_absence = 1;
        close_fd(&l->pipes[0][1]); close_fd(&l->pipes[1][1]);
        pthread_mutex_unlock(&l->lock); return NULL;
    }
    /* Retain the fork result before any observation can fail. pidfd_open
     * below cannot race reuse: this owner is the only exact child reaper. */
    l->tasks[0].pid = pid; l->tasks[0].tgid = pid;
    l->tasks[0].pidfd = (int)syscall(SYS_pidfd_open, pid, 0);
    l->count = 1; l->observation.owned_tasks = 1;
    if (l->tasks[0].pidfd < 0) {
        fail(l, errno);
        /* Original unreaped direct child PID cannot be reused. */
        if (kill(pid, SIGKILL) < 0 && errno != ESRCH) fail(l, errno);
    } else {
        uint64_t ticks; pid_t tgid;
        int e = identity(pid, &ticks, &tgid, l->observation.executable);
        if (e) fail(l, e);
        else {
            l->tasks[0].ticks = ticks; l->tasks[0].tgid = tgid;
            l->observation.pid = pid; l->observation.start_ticks = ticks;
            char boot_id[64];
            e = read_text("/proc/sys/kernel/random/boot_id", boot_id, sizeof(boot_id));
            if (e || strlen(boot_id) != 37 || boot_id[36] != '\n') fail(l, e ? e : EPROTO);
            else memcpy(l->observation.boot_id, boot_id, 36);
            struct timespec real, boot;
            long hz = sysconf(_SC_CLK_TCK);
            if (hz <= 0 || clock_gettime(CLOCK_REALTIME, &real) || clock_gettime(CLOCK_BOOTTIME, &boot)) fail(l, EPROTO);
            else l->observation.birth_utc_ns = ((int64_t)real.tv_sec - boot.tv_sec) * PC_NS
                + real.tv_nsec - boot.tv_nsec + (int64_t)(ticks / (uint64_t)hz) * PC_NS
                + (int64_t)(ticks % (uint64_t)hz) * PC_NS / hz;
        }
    }
    close_fd(&l->pipes[0][1]); close_fd(&l->pipes[1][1]);
    if (l->test_fault == 4) fail(l, EIO);
    pthread_mutex_unlock(&l->lock);
    for (;;) {
        pthread_mutex_lock(&l->lock);
        int64_t now = pc_monotonic_ns();
        {
            for (unsigned i = 0; i < l->count; ++i) {
                if (l->tasks[i].done) continue;
                int status; pid_t waited = waitpid(l->tasks[i].pid, &status, WNOHANG | __WALL);
                if (waited == l->tasks[i].pid) observe_event(l, i, status);
                else if (waited < 0 && errno != EINTR) fail(l, errno);
            }
        }
        if (!l->stopping && now >= l->work_end) fail(l, ETIMEDOUT);
        if (!l->stopping && l->recover) begin_stop(l);
        if (l->stage == HELD && l->request_denial && !l->stopping) {
            if (l->test_fault == 6) { fail(l, EACCES); pthread_mutex_unlock(&l->lock); continue; }
            l->stage = DENYING;
            int e = continue_task(&l->tasks[0], 1, 0); if (e) fail(l, e);
        }
        if (l->stage == DENIED && l->request_resume && !l->stopping) {
            int e = l->test_fault == 7 ? EIO : denial_readback(l);
            if (!e) e = continue_task(&l->tasks[0], 1, 0);
            if (e) fail(l, e);
            else { l->stage = RUNNING; l->observation.preexec_held = 0; }
        }
        if (l->count && l->observation.reaped_tasks == l->count) {
            /* Reap is necessary, but independently observe exact proc absence. */
            int absent = 1;
            for (unsigned i = 0; i < l->count; ++i) {
                int e = same_task(&l->tasks[i]);
                if (e == ESTALE) continue; /* original retained task was reaped; new PID occupant is preserved */
                if (e != ENOENT && e != ESRCH) absent = 0;
            }
            if (absent) { l->observation.exact_absence = 1; l->stage = FINISHED; l->owner_done = 1; }
        }
        if (l->owner_done || now >= l->lease_end || (l->stopping && now >= l->stop_end)) {
            if (!l->owner_done) fail(l, ETIMEDOUT);
            l->owner_done = 1;
            pthread_mutex_unlock(&l->lock); return NULL;
        }
        pthread_mutex_unlock(&l->lock); pause_tick();
    }
}

int pc_create(const pc_request *r, pc_lease **out) {
    if (!out || *out || !r || r->size != sizeof(*r) || r->abi != 1 || r->test_fault > 8) return EINVAL;
    int64_t now = pc_monotonic_ns();
    if (now < 0 || r->lease_deadline_ns <= now || r->lease_deadline_ns > now + 45 * PC_NS ||
        r->work_deadline_ns <= now || r->work_deadline_ns > now + 30 * PC_NS ||
        r->work_deadline_ns > r->lease_deadline_ns ||
        !r->executable || r->executable[0] != '/' || !r->cwd || r->cwd[0] != '/') return EINVAL;
    int preflight = inherited_descriptor_preflight();
    if (preflight) return preflight;
    pc_lease *l = calloc(1, sizeof(*l));
    if (!l) return ENOMEM;
    for (int i = 0; i < 2; ++i) l->pipes[i][0] = l->pipes[i][1] = -1;
    for (int i = 0; i < PC_TASKS; ++i) l->tasks[i].pidfd = -1;
    int e = pthread_mutex_init(&l->lock, NULL);
    if (e) { free(l); return e; }
    *out = l;
    l->test_fault = r->test_fault;
    l->lease_end = r->lease_deadline_ns; l->work_end = r->work_deadline_ns;
    l->observation.size = sizeof(l->observation); l->observation.abi = 1;
    l->observation.exit_code = l->observation.signal = -1;
    if (l->test_fault != 1) {
        l->exe = strdup(r->executable); l->cwd = strdup(r->cwd);
        l->argv = copy_vector(r->argv); l->envp = copy_vector(r->envp);
    }
    if (!l->exe || !l->cwd || !l->argv || !l->envp) e = errno ? errno : ENOMEM;
    if (!e && (!l->argv[0] || strcmp(l->argv[0], l->exe))) e = EINVAL;
    for (int i = 0; !e && i < 2; ++i) {
        e = create_pipe_above_stdio(l->pipes[i]);
        if (!e && i == 0 && l->test_fault == 2) e = EIO;
    }
    if (!e && l->test_fault == 3) e = EAGAIN;
    if (!e) e = pthread_create(&l->owner, NULL, owner, l);
    if (e) {
        close_fd(&l->pipes[0][1]); close_fd(&l->pipes[1][1]);
        l->observation.native_error = e; l->owner_done = 1;
        l->observation.exact_absence = 1; return e;
    }
    l->owner_started = 1;
    for (;;) {
        pthread_mutex_lock(&l->lock);
        int ready = l->stage == HELD, error = l->observation.native_error;
        pthread_mutex_unlock(&l->lock);
        if (ready) return 0;
        if (error) return error;
        if (pc_monotonic_ns() >= l->work_end) return ETIMEDOUT;
        pause_tick();
    }
}
int pc_observe(pc_lease *l, pc_observation *o) {
    if (!l || !o || o->size != sizeof(*o) || o->abi != 1) return EINVAL;
    pthread_mutex_lock(&l->lock); *o = l->observation; pthread_mutex_unlock(&l->lock);
    return 0;
}
int pc_observe_hold(pc_lease *l, pc_observation *o) {
    if (!l || !o || o->size != sizeof(*o) || o->abi != 1) return EINVAL;
    pthread_mutex_lock(&l->lock);
    int e = (l->stage != HELD && l->stage != DENIED) ? EBUSY : same_task(&l->tasks[0]);
    if (!e) {
        char exe[4096], boot[64]; uint64_t ticks; pid_t tgid;
        e = identity(l->observation.pid, &ticks, &tgid, exe);
        if (!e && strcmp(exe, l->observation.executable)) e = ESTALE;
        if (!e) e = read_text("/proc/sys/kernel/random/boot_id", boot, sizeof(boot));
        if (!e && (strlen(boot) != 37 || memcmp(boot, l->observation.boot_id, 36))) e = ESTALE;
    }
    if (!e) *o = l->observation;
    pthread_mutex_unlock(&l->lock); return e;
}
static int transition(pc_lease *l, int64_t deadline, int resume) {
    if (!l) return EINVAL;
    pthread_mutex_lock(&l->lock);
    if (deadline > l->work_end || deadline <= pc_monotonic_ns() ||
        l->stage != (resume ? DENIED : HELD)) { pthread_mutex_unlock(&l->lock); return EINVAL; }
    if (resume) l->request_resume = 1; else l->request_denial = 1;
    pthread_mutex_unlock(&l->lock);
    for (;;) {
        pthread_mutex_lock(&l->lock);
        int ready = resume ? l->stage >= RUNNING : l->stage == DENIED;
        int error = l->observation.native_error;
        pthread_mutex_unlock(&l->lock);
        if (error) return error;
        if (ready) return 0;
        if (pc_monotonic_ns() >= deadline) return ETIMEDOUT;
        pause_tick();
    }
}
int pc_enforce_denial(pc_lease *l, int64_t deadline) { return transition(l, deadline, 0); }
int pc_resume(pc_lease *l, int64_t deadline) { return transition(l, deadline, 1); }
int pc_recover(pc_lease *l, int64_t deadline) {
    if (!l) return EINVAL;
    pthread_mutex_lock(&l->lock);
    int64_t now = pc_monotonic_ns();
    if (l->observation.exact_absence) { pthread_mutex_unlock(&l->lock); return 0; }
    if (deadline <= now || deadline > l->lease_end || deadline > now + 5 * PC_NS) {
        pthread_mutex_unlock(&l->lock); return EINVAL;
    }
    if (!l->stop_end || deadline < l->stop_end) l->stop_end = deadline;
    l->recover = 1;
    pthread_mutex_unlock(&l->lock);
    for (;;) {
        pthread_mutex_lock(&l->lock);
        int absent = l->observation.exact_absence, done = l->owner_done;
        pthread_mutex_unlock(&l->lock);
        if (absent) return 0;
        if (done || pc_monotonic_ns() >= deadline) return ETIMEDOUT;
        pause_tick();
    }
}
int pc_take_readers(pc_lease *l, int *out, int *err) {
    if (!l || !out || !err) return EINVAL;
    pthread_mutex_lock(&l->lock);
    int e = 0;
    if (l->readers_taken || l->pipes[0][0] < 0 || l->pipes[1][0] < 0) e = EBUSY;
    else {
        *out = fcntl(l->pipes[0][0], F_DUPFD_CLOEXEC, 3);
        *err = *out < 0 ? -1 : fcntl(l->pipes[1][0], F_DUPFD_CLOEXEC, 3);
        if (*out < 0 || *err < 0) { e = errno; close_fd(out); close_fd(err); }
        else if (fstat(*out, &l->reader_identity[0]) || fstat(*err, &l->reader_identity[1])) {
            e = errno; close_fd(out); close_fd(err);
        } else {
            l->reader_fds[0] = *out; l->reader_fds[1] = *err;
            l->readers_taken = 1;
        }
    }
    pthread_mutex_unlock(&l->lock); return e;
}
int pc_ack_readers_closed(pc_lease *l) {
    if (!l) return EINVAL;
    pthread_mutex_lock(&l->lock);
    if (!l->observation.exact_absence) { pthread_mutex_unlock(&l->lock); return EBUSY; }
    for (int i = 0; i < 2 && l->readers_taken; ++i) {
        struct stat current;
        int exists = fstat(l->reader_fds[i], &current);
        if ((!exists && current.st_dev == l->reader_identity[i].st_dev &&
             current.st_ino == l->reader_identity[i].st_ino) || (exists && errno != EBADF)) {
            pthread_mutex_unlock(&l->lock); return EBUSY;
        }
        /* Independent pipe settlement, not merely a managed acknowledgement. */
        struct pollfd p = {.fd = l->pipes[i][0], .events = POLLIN | POLLHUP};
        int bytes = -1;
        if (poll(&p, 1, 0) != 1 || !(p.revents & POLLHUP) ||
            ioctl(l->pipes[i][0], FIONREAD, &bytes) < 0 || bytes != 0) {
            pthread_mutex_unlock(&l->lock); return EBUSY;
        }
    }
    l->readers_closed = 1;
    pthread_mutex_unlock(&l->lock); return 0;
}
int pc_release(pc_lease **handle, int64_t deadline) {
    if (!handle || !*handle) return EINVAL;
    pc_lease *l = *handle;
    pthread_mutex_lock(&l->lock);
    if (!l->owner_done || !l->observation.exact_absence ||
        (l->observation.pid && !l->observation.terminal) ||
        (l->readers_taken && !l->readers_closed)) { pthread_mutex_unlock(&l->lock); return EBUSY; }
    pthread_mutex_unlock(&l->lock);
    if (deadline > l->lease_end) return EINVAL;
    if (l->owner_started) {
        for (;;) {
            int e = pthread_tryjoin_np(l->owner, NULL);
            if (!e) break;
            if (e != EBUSY) return e;
            if (pc_monotonic_ns() >= deadline) return ETIMEDOUT;
            pause_tick();
        }
    }
    for (int i = 0; i < 2; ++i) for (int j = 0; j < 2; ++j) close_fd(&l->pipes[i][j]);
    for (unsigned i = 0; i < PC_TASKS; ++i) close_fd(&l->tasks[i].pidfd);
    free(l->exe); free(l->cwd); free_vector(l->argv); free_vector(l->envp);
    pthread_mutex_destroy(&l->lock); free(l); *handle = NULL; return 0;
}
