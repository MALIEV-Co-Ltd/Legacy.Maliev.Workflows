"""Supplemental source checks; never a substitute for Linux compile/OS proof."""
import hashlib
import json
from pathlib import Path
import re
import unittest

BASE = Path(__file__).resolve().parent
C = (BASE / "program_child.c").read_text(encoding="utf-8")
H = (BASE / "program_child.h").read_text(encoding="utf-8")
TEST = (BASE / "test_program_child.c").read_text(encoding="utf-8")


class SourceContract(unittest.TestCase):
    def test_declared_abi_has_implementation(self):
        names = re.findall(r"(?:int|int64_t) (pc_\w+)\(", H)
        self.assertEqual(len(names), 10)
        for name in names:
            self.assertRegex(C, rf"(?:int|int64_t) {name}\(")

    def test_exact_wait_and_signal_scope(self):
        self.assertNotRegex(C, r"waitpid\(\s*-1|kill\(\s*-|PTRACE_ATTACH|PTRACE_DETACH")
        self.assertIn("waitpid(l->tasks[i].pid", C)
        self.assertIn("SYS_pidfd_send_signal", C)
        self.assertIn("PTRACE_O_EXITKILL", C)

    def test_preexec_denial_evidence(self):
        self.assertIn("PTRACE_SYSCALL", C)
        self.assertIn("regs.rax != -EPERM", C)
        self.assertIn("NoNewPrivs:", C)
        self.assertIn("Seccomp:", C)
        self.assertIn("AUDIT_ARCH_X86_64", C)
        self.assertIn("0x40000000U", C)
        self.assertIn("SYS_io_uring_setup", C)
        self.assertIn("SYS_close_range", C)

    def test_partial_custody_precedes_native_allocations(self):
        published = C.index("*out = l;")
        self.assertLess(published, C.index("l->exe = strdup"))
        self.assertLess(published, C.index("e = create_pipe_above_stdio(l->pipes[i])"))
        self.assertLess(published, C.index("pthread_create(&l->owner"))
        retained = C.index("l->count = 1;")
        self.assertLess(retained, C.index("int e = identity(pid, &ticks"))

    def test_original_caps_cannot_renew(self):
        self.assertIn("now + 45 * PC_NS", C)
        self.assertIn("now + 30 * PC_NS", C)
        self.assertIn("r->work_deadline_ns > r->lease_deadline_ns", C)
        self.assertNotIn("l->lease_end - 5 * PC_NS", C)
        self.assertIn("deadline < l->stop_end", C)
        self.assertEqual(C.count("l->lease_end ="), 1)
        self.assertEqual(C.count("l->work_end ="), 1)

    def test_terminal_wait_not_stops(self):
        terminal = C.index("l->observation.terminal = 1;")
        self.assertLess(C.index("if (WIFEXITED(status) || WIFSIGNALED(status))"), terminal)
        self.assertLess(terminal, C.index("if (!WIFSTOPPED(status))"))
        self.assertIn("WEXITSTATUS(status) : -1", C)
        self.assertIn("WTERMSIG(status) : -1", C)

    def test_reader_absence_independently_observed(self):
        self.assertIn("current.st_ino == l->reader_identity[i].st_ino", C)
        self.assertIn("FIONREAD", C)
        self.assertIn("POLLHUP", C)
        self.assertIn("pthread_tryjoin_np(l->owner", C)
        self.assertNotIn("pthread_join(", C)

    def test_real_test_cases_are_pending_not_model_qualification(self):
        for mode in ("normal", "signal", "stop", "slow"):
            self.assertIn(f'run(exe, "{mode}")', TEST)
        self.assertIn("live parent connection outside child denial", TEST)
        self.assertIn("Auth Program qualification remains separate", TEST)
        self.assertIn("-Werror", (BASE / "Makefile").read_text())

    def test_faults_are_explicit_source_inputs_not_receipts(self):
        self.assertIn("uint32_t test_fault", H)
        for point in range(1, 9):
            self.assertIn(f"l->test_fault == {point}" if point != 1 else "l->test_fault != 1", C)
        self.assertIn("run_fault(exe, point)", TEST)
        self.assertNotIn("QualifiedProgramLaunchFactory", C)

    def test_inherited_launch_and_partial_writers(self):
        self.assertNotIn('"/dev/null"', C)
        self.assertIn("inherited_descriptor_preflight()", C)
        self.assertLess(C.index("int preflight = inherited_descriptor_preflight()"), C.index("pc_lease *l = calloc"))
        self.assertIn("failed fork writers closed/EOF", TEST)
        self.assertIn("failure_cleanup(); exit(1)", TEST)

    def test_newborn_during_stop_is_never_resumed(self):
        event = C[C.index("if (event == PTRACE_EVENT_FORK"):C.index("if (event == PTRACE_EVENT_EXEC")]
        self.assertIn("if (l->stopping)", event)
        self.assertIn("new_task->pidfd, SIGKILL", event)
        self.assertNotIn("continue_task(new_task", event)

    def test_closed_standard_input_cannot_be_reallocated_as_pipe(self):
        self.assertIn("create_pipe_above_stdio", C)
        self.assertIn("F_DUPFD_CLOEXEC, 3", C)
        self.assertIn("parent closed stdin preserved", TEST)
        self.assertIn("extra inheritable descriptor refused before allocation", TEST)
        self.assertIn("parent closed stdout preserved", TEST)
        self.assertIn("parent closed stderr preserved", TEST)
        self.assertIn("exact redirected stdout bytes", TEST)

    def test_compiled_abi_and_raw_native_case_observations(self):
        self.assertIn('"--abi"', TEST)
        self.assertIn("sizeof(pc_request)", TEST)
        self.assertIn("offsetof(pc_observation, start_ticks)", TEST)
        for phase in ("held", "denied-held", "terminal", "released"):
            self.assertIn(f'"{phase}"', TEST)
        self.assertIn("++case_id", TEST)
        self.assertIn("recover_active()", TEST)
        self.assertIn("drain_deadline()", TEST)
        self.assertIn("byteObserved", TEST)

    def test_incomplete_output_is_failure_and_terminal_cannot_be_held(self):
        self.assertIn('check(!ferror(journal) && fflush(journal) == 0', TEST)
        self.assertIn('return ferror(stdout) || fflush(stdout) != 0 ? 74 : 0', TEST)
        terminal = C[C.index('if (WIFEXITED(status) || WIFSIGNALED(status))'):C.index('if (!WIFSTOPPED(status))')]
        self.assertIn('l->observation.preexec_held = 0', terminal)


if __name__ == "__main__":
    unittest.main(verbosity=2)
