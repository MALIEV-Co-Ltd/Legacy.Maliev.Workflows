#ifndef MALIEV_TEST_PROGRAM_CHILD_H
#define MALIEV_TEST_PROGRAM_CHILD_H
#include <stdint.h>

/* Test-local ABI v1, Linux x86_64. No qualified factory is installed. */
typedef struct pc_lease pc_lease;
typedef struct {
    uint32_t size, abi;
    const char *executable, *cwd;
    const char *const *argv, *const *envp;
    int64_t lease_deadline_ns; /* CLOCK_MONOTONIC, original <=45s */
    int64_t work_deadline_ns;  /* same origin, <=30s and <=remaining lease */
    uint32_t test_fault; /* Test-local fault injection0normal,1..8; NEVER capability. */
} pc_request;
typedef struct {
    uint32_t size, abi;
    int32_t pid, terminal, exit_code, signal;
    uint64_t start_ticks;
    int64_t birth_utc_ns;
    char boot_id[37], executable[4096];
    int32_t preexec_held, denial_observed, exact_absence, native_error;
    uint32_t owned_tasks, reaped_tasks;
} pc_observation;

int64_t pc_monotonic_ns(void);
/* *out is published before pipes/thread/fork. Retain on EVERY return. */
int pc_create(const pc_request *, pc_lease **out);
int pc_observe_hold(pc_lease *, pc_observation *);
int pc_enforce_denial(pc_lease *, int64_t original_deadline_ns);
int pc_resume(pc_lease *, int64_t original_deadline_ns);
/* Poll does not cancel or consume shared native terminal custody. */
int pc_observe(pc_lease *, pc_observation *);
int pc_recover(pc_lease *, int64_t original_stop_deadline_ns);
/* Duplicate read descriptors transfer to managed SafeFileHandle exactly once.
 * Caller closes/drains both, then acknowledges. Originals stay native-owned. */
int pc_take_readers(pc_lease *, int *stdout_fd, int *stderr_fd);
int pc_ack_readers_closed(pc_lease *);
/* Exclusive final call, only after callers/pollers settled. Joins native owner. */
int pc_release(pc_lease **, int64_t original_release_deadline_ns);
#endif
