#define _GNU_SOURCE
#include "program_child.h"
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <netinet/in.h>
#include <poll.h>
#include <stddef.h>
#include <pthread.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static pc_lease *active;
static int active_out = -1, active_err = -1;
static int64_t active_deadline;
static int64_t active_work_deadline, active_stop_deadline, active_drain_deadline;
static FILE *journal;
static unsigned case_id;
static int control_fds[3] = {-1, -1, -1};
static void check(int yes, const char *message);
static void journal_observation(const char *mode, const char *phase, const pc_observation *o) {
    fprintf(journal, "{\"schema\":1,\"caseId\":%u,\"mode\":\"%s\",\"phase\":\"%s\",\"observerPid\":%d,\"monotonicNs\":%" PRId64
        ",\"leaseDeadlineNs\":%" PRId64 ",\"workDeadlineNs\":%" PRId64 ",\"stopDeadlineNs\":%" PRId64
        ",\"drainDeadlineNs\":%" PRId64 ",\"pid\":%d,\"startTicks\":%" PRIu64 ",\"birthUtcNs\":%" PRId64
        ",\"bootId\":\"%s\",\"executable\":\"", case_id, mode, phase, getpid(), pc_monotonic_ns(), active_deadline,
        active_work_deadline, active_stop_deadline, active_drain_deadline, o->pid, o->start_ticks, o->birth_utc_ns, o->boot_id);
    for (const unsigned char *p = (const unsigned char *)o->executable; *p; ++p) {
        if (*p == '"' || *p == '\\') fprintf(journal, "\\%c", *p);
        else if (*p < 32) fprintf(journal, "\\u%04x", *p);
        else fputc(*p, journal);
    }
    fprintf(journal, "\",\"preexecHeld\":%d,\"denialObserved\":%d,\"terminal\":%d,\"exitCode\":%d,\"signal\":%d,\"nativeError\":%d,\"exactAbsence\":%d,\"ownedTasks\":%u,\"reapedTasks\":%u}\n",
        o->preexec_held, o->denial_observed, o->terminal, o->exit_code, o->signal, o->native_error,
        o->exact_absence, o->owned_tasks, o->reaped_tasks);
    check(!ferror(journal) && fflush(journal) == 0, "native case journal complete");
}
static int recover_active(void) {
    if (!active_stop_deadline) {
        active_stop_deadline = pc_monotonic_ns() + 5LL * 1000000000;
        if (active_stop_deadline > active_deadline) active_stop_deadline = active_deadline;
    }
    return pc_recover(active, active_stop_deadline);
}
static int64_t drain_deadline(void) {
    if (!active_drain_deadline) {
        active_drain_deadline = pc_monotonic_ns() + 5LL * 1000000000;
        if (active_drain_deadline > active_deadline) active_drain_deadline = active_deadline;
    }
    return active_drain_deadline;
}
static atomic_int waiter_failed;
static pthread_t active_waiters[2];
static unsigned active_waiter_count;
static int join_waiters(int64_t deadline) {
    while (active_waiter_count) {
        int error = pthread_tryjoin_np(active_waiters[active_waiter_count - 1], NULL);
        if (!error) { --active_waiter_count; continue; }
        if (error != EBUSY) return error;
        if (pc_monotonic_ns() >= deadline) return ETIMEDOUT;
        struct timespec t = {0, 1000000}; nanosleep(&t, NULL);
    }
    return 0;
}
static void failure_cleanup(void) {
    for (int i = 0; i < 3; ++i) if (control_fds[i] >= 0) { close(control_fds[i]); control_fds[i] = -1; }
    if (!active) return;
    int recovered = recover_active();
    int settled_waiters = join_waiters(active_stop_deadline);
    if (settled_waiters) {
        fprintf(stderr, "failure cleanup quarantined unsettled waiters=%d\n", settled_waiters);
        return;
    }
    if (!recovered) {
        if (active_out < 0 && active_err < 0) pc_take_readers(active, &active_out, &active_err);
        int fds[] = {active_out, active_err};
        for (int i = 0; i < 2; ++i) if (fds[i] >= 0) {
            int flags = fcntl(fds[i], F_GETFL);
            if (flags >= 0) fcntl(fds[i], F_SETFL, flags | O_NONBLOCK);
            char buf[4096];
            while (pc_monotonic_ns() < drain_deadline() && read(fds[i], buf, sizeof(buf)) > 0) {}
            close(fds[i]);
        }
        active_out = active_err = -1;
        int settled = pc_ack_readers_closed(active);
        int released = settled ? settled : pc_release(&active, drain_deadline());
        fprintf(stderr, "failure cleanup recover=%d readers=%d release=%d retained=%d\n",
                recovered, settled, released, active != NULL);
    } else fprintf(stderr, "failure cleanup quarantined native custody error=%d\n", recovered);
}
static void check(int yes, const char *message) {
    if (!yes) {
        fprintf(stderr, "FAIL: %s errno=%d\n", message, errno);
        fprintf(stdout, "FAIL: %s\n", message); fflush(stdout);
        failure_cleanup(); exit(1);
    }
}
static void live_control(int family, const char *position) {
    struct sockaddr_storage address = {0}; socklen_t length;
    if (family == AF_INET) {
        struct sockaddr_in *a = (struct sockaddr_in *)&address;
        a->sin_family = AF_INET; a->sin_addr.s_addr = htonl(INADDR_LOOPBACK); length = sizeof(*a);
    } else {
        struct sockaddr_in6 *a = (struct sockaddr_in6 *)&address;
        a->sin6_family = AF_INET6; a->sin6_addr = in6addr_loopback; length = sizeof(*a);
    }
    control_fds[0] = socket(family, SOCK_STREAM | SOCK_CLOEXEC, 0);
    check(control_fds[0] >= 0, "live parent observer socket");
    check(bind(control_fds[0], (struct sockaddr *)&address, length) == 0 &&
          listen(control_fds[0], 1) == 0, "live parent loopback listener");
    check(getsockname(control_fds[0], (struct sockaddr *)&address, &length) == 0, "actual parent port");
    control_fds[1] = socket(family, SOCK_STREAM | SOCK_CLOEXEC | SOCK_NONBLOCK, 0);
    check(control_fds[1] >= 0, "live parent client socket");
    int connected = connect(control_fds[1], (struct sockaddr *)&address, length);
    check(connected == 0 || errno == EINPROGRESS, "live parent connection outside child denial");
    struct pollfd ready = {.fd = control_fds[1], .events = POLLOUT};
    check(poll(&ready, 1, 1000) == 1, "finite parent connect completion");
    int socket_error = -1; socklen_t error_length = sizeof(socket_error);
    check(getsockopt(control_fds[1], SOL_SOCKET, SO_ERROR, &socket_error, &error_length) == 0 && !socket_error,
          "actual parent connect status");
    ready.fd = control_fds[0]; ready.events = POLLIN;
    check(poll(&ready, 1, 1000) == 1, "finite parent accept readiness");
    control_fds[2] = accept4(control_fds[0], NULL, NULL, SOCK_CLOEXEC | SOCK_NONBLOCK);
    check(control_fds[2] >= 0 && send(control_fds[1], "x", 1, MSG_NOSIGNAL) == 1, "live parent TCP byte sent");
    char byte; int64_t deadline = pc_monotonic_ns() + 1000000000;
    for (;;) {
        ssize_t n = recv(control_fds[2], &byte, 1, 0);
        if (n == 1) { check(byte == 'x', "live parent TCP byte observed"); break; }
        check(n < 0 && (errno == EAGAIN || errno == EINTR) && pc_monotonic_ns() < deadline,
              "finite live TCP control");
        struct timespec t = {0, 1000000}; nanosleep(&t, NULL);
    }
    unsigned port = family == AF_INET ? ntohs(((struct sockaddr_in *)&address)->sin_port)
                                      : ntohs(((struct sockaddr_in6 *)&address)->sin6_port);
    for (int i = 0; i < 3; ++i) { close(control_fds[i]); control_fds[i] = -1; }
    fprintf(journal, "{\"schema\":1,\"caseId\":%u,\"phase\":\"live-parent-control\",\"position\":\"%s\",\"observerPid\":%d,\"monotonicNs\":%" PRId64 ",\"family\":%d,\"loopbackPort\":%u,\"connected\":true,\"byteObserved\":true,\"socketsClosed\":true}\n",
            case_id, position, getpid(), pc_monotonic_ns(), family, port);
    check(!ferror(journal) && fflush(journal) == 0, "live parent control journal complete");
}
static pc_observation snapshot(pc_lease *l) {
    pc_observation o = {.size = sizeof(o), .abi = 1};
    check(pc_observe(l, &o) == 0, "observation"); return o;
}
static void tick(void) { struct timespec t = {0, 1000000}; nanosleep(&t, NULL); }
static pc_observation await_terminal(pc_lease *l, int64_t deadline) {
    for (;;) {
        pc_observation o = snapshot(l);
        if (o.terminal) return o;
        check(!o.native_error, "native pump fault");
        check(pc_monotonic_ns() < deadline, "terminal bounded wait"); tick();
    }
}
static void *concurrent_wait(void *arg) {
    pc_lease *l = arg;
    int64_t deadline = pc_monotonic_ns() + 3LL * 1000000000;
    for (;;) {
        pc_observation o = {.size = sizeof(o), .abi = 1};
        int error = pc_observe(l, &o);
        if (error || o.native_error || pc_monotonic_ns() >= deadline) { atomic_store(&waiter_failed, 1); break; }
        if (o.terminal) { if (o.exit_code != 17 || o.signal != -1) atomic_store(&waiter_failed, 1); break; }
        tick();
    }
    return NULL;
}
/* The test executable is the actual direct child. This is NOT a Program wrapper.
 * Hosted .NET qualification must additionally execute Auth's exact Program. */
static void *fork_worker(void *unused) {
    (void)unused;
    for (unsigned i = 0; i < 10; ++i) {
        pid_t pid = fork();
        if (!pid) { struct timespec t = {10, 0}; nanosleep(&t, NULL); _exit(0); }
        if (pid < 0) break;
    }
    return NULL;
}
static int child_mode(const char *mode) {
    if (!strcmp(mode, "closed-input") && (fcntl(STDIN_FILENO, F_GETFD) >= 0 || errno != EBADF)) return 99;
    if (!strcmp(mode, "inherited-input")) {
        char input[16] = {0};
        if (read(STDIN_FILENO, input, sizeof(input)) != 15 || strcmp(input, "inherited-input")) return 100;
    }
    if (!strcmp(mode, "closed-output") && fcntl(STDOUT_FILENO, F_GETFD) < 0) return 101;
    if (!strcmp(mode, "closed-error") && fcntl(STDERR_FILENO, F_GETFD) < 0) return 102;
    int a = socket(AF_INET, SOCK_STREAM, 0); int ea = errno;
    int b = socket(AF_INET6, SOCK_STREAM, 0); int eb = errno;
    if (a >= 0 || b >= 0 || ea != EPERM || eb != EPERM) return 91;
    if (!strcmp(mode, "signal")) { kill(getpid(), SIGKILL); return 92; }
    if (!strcmp(mode, "stop")) kill(getpid(), SIGSTOP);
    if (!strcmp(mode, "slow")) { struct timespec t = {2, 0}; nanosleep(&t, NULL); }
    if (!strcmp(mode, "race")) {
        pthread_t threads[3];
        for (unsigned i = 0; i < 3; ++i) if (pthread_create(&threads[i], NULL, fork_worker, NULL)) return 97;
        struct timespec t = {10, 0}; nanosleep(&t, NULL);
        return 98;
    }
    if (!strcmp(mode, "descendant")) {
        pid_t pid = fork();
        if (pid < 0) return 93;
        if (!pid) { struct timespec t = {10, 0}; nanosleep(&t, NULL); _exit(0); }
    }
    if (!strcmp(mode, "ceiling")) {
        unsigned created = 0; int limited = 0;
        for (unsigned i = 0; i < 70; ++i) {
            pid_t pid = fork();
            if (pid < 0) { if (errno == EAGAIN) limited = 1; else return 94; break; }
            if (!pid) _exit(0);
            int status;
            if (waitpid(pid, &status, 0) != pid || !WIFEXITED(status)) return 95;
            ++created;
        }
        if (!limited || created != 63) return 96;
    }
    puts("native-child-output"); return 17;
}
static void run(const char *exe, const char *mode) {
    ++case_id; active_stop_deadline = active_drain_deadline = 0;
    live_control(AF_INET, "before-create"); live_control(AF_INET6, "before-create");
    const char *argv[] = {exe, "--child", mode, NULL};
    const char *envp[] = {"LANG=C", NULL};
    int64_t origin = pc_monotonic_ns();
    pc_request r = {.size = sizeof(r), .abi = 1, .executable = exe, .cwd = "/",
        .argv = argv, .envp = envp, .lease_deadline_ns = origin + 45LL * 1000000000,
        .work_deadline_ns = origin + 30LL * 1000000000};
    pc_lease *l = NULL;
    active_deadline = r.lease_deadline_ns;
    active_work_deadline = r.work_deadline_ns;
    int e = pc_create(&r, &l);
    active = l;
    check(l != NULL, "published retained lease");
    check(e == 0, "held creation");
    pc_observation before = {.size = sizeof(before), .abi = 1};
    check(pc_observe_hold(l, &before) == 0 && before.preexec_held && before.start_ticks &&
        before.pid > 0 && strlen(before.boot_id) == 36, "actual held identity");
    journal_observation(mode, "held", &before);
    check(pc_resume(l, r.work_deadline_ns) != 0, "resume refuses absent denial");
    check(pc_enforce_denial(l, r.work_deadline_ns) == 0, "actual child syscall denial");
    pc_observation denied = {.size = sizeof(denied), .abi = 1};
    check(pc_observe_hold(l, &denied) == 0 && denied.denial_observed &&
        denied.pid == before.pid && denied.start_ticks == before.start_ticks &&
        !strcmp(denied.executable, before.executable), "same generation second hold");
    journal_observation(mode, "denied-held", &denied);
    int out = -1, err = -1;
    e = pc_take_readers(l, &out, &err); active_out = out; active_err = err;
    check(e == 0, "reader descriptor transfer");
    check(pc_resume(l, r.work_deadline_ns) == 0, "resume exact held child");
    if (!strcmp(mode, "race")) {
        int64_t barrier = pc_monotonic_ns() + 3LL * 1000000000;
        while (snapshot(l).owned_tasks < 4) {
            check(pc_monotonic_ns() < barrier, "actual concurrent clone/fork boundary reached"); tick();
        }
    }
    if (!strcmp(mode, "slow") || !strcmp(mode, "race")) {
        /* Abandoned poll waiter cannot abandon the native owner. */
        check(!snapshot(l).terminal, "canceled waiter did not manufacture exit");
        check(recover_active() == 0, "recover canceled wait");
    }
    int concurrent = !strcmp(mode, "normal");
    if (concurrent) for (unsigned i = 0; i < 2; ++i) {
        e = pthread_create(&active_waiters[i], NULL, concurrent_wait, l);
        if (!e) ++active_waiter_count;
        check(e == 0, "waiter start");
    }
    pc_observation terminal = await_terminal(l, pc_monotonic_ns() + 10LL * 1000000000);
    journal_observation(mode, "terminal", &terminal);
    if (!strcmp(mode, "signal") || !strcmp(mode, "slow") || !strcmp(mode, "race"))
        check(terminal.exit_code == -1 && terminal.signal == SIGKILL, "native signal status");
    else check(terminal.exit_code == 17 && terminal.signal == -1, "native normal17 status");
    check(join_waiters(r.work_deadline_ns) == 0, "waiters bounded/joined");
    check(!atomic_load(&waiter_failed), "concurrent immutable status");
    check(recover_active() == 0, "exact absence");
    pc_observation repeated = snapshot(l);
    check(repeated.pid == terminal.pid && repeated.start_ticks == terminal.start_ticks &&
        repeated.exit_code == terminal.exit_code && repeated.signal == terminal.signal &&
        repeated.exact_absence && repeated.owned_tasks == repeated.reaped_tasks, "idempotent status and reap");
    if (!strcmp(mode, "descendant")) check(repeated.owned_tasks == 2, "descendant retained and reaped");
    if (!strcmp(mode, "ceiling")) check(repeated.owned_tasks == 64, "all capped tasks retained and reaped");
    if (!strcmp(mode, "race")) check(repeated.owned_tasks >= 4, "concurrent fork/clone recovery accounted");
    char buf[256];
    drain_deadline();
    ssize_t output_length = read(out, buf, sizeof(buf));
    check(output_length >= 0 && read(err, buf, sizeof(buf)) == 0, "readers reach EOF");
    if (terminal.exit_code == 17) check(output_length == (ssize_t)(sizeof("native-child-output\n") - 1) &&
        !memcmp(buf, "native-child-output\n", sizeof("native-child-output\n") - 1), "exact redirected stdout bytes");
    close(out); close(err);
    active_out = active_err = -1;
    check(pc_ack_readers_closed(l) == 0, "managed readers closed");
    check(pc_release(&l, drain_deadline()) == 0 && !l, "verified custody released");
    active = NULL;
    journal_observation(mode, "released", &repeated);
    live_control(AF_INET, "after-release"); live_control(AF_INET6, "after-release");
    printf("PASS native case %s\n", mode);
}
static void run_fault(const char *exe, uint32_t point) {
    ++case_id; active_stop_deadline = active_drain_deadline = 0;
    const char *argv[] = {exe, "--child", "normal", NULL};
    const char *envp[] = {"LANG=C", NULL};
    int64_t origin = pc_monotonic_ns();
    pc_request r = {.size = sizeof(r), .abi = 1, .executable = exe, .cwd = "/",
        .argv = argv, .envp = envp, .lease_deadline_ns = origin + 45LL * 1000000000,
        .work_deadline_ns = origin + 30LL * 1000000000, .test_fault = point};
    pc_lease *l = NULL;
    active_deadline = r.lease_deadline_ns;
    active_work_deadline = r.work_deadline_ns;
    int e = pc_create(&r, &l);
    active = l;
    check(l != NULL, "fault retained handle");
    if (point <= 5 || point == 8) check(e != 0, "actual partial creation fails");
    else {
        check(e == 0, "fault holds original child");
        e = pc_enforce_denial(l, r.work_deadline_ns);
        if (point == 6) check(e != 0, "deny refusal observed");
        else {
            check(e == 0, "denied before injected resume refusal");
            check(pc_resume(l, r.work_deadline_ns) != 0, "resume refusal retained");
        }
    }
    check(recover_active() == 0, "partial exact absence");
    pc_observation o = snapshot(l);
    check(o.native_error != 0 && o.exact_absence && o.owned_tasks == o.reaped_tasks,
        "primary fault retained alongside verified recovery");
    if (point == 8) {
        int out = -1, err = -1;
        e = pc_take_readers(l, &out, &err); active_out = out; active_err = err;
        check(e == 0, "failed fork readers retained");
        char buf[1];
        check(read(out, buf, sizeof(buf)) == 0 && read(err, buf, sizeof(buf)) == 0, "failed fork writers closed/EOF");
        close(out); close(err);
        active_out = active_err = -1;
        check(pc_ack_readers_closed(l) == 0, "failed fork independent pipe settlement");
    }
    check(pc_release(&l, drain_deadline()) == 0 && l == NULL, "partial native descriptors/thread released");
    active = NULL;
    char mode[32]; snprintf(mode, sizeof(mode), "fault%u", point);
    journal_observation(mode, "released", &o);
    printf("PASS native fault%u\n", point);
}
static void inherited_input_cases(const char *exe) {
    int saved = fcntl(STDIN_FILENO, F_DUPFD_CLOEXEC, 3);
    check(saved >= 3, "retained original test stdin");
    close(STDIN_FILENO);
    run(exe, "closed-input");
    check(fcntl(STDIN_FILENO, F_GETFD) < 0 && errno == EBADF, "parent closed stdin preserved");
    check(dup2(saved, STDIN_FILENO) == STDIN_FILENO, "restore original test stdin");
    int input[2]; check(pipe2(input, O_CLOEXEC) == 0, "input fixture pipe");
    check(write(input[1], "inherited-input", 15) == 15, "input bytes"); close(input[1]);
    check(dup2(input[0], STDIN_FILENO) == STDIN_FILENO, "inherited input supplied"); close(input[0]);
    run(exe, "inherited-input");
    check(dup2(saved, STDIN_FILENO) == STDIN_FILENO, "restore test stdin after input case"); close(saved);
    int unmodeled = open("/dev/null", O_RDONLY); /* deliberately inheritable */
    check(unmodeled >= 3, "unmodeled inheritable descriptor");
    const char *argv[] = {exe, "--child", "normal", NULL}, *envp[] = {"LANG=C", NULL};
    int64_t origin = pc_monotonic_ns();
    pc_request request = {.size = sizeof(request), .abi = 1, .executable = exe, .cwd = "/",
        .argv = argv, .envp = envp, .lease_deadline_ns = origin + 45LL * 1000000000,
        .work_deadline_ns = origin + 30LL * 1000000000};
    pc_lease *l = NULL;
    int e = pc_create(&request, &l); close(unmodeled);
    check(e == ENOTSUP && l == NULL, "extra inheritable descriptor refused before allocation");
    puts("PASS preallocation unsupported descriptor refusal");
    ++case_id;
    active_deadline = request.lease_deadline_ns; active_work_deadline = request.work_deadline_ns;
    active_stop_deadline = active_drain_deadline = 0;
    pc_observation refused = {.size = sizeof(refused), .abi = 1, .exit_code = -1, .signal = -1, .native_error = e};
    journal_observation("unsupported-descriptor", "preallocation-refused", &refused);
}
static void closed_output_cases(const char *exe) {
    fflush(stdout); fflush(stderr);
    int saved = fcntl(STDOUT_FILENO, F_DUPFD_CLOEXEC, 3);
    check(saved >= 3, "original test stdout retained"); close(STDOUT_FILENO);
    run(exe, "closed-output");
    check(fcntl(STDOUT_FILENO, F_GETFD) < 0 && errno == EBADF, "parent closed stdout preserved");
    check(dup2(saved, STDOUT_FILENO) == STDOUT_FILENO, "original test stdout restored"); close(saved); clearerr(stdout);
    saved = fcntl(STDERR_FILENO, F_DUPFD_CLOEXEC, 3);
    check(saved >= 3, "original test stderr retained"); close(STDERR_FILENO);
    run(exe, "closed-error");
    check(fcntl(STDERR_FILENO, F_GETFD) < 0 && errno == EBADF, "parent closed stderr preserved");
    check(dup2(saved, STDERR_FILENO) == STDERR_FILENO, "original test stderr restored"); close(saved); clearerr(stderr);
}
int main(int argc, char **argv) {
    if (argc == 3 && !strcmp(argv[1], "--child")) return child_mode(argv[2]);
    if (argc == 2 && !strcmp(argv[1], "--abi")) {
        printf("{\"abi\":1,\"pointerBytes\":%zu,\"requestBytes\":%zu,\"observationBytes\":%zu,\"requestOffsets\":{\"size\":%zu,\"abi\":%zu,\"executable\":%zu,\"cwd\":%zu,\"argv\":%zu,\"envp\":%zu,\"lease_deadline_ns\":%zu,\"work_deadline_ns\":%zu,\"test_fault\":%zu},",
            sizeof(void *), sizeof(pc_request), sizeof(pc_observation), offsetof(pc_request, size), offsetof(pc_request, abi),
            offsetof(pc_request, executable), offsetof(pc_request, cwd), offsetof(pc_request, argv), offsetof(pc_request, envp),
            offsetof(pc_request, lease_deadline_ns), offsetof(pc_request, work_deadline_ns), offsetof(pc_request, test_fault));
        printf("\"observationOffsets\":{\"size\":%zu,\"abi\":%zu,\"pid\":%zu,\"terminal\":%zu,\"exit_code\":%zu,\"signal\":%zu,\"start_ticks\":%zu,\"birth_utc_ns\":%zu,\"boot_id\":%zu,\"executable\":%zu,\"preexec_held\":%zu,\"denial_observed\":%zu,\"exact_absence\":%zu,\"native_error\":%zu,\"owned_tasks\":%zu,\"reaped_tasks\":%zu}}\n",
            offsetof(pc_observation, size), offsetof(pc_observation, abi), offsetof(pc_observation, pid), offsetof(pc_observation, terminal),
            offsetof(pc_observation, exit_code), offsetof(pc_observation, signal), offsetof(pc_observation, start_ticks),
            offsetof(pc_observation, birth_utc_ns), offsetof(pc_observation, boot_id), offsetof(pc_observation, executable),
            offsetof(pc_observation, preexec_held), offsetof(pc_observation, denial_observed), offsetof(pc_observation, exact_absence),
            offsetof(pc_observation, native_error), offsetof(pc_observation, owned_tasks), offsetof(pc_observation, reaped_tasks));
        return ferror(stdout) || fflush(stdout) != 0 ? 74 : 0;
    }
    int journal_fd = fcntl(STDOUT_FILENO, F_DUPFD_CLOEXEC, 3);
    check(journal_fd >= 3, "retained case journal descriptor");
    journal = fdopen(journal_fd, "w");
    if (!journal) close(journal_fd);
    check(journal != NULL, "case journal stream");
    char exe[4096]; ssize_t n = readlink("/proc/self/exe", exe, sizeof(exe) - 1);
    check(n > 0, "self executable"); exe[n] = 0;
    run(exe, "normal"); run(exe, "signal"); run(exe, "stop"); run(exe, "slow");
    run(exe, "descendant"); run(exe, "ceiling");
    for (unsigned i = 0; i < 3; ++i) run(exe, "race");
    for (uint32_t point = 1; point <= 8; ++point) run_fault(exe, point);
    inherited_input_cases(exe);
    closed_output_cases(exe);
    check(fclose(journal) == 0, "case journal descriptor closed"); journal = NULL;
    puts("PASS 22 actual Linux child cases; Auth Program qualification remains separate");
    return 0;
}
